%% note

% this version is for reruns to fix load events being off by one hour due
% to error with daylight saving. this was started on feb 08 2022
%
% set up to do runs for one plant at the 95th percentile for 85% RTE only

%% load data

load_raw = readtable('matlab_export/load_profiles_02_08_22.xlsx');
[m,n] = size(load_raw);
load_raw = load_raw(:,3:n);
plant_ids = load_raw.Properties.VariableNames;

load_data = table2array(load_raw);


%% feasibility 

% removing cogen and some basic variable initialization

cogen = [9,10]; %manually determine cogen plants by name

load_data(:,cogen) = [];
load_data_og = load_data;
[m,n] = size(load_data);
load_maxes = max(load_data);


%% filenames for loads w/ percentile replacement

filename2 = num2str(linspace(100, 50, 11)');
filename1 = repelem("apr_14_22_results/opt_results_long_mar_25_22_allRTE_p", length(filename2))';
filename3 = repelem(".xlsx", length(filename2))';
filenames = strcat(filename1, filename2, filename3);

% filenames for P_solved

filename_P1 = repelem("apr_14_22_results/opt_results_p", length(filename2))';
filename_P2 = filename2;
filename_P3 = filename3;
filenames_P = strcat(filename_P1, filename_P2, filename_P3);

%% RTES, prices, and cycle costs

% RTEs

rtes = ["RTE80", "RTE90", "RTE100"]; % ["RTE85"]; % ["RTE80", "RTE85", "RTE90", "RTE100"];


% price loading and cleaning

price_raw = readtable('matlab_export/PriceDataWide_v2.xlsx'); % fix to dec. 2020
plant_nodes = readtable('matlab_export/PlantNodes_v2.xlsx'); % adjust to correct nodes
plant_nodes(cogen,:) = [];

np_price = table2array(price_raw(:,5));
sp_price = table2array(price_raw(:,6));
zp_price = table2array(price_raw(:,7));

% manual scrubbing of data to remove large nas
for i = 1:length(np_price)-1 % sets single data entry gaps to linear interpolation
    
    if isnan(np_price(i))
        np_price(i) = (np_price(i-1) + np_price(i+1))/2;
    end
    
    if isnan(sp_price(i))
        sp_price(i) = (sp_price(i-1) + sp_price(i+1))/2;
    end
    
    if isnan(zp_price(i))
        zp_price(i) = (zp_price(i-1) + zp_price(i+1))/2;
    end
    
end


for i = 1:length(np_price)-1 % set remaining nas to high price
    
    if isnan(np_price(i))
        np_price(i) = 999;
    end
    
    if isnan(sp_price(i))
        sp_price(i) = 999;
    end
    
    if isnan(zp_price(i))
        zp_price(i) = 999;
    end
    
end



for i = 1:length(np_price)-1 % set negative prices to 0.001 for optimization behavior
    
    if np_price(i) <= 0
        np_price(i) = 0.001;
    end
    
    if sp_price(i) <= 0
        sp_price(i) = 0.001;
    end
    
    if zp_price(i) <= 0
        zp_price(i) = 0.001;
    end
    
end


cycle_cost_list = [0.2054, 0.1122, 0.07563, 0.0938, 0.06694, 0.05491]; % [0.1496, 0.08958, 0.06527, 0.1775, 0.1009, 0.07045, 0.1217, 0.07826, 0.06009]*1000; % ($/MWh/cycle)
cycle_cost_list_char = ["NMC_Extra_High", "NCA_Extra_High", "LFP_Extra_High", "NMC_Extra_Low", "NCA_Extra_Low", "LFP_Extra_Low"]; % ["NMC", "NCA", "LFP", "NMC_High", "NCA_High", "LFP_High", "NMC_Low", "NCA_Low", "LFP_Low"];

%% charge data and omittted load removal

% following 2 lines fix filenames to p95
filenames =  filenames(2);
filenames_P = filenames_P(2);

peaker_results = readtable(filenames);
omitted_events = reshape(table2array(peaker_results(:,'omitted_event_mwh')), [m,n]);
load_data = load_data_og - omitted_events;

peaker_charge_RTE80 = reshape(table2array(peaker_results(:,'RTE80')), [m,n]);
peaker_charge_RTE85 = reshape(table2array(peaker_results(:,'RTE85')), [m,n]);
peaker_charge_RTE90 = reshape(table2array(peaker_results(:,'RTE90')), [m,n]);
peaker_charge_RTE100 = reshape(table2array(peaker_results(:,'RTE100')), [m,n]);

%% recreate existing SOC (Z's) % NEED TO PROCESS ALL RESULTZ

Z_peak_RTE80 = zeros(m+1,n);
Z_peak_RTE85 = zeros(m+1,n);
Z_peak_RTE90 = zeros(m+1,n);
Z_peak_RTE100 = zeros(m+1,n);

for i = 1:n
    
    for j = 1:m
        
        if j==1
            
            Z_peak_RTE80(j,i) = 0;
            Z_peak_RTE85(j,i) = 0;
            Z_peak_RTE90(j,i) = 0;
            Z_peak_RTE100(j,i) = 0; 
            
        else
            
            Z_peak_RTE80(j,i) = Z_peak_RTE80(j-1,i) + 0.894427191 * peaker_charge_RTE80(j-1,i) - (1/0.894427191) * load_data(j-1,i);
            Z_peak_RTE85(j,i) = Z_peak_RTE85(j-1,i) + 0.921954446 * peaker_charge_RTE85(j-1,i) - (1/0.921954446) * load_data(j-1,i);
            Z_peak_RTE90(j,i) = Z_peak_RTE90(j-1,i) + 0.948683298 * peaker_charge_RTE90(j-1,i) - (1/0.948683298) * load_data(j-1,i);
            Z_peak_RTE100(j,i) = Z_peak_RTE100(j-1,i) + 1 * peaker_charge_RTE100(j-1,i) - (1/1) * load_data(j-1,i);
            
            if Z_peak_RTE80(j,i) < 1
                
                Z_peak_RTE80(j,i) = 0;
                
            end
            
            if Z_peak_RTE85(j,i) < 1
                
                Z_peak_RTE85(j,i) = 0;
                
            end
            
            if Z_peak_RTE90(j,i) < 1
                
                Z_peak_RTE90(j,i) = 0;
                
            end
            
            if Z_peak_RTE100(j,i) < 1
                
                Z_peak_RTE100(j,i) = 0;
                
            end
            
        end
        
        Z_peak_RTE80(m+1,i) = Z_peak_RTE80(m,i) + 0.894427191 * peaker_charge_RTE80(m,i) - (1/0.894427191) * load_data(m,i);
        Z_peak_RTE85(m+1,i) = Z_peak_RTE85(m,i) + 0.921954446 * peaker_charge_RTE85(m,i) - (1/0.921954446) * load_data(m,i);
        Z_peak_RTE90(m+1,i) = Z_peak_RTE90(m,i) + 0.948683298 * peaker_charge_RTE90(m,i) - (1/0.948683298) * load_data(m,i);
        Z_peak_RTE100(m+1,i) = Z_peak_RTE100(m,i) + 1 * peaker_charge_RTE100(m,i) - (1/1) * load_data(m,i);
        
        
            if Z_peak_RTE80(m+1,i) < 1
                
                Z_peak_RTE80(m+1,i) = 0;
                
            end
            
            if Z_peak_RTE85(m+1,i) < 1
                
                Z_peak_RTE85(m+1,i) = 0;
                
            end
            
            if Z_peak_RTE90(m+1,i) < 1
                
                Z_peak_RTE90(m+1,i) = 0;
                
            end
            
            if Z_peak_RTE100(m+1,i) < 1
                
                Z_peak_RTE100(m+1,i) = 0;
                
            end 
               
    end
    
end





%% cleaning and opt

% n = 2;

for p = 1:length(cycle_cost_list)

    % p = 1;
    temp_cc = cycle_cost_list(p);
    
    for j = 1:length(rtes) % go through RTEs
        
        % j = 1;
        r_time_array = zeros(m,n);
        q_time_array = zeros(m,n);
        
        if rtes(j)=="RTE80"
            
            tmu = 0.894427191;
            peaker_charge = peaker_charge_RTE80;
            P_idx = 'Sheet4';
            Z_peak = Z_peak_RTE80;
            
        elseif rtes(j)=="RTE85"
            
            tmu = 0.921954446;
            peaker_charge = peaker_charge_RTE85;
            P_idx = 'Sheet2';
            Z_peak = Z_peak_RTE85;
            
        elseif rtes(j)=="RTE90"
            
            tmu = 0.948683298;
            peaker_charge = peaker_charge_RTE90;
            P_idx = 'Sheet6';
            Z_peak = Z_peak_RTE90;
            
        else
        
            tmu = 1;
            peaker_charge = peaker_charge_RTE100;
            P_idx = 'Sheet8';
            Z_peak = Z_peak_RTE100;
            
        end
        
        tP_solved = table2array(readtable(filenames_P, sheet = P_idx));
        
        for k = 1:n % go through plants
            
            % k = 1;
            tload = load_data(:,k);
            tcharge = peaker_charge(:,k);
            tZ_peak = Z_peak(:,k);
            node = char(table2array(plant_nodes(k,2)));
            
            if node == 'SP15' % if statement for price node
                
                tprice = sp_price;
                
            elseif node =='NP15'
                
                tprice = np_price;
                
            else
                
                tprice = zp_price;
                
            end
          
            % setting remaining inputs
            
            tsize_MW = tP_solved(k);
            td = 4;
            tr_cap = load_maxes(k);
            topt_int = 24;
            % tcheck_length = 24; no longer relevant
            
            tcycle_cost = temp_cc * td * tsize_MW; % $ / cycle
            
            % OPTIMIZATION FUNCTION
            
            [q_time_solved, r_time_solved, C_solved] = time_seg_v4(tZ_peak, tprice, td, tmu, tr_cap, topt_int, tsize_MW, tcycle_cost);

            r_time_array(:,k) = r_time_solved;
            q_time_array(:,k) = q_time_solved;
            
            
        end
        
        excel_name = strcat("apr_14_22_results/opt_results_", rtes(j), filename2(2,:), cycle_cost_list_char(p), ".xlsx");
       
        writematrix(r_time_array,excel_name,'Sheet',1) % charge
        writematrix(q_time_array,excel_name,'Sheet',2) % discharge
        
        
        
    end
    
     
end



