function[r,P,Z] = peaker_opt_v3(load, price, d, mu, batt_price, r_cap, Z_0)

% q: load profile from plant
% r: charge profile of battery

% v3: added Z_0 as input and Z as output

    q = load;
    pr = price;
    m = length(q);

cvx_begin

variable P(1)
variable r(m)
variable C(m)
variable Z(m+1)

minimize( P*batt_price + C(m) )

subject to
    P >= 0;

for i = 1:m
    
    if i == 1
        
        subject to
            r(i) >= 0;
            r(i) <= P;
            r(i) <= r_cap; % v2 addition
            Z(i) == Z_0
            r(i)*q(i) == 0;
            P >= q(i);
            C(i) == r(i)*pr(i);
        
    else
        
        subject to
            r(i) >= 0;
            r(i) <= P;
            r(i) <= r_cap; % v2 addition
            Z(i) >= 0;
            Z(i) <= P*d;
            Z(i) == Z(i-1) + mu*r(i-1) - (1/mu)*q(i-1);
            r(i)*q(i) == 0;
            P >= q(i);
            C(i) == r(i)*pr(i) + C(i-1);

    end
    
end

subject to
    Z(m+1) == Z(m) + mu*r(m) - (1/mu)*q(m);
    Z(m+1)>=0;

cvx_end

end
