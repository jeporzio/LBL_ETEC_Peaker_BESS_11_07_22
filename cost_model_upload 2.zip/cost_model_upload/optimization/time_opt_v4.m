function[r,Z,C] = time_opt_v4(load_time, price, d, mu, r_cap, Z_0, size_MW, cycle_cost)

% q: load profile from plant
% r: charge profile of battery

% v4: complete rehaul
%       load_time is pre-selected
%       if Z_peak has a state of charge, skip period





% delete above

    q = load_time;
    pr = price;
    m = length(q);
    P_solved = size_MW;

cvx_begin

variable r(m)
variable C(m)
variable Z(m+1)

minimize( -1 * C(m) )

subject to

for i = 1:m
    
    if i == 1
        
        subject to
            
            r(i) >= 0;
            r(i) <= r_cap;
            r(i) <= P_solved;
            Z(i) == Z_0
            r(i)*q(i) == 0;
            
            C(i) == (q(i) - r(i)) * pr(i) - (q(i) / (P_solved*d)) * cycle_cost;
        
    else
        
        subject to
        
            r(i) >= 0;
            r(i) <= r_cap; % v2 addition
            r(i) <= P_solved
            Z(i) >= 0;
            Z(i) <= P_solved*d;
            Z(i) == Z(i-1) + mu*r(i-1) - (1/mu)*q(i-1);
            r(i)*q(i) == 0;
            
            C(i) == (q(i) - r(i)) * pr(i) - (q(i) / (P_solved*d)) * cycle_cost + C(i-1);

    end
    
end

subject to

    Z(m+1) == Z(m) + mu*r(m) - (1/mu)*q(m);
    Z(m+1) >= 0;

cvx_end

end
