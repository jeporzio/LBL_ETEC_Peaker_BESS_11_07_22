%% note

% This version has an optimizatino interval of 24 hours that expands if 
% peaker activity lands on this threshold.
% This was started on april 11 2022
% 
%
% set up to do runs for one plant at the 95th percentile for 85% RTE only

%% load data

load_raw = readtable('matlab_export/load_profiles_02_08_22.xlsx');
[m,n] = size(load_raw);
load_raw = load_raw(:,3:n);
plant_ids = load_raw.Properties.VariableNames;

load_data = table2array(load_raw);




%% feasibility

cogen = [9,10]; %manually determine cogen plants by name

load_data(:,cogen) = [];
load_data_og = load_data;
[m,n] = size(load_data);
load_maxes = max(load_data);

filename2 = num2str(linspace(100, 50, 11)');
filename1 = repelem("mar_11_22_results/opt_results_p", length(filename2))';
filename3 = repelem(".xlsx", length(filename2))';
filenames = strcat(filename1, filename2, filename3);



%% replacement percentile initializing

[x,y] = size(load_data);

event_size = zeros(x,y);
event_idx_start = zeros(x,y);
event_idx_end = zeros(x,y);

for i=1:y
   
    cntr = 1;
    
    for j=2:x
        
        if load_data(j,i) == 0 && load_data(j-1,i)==0
              
        elseif load_data(j,i) ~= 0 && load_data(j-1,i)==0
            
            event_idx_start(cntr,i) = j;
            event_size(cntr,i) = load_data(j,i);
                
        elseif load_data(j,i) ~= 0 && load_data(j-1,i)~=0

            event_size(cntr,i) = event_size(cntr,i) + load_data(j,i);
            
        elseif load_data(j,i) == 0 && load_data(j-1,i)~=0
            
            event_size(cntr,i) = event_size(cntr,i) + load_data(j,i);
            event_idx_end(cntr,i) = j;
            cntr = cntr + 1;
            
        end 
        
    end
    
end

%% replacement percentile selection and implementation

% percentile = linspace(100, 50, 11); % manually set value, or create for loop
percentile = 95;

pr_cntr = 0;


for z = percentile

    z = 95; % delete me
    pr_cntr = pr_cntr + 1;
    
for i = 1:y
    
    load_events = nonzeros(event_size(:,i));
    load_events_sorted = sort(nonzeros(event_size(:,i)));
    q = length(load_events);
    upbound = load_events_sorted(round(percentile(pr_cntr)/100*q));
    
    for j = 1:q
        
        if load_events(j) > upbound
           
           load_data(event_idx_start(j,i):event_idx_end(j,i),i) = 0;
            
        end
        
    end
    
    
end

omitted_events = load_data_og - load_data; 
writematrix(omitted_events,filenames(pr_cntr),'Sheet',9)


%% price data

price_raw = readtable('matlab_export/PriceDataWide_v2.xlsx'); % fix to dec. 2020
plant_nodes = readtable('matlab_export/PlantNodes_v2.xlsx'); % adjust to correct nodes
plant_nodes(cogen,:) = [];

np_price = table2array(price_raw(:,5));
sp_price = table2array(price_raw(:,6));
zp_price = table2array(price_raw(:,7));

% manual scrubbing of data to remove large nas
for i = 1:length(np_price)-1 % sets single data entry gaps to linear interpolation
    
    if isnan(np_price(i))
        np_price(i) = (np_price(i-1) + np_price(i+1))/2;
    end
    
    if isnan(sp_price(i))
        sp_price(i) = (sp_price(i-1) + sp_price(i+1))/2;
    end
    
    if isnan(zp_price(i))
        zp_price(i) = (zp_price(i-1) + zp_price(i+1))/2;
    end
    
end


for i = 1:length(np_price)-1 % set remaining nas to high price and anything below 1 to 1
    
    if isnan(np_price(i))
        np_price(i) = 999;
    end
    
    if isnan(sp_price(i))
        sp_price(i) = 999;
    end
    
    if isnan(zp_price(i))
        zp_price(i) = 999;
    end
    
    if np_price(i) <= 1
        np_price(i) = 1;
    end
    
    if sp_price(i) <= 1
        sp_price(i) = 1;
    end
    
    if zp_price(i) <= 1
        zp_price(i) = 1;
    end
    
end

% np_price = np_price(1:m);
% sp_price = sp_price(1:m);
% zp_price = zp_price(1:m);

%% opt for all plants - RTE85

[g,h] = size(load_data);

r_array = zeros(g,h);
P_array = zeros(h,1);

% j = 1:h

for j = 1:h
    
    tload = load_data(:,j);
    node = char(table2array(plant_nodes(j,2)));
    
    if node=='SP15'
        
        tprice = sp_price;
        
    elseif node=='NP15'
        
        tprice = np_price;
        
    else
        
        tprice = zp_price; 
        
    end
    
    td = 4;
    tmu = 0.921954446;
    tbatt_price = 99999;
    
    tr_cap = load_maxes(j);
    
    topt_int = 24;
    
    [r_temp,P_temp] = peaker_seg_v4(tload,tprice,td,tmu,tbatt_price, tr_cap, topt_int);
    
    r_array(:,j) = r_temp;
    P_array(j,1) = P_temp;
    
end

writematrix(r_array, filenames(pr_cntr),'Sheet',1)
writematrix(P_array,filenames(pr_cntr),'Sheet',2)

 % remove this end if exploring results for RTE 80, 90, and 100

% everything below this line has been commented out. Uncomment to perform


% writematrix(P_array,filenames(3),'Sheet',2)
%% opt for all plants - RTE80

[g,h] = size(load_data);

r_array = zeros(g,h);
P_array = zeros(h,1);

% j = 1:h

for j = 1:h
    
    tload = load_data(:,j);
    node = char(table2array(plant_nodes(j,2)));
    
    if node=='SP15'
        
        tprice = sp_price;
        
    elseif node=='NP15'
        
        tprice = np_price;
        
    else
        
        tprice = zp_price; 
        
    end
    
    td = 4;
    tmu = 0.894427191;
    tbatt_price = 99999;
    
    tr_cap = load_maxes(j);
    
    topt_int = 24;
    
    [r_temp,P_temp] = peaker_seg_v4(tload,tprice,td,tmu,tbatt_price, tr_cap, topt_int);
    
    r_array(:,j) = r_temp;
    P_array(j,1) = P_temp;
    
end

writematrix(r_array,filenames(pr_cntr),'Sheet',3)
writematrix(P_array,filenames(pr_cntr),'Sheet',4)

%% opt for all plants - RTE90

[g,h] = size(load_data);

r_array = zeros(g,h);
P_array = zeros(h,1);

% j = 1:h

for j = 1:h
    
    tload = load_data(:,j);
    node = char(table2array(plant_nodes(j,2)));
    
    if node=='SP15'
        
        tprice = sp_price;
        
    elseif node=='NP15'
        
        tprice = np_price;
        
    else
        
        tprice = zp_price; 
        
    end
    
    td = 4;
    tmu = 0.948683298;
    tbatt_price = 99999;
    
    tr_cap = load_maxes(j);
    
    topt_int = 24;
    
    [r_temp,P_temp] = peaker_seg_v4(tload,tprice,td,tmu,tbatt_price, tr_cap, topt_int);
    
    r_array(:,j) = r_temp;
    P_array(j,1) = P_temp;
    
end

writematrix(r_array,filenames(pr_cntr),'Sheet',5)
writematrix(P_array,filenames(pr_cntr),'Sheet',6)


%% opt for all plants - RTE100

[g,h] = size(load_data);

r_array = zeros(g,h);
P_array = zeros(h,1);

% j = 1:h

for j = 1:h
    
    tload = load_data(:,j);
    node = char(table2array(plant_nodes(j,2)));
    
    if node=='SP15'
        
        tprice = sp_price;
        
    elseif node=='NP15'
        
        tprice = np_price;
        
    else
        
        tprice = zp_price; 
        
    end
    
    td = 4;
    tmu = 1;
    tbatt_price = 99999;
    
    tr_cap = load_maxes(j);
    
    topt_int = 24;
    
    [r_temp,P_temp] = peaker_seg_v4(tload,tprice,td,tmu,tbatt_price, tr_cap, topt_int);
    
    r_array(:,j) = r_temp;
    P_array(j,1) = P_temp;
    
end

writematrix(r_array,filenames(pr_cntr),'Sheet',7)
writematrix(P_array,filenames(pr_cntr),'Sheet',8)

end