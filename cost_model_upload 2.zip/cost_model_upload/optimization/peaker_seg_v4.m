function[r_solved,P_solved] = peaker_seg_v4(load, price, d, mu, batt_price, r_cap, opt_int)

% load = tload;
%     
% price = tprice;
%      
% mu = tmu;
% d = 4;
% batt_price = 99999;
% r_cap = tr_cap;
% opt_int = 24;

% delete above

opt_int = opt_int - 1;
opt_int_0 = opt_int;

% first step %

m = length(load);

load = [load; zeros(24,1)];
price = [price; zeros(24,1)];

dim_load = length(load);

idx_start = 1;
idx_end = idx_start + opt_int;

r_solved = zeros(dim_load,1); 
Z_solved = zeros(dim_load+1,1);
P_solved = 0;

q = load(idx_start:idx_end);
idx_add = 0;
% idx_sub = 0;
% idx_bonus = 0;

while sum(load((idx_end+1):(idx_end+4))) ~= 0 
    
    opt_int = opt_int + 1;
    idx_end = idx_start + opt_int;
    q = load(idx_start:idx_end);
    idx_add = idx_add + 1;
    
end

pr = price(idx_start:idx_end);
Z_0 = 0;

if sum(q)==0
    
    r_temp = zeros(length(q),1); 
    P_temp = zeros(length(q),1); 
    Z_temp = zeros(length(q)+1,1); 
    
else
      
    [r_temp, P_temp, Z_temp] = peaker_opt_v3(q,pr,d,mu,batt_price, r_cap, Z_0);
    
end

r_solved(idx_start:idx_end,1) = r_temp;
Z_solved(idx_start:(idx_end+1),1) = Z_temp(1:(opt_int+2));

if P_temp >= P_solved
    
    P_solved = P_temp;
    
end




% 2:n steps %

while idx_end < m
   
    opt_int = opt_int_0-idx_add;
    idx_start = idx_end+1;
    idx_end = idx_start + opt_int;
    
    q = load(idx_start:idx_end);
    %idx_add_old = idx_add;
    idx_add = 0;
    %idx_sub_old = idx_sub;
    %idx_sub = 0;
    %idx_bonus = 0;
    
    while sum(load((idx_end+1):(idx_end+4))) ~= 0 
    
        opt_int = opt_int + 1;
        idx_end = idx_start + opt_int;
        q = load(idx_start:idx_end);
        idx_add = idx_add + 1;
    
    end
    
    pr = price(idx_start:idx_end);
    Z_0 = Z_solved(idx_start);

    if sum(q)==0
    
        r_temp = zeros(length(q),1); 
        P_temp = 0; 
        Z_temp = zeros(length(q)+1,1); 
        
    else
        
        while sum(q(1:12))~=0
            
            idx_start = idx_start - 24;
            pr = price(idx_start:idx_end);
            Z_0 = Z_solved(idx_start);
            q = load(idx_start:idx_end);
            
        end
        
      
    [r_temp, P_temp, Z_temp] = peaker_opt_v3(q,pr,d,mu,batt_price, r_cap, Z_0);
    
    while isnan(r_temp(opt_int)) || isnan(Z_temp(opt_int+1))
        
        idx_start = idx_start - opt_int - 1;
        pr = price(idx_start:idx_end);
        Z_0 = Z_solved(idx_start);
        q = load(idx_start:idx_end);
        
        [r_temp, P_temp, Z_temp] = peaker_opt_v3(q,pr,d,mu,batt_price, r_cap, Z_0);
        
    end
    
    end
    
    r_solved(idx_start:idx_end,1) = r_temp;
    Z_solved(idx_start:(idx_end+1),1) = Z_temp; % (1:(opt_int + 2 + idx_sub + idx_bonus));
    
    if P_temp >= P_solved
    
        P_solved = P_temp;
    
    end
     
end

r_solved = r_solved(1:m,:);
Z_solved = Z_solved(1:(m+1),:);

end

