function[q_time_solved, r_time_solved, C_solved] = time_seg_v4(Z_peak, price, d, mu, r_cap, opt_int, size_MW, cycle_cost)

% perform optimization over periods
% for each period, create load time (4 hours with lowest price assigned max
% output)
% avoid opt entirely if Z_peak is non_zero (<1)

% time_opt_v4(load_time, price, d, mu, r_cap, Z_0, size_MW, cycle_cost)


% Z_peak = tZ_peak;
% price = tprice;
% d = td;
% mu = tmu;
% r_cap = tr_cap;
% opt_int = topt_int;
% size_MW = tsize_MW;
% cycle_cost = tcycle_cost;

% delete above

opt_int = opt_int - 1;
opt_int_0 = opt_int;

m = length(price);

Z_peak = [Z_peak; zeros(24,1)];
price = [price; zeros(24,1)];

dim_load = length(Z_peak);

idx_start = 1;
idx_end = idx_start + opt_int;

q_solved = zeros(dim_load,1); 
r_solved = zeros(dim_load,1); 
Z_solved = zeros(dim_load+1,1);
C_solved = 0;

r_temp = 0;
Z_temp = 0;
C_temp = 0;
q_temp = 0;
        
r_new = 0;
Z_new = 0;
C_new = 0;
q_new = 0;

max_load = min([r_cap, size_MW]);

% first step %

C_temp = -1;
C_new = 0;
load_quant = 0;

pr = price(idx_start:idx_end);

if (max(pr)*max_load - min(pr)*max_load/(mu^2)) <= cycle_cost * (max_load / (size_MW * d)) || sum(Z_peak(idx_start:idx_end)) ~= 0
    
    
else
    
    q_new = zeros(length(pr),1);
    r_new = zeros(length(pr),1);
    Z_new = zeros(length(pr)+1,1);
    C_new = 0;
    
    while C_new > C_temp
    
        r_temp = r_new;
        Z_temp = Z_new;
        C_temp = C_new;
        q_temp = q_new;
        
        load_quant = load_quant + 1;
        [pr_max, pr_idx] = maxk(pr, load_quant);
        q_new = zeros(length(pr),1);
        q_new(pr_idx) = max_load;
        
        Z_0 = 0; % change this for 2:n runs
        
        [r_new, Z_new, C_new] = time_opt_v4(q_new, pr, d, mu, r_cap, Z_0, size_MW, cycle_cost);
        
        C_new = C_new(end);
        
    end
    
    q_solved(idx_start:idx_end) = q_temp;
    r_solved(idx_start:idx_end) = r_temp;
    Z_solved(idx_start:idx_end + 1) = Z_temp;
    C_solved = C_temp;
    
end



% 2:n %

while idx_end < m

    C_temp = -1;
    C_new = 0;
    load_quant = 0;
    Z_check = NaN;
    idx_bump = 0;

    idx_start = idx_end + 1;
    idx_end = idx_start + opt_int;

    pr = price(idx_start:idx_end);

    if (max(pr)*max_load - min(pr)*max_load/(mu^2)) <= cycle_cost * (max_load / (size_MW * d)) || sum(Z_peak(idx_start:idx_end)) ~= 0
    
    
    else
        
        while isnan(Z_check)
    
            idx_start = idx_start - idx_bump;
            pr = price(idx_start:idx_end);
            
            q_new = zeros(length(pr),1);
            r_new = zeros(length(pr),1);
            Z_new = zeros(length(pr)+1,1);
            C_new = 0;
    
            while C_new > C_temp
    
                q_temp = q_new;
                r_temp = r_new;
                Z_temp = Z_new;
                C_temp = C_new;
        
                load_quant = load_quant + 1;
                [pr_max, pr_idx] = maxk(pr, load_quant);
                q_new = zeros(length(pr),1);
                q_new(pr_idx) = max_load;
        
                Z_0 = Z_peak(idx_start); 
        
                [r_new, Z_new, C_new] = time_opt_v4(q_new, pr, d, mu, r_cap, Z_0, size_MW, cycle_cost);
            
                C_new = C_new(end);
                Z_check = Z_temp(end);
        
            end
            
            idx_bump = idx_bump + opt_int + 1;
        
        end
    
        q_solved(idx_start:idx_end) = q_temp;
        r_solved(idx_start:idx_end) = r_temp;
        Z_solved(idx_start:idx_end + 1) = Z_temp;
        C_solved = C_temp;
    
    end

end

q_time_solved = q_solved(1:m);
r_time_solved = r_solved(1:m);
Z_time_solved = Z_solved(1:m+1);
    
end

