#------------------------------------------------------------------------------
# Notes #
#------------------------------------------------------------------------------

# v4 (11/25/21): jason adding code for other pollutants

# v5 (11/29/21): compatability with func.li.bess

#------------------------------------------------------------------------------
# Clear, Library, Directory, and Reading #
#------------------------------------------------------------------------------

# rm(list = ls()) # remove for final version

library(boot)
library(udunits2)

this_directory = "/Users/jasonporzio/Documents/Shell Research/peaker replacement/cost_model_upload/supp_func" ###put filepath to your folder 'R_LCA' here
# setwd(this_directory)

source(file.path(this_directory, 
                 "unit_conversions_and_mw/energy_content_fuels.R"))
#
io.table <- read.csv(file.path(this_directory,
                               "io_tables_2/io_table_physical.csv"), header = TRUE, row.names = 1) 

io_filepath = file.path(this_directory,"io_tables_2/io_table_physical.csv")
## add your own CSV file to folder and replace io_table here ^ 
## check file R_LCA -> io_tables -> io_table_physical.csv for reference for what it should look like

#------------------------------------------------------------------------------
# General Functions #
#------------------------------------------------------------------------------

TableSetup <- function(filepath) {
  # Reads in csv file, sets header and row names, deletes column with row names
  #
  # Args:
  # filepath: path to table (csv file)
  #
  # Returns:
  #  The prepared table for further calculations (a data frame)
  table <- read.csv(filepath, header = T, row.names = 1)
  return(table)
}


YSetUp <- function(filepath) {
  # Reads in csv file, uses row names and dimensions to create y vector
  #
  # Args:
  # filepath: path to table (csv file)
  #
  # Returns:
  # The prepared y vector including row names, populated with zeros
  io.table <- TableSetup(filepath)
  num.sectors <- dim(io.table)[1]
  y <- data.frame(matrix(0, ncol = 1, nrow = num.sectors))
  row.names(y) <- row.names(io.table)
  colnames(y) <- c("y")
  return(y)
}


IOTableSetup <- function(filepath) {
  # Computes the table A, which contains dollar-based input-output ratios for 
  # all relevant "sectors" as defined in this project
  # Can also be used to import physical units-based input-output table
  #
  # Args:
  #  filepath: path to IO table csv file
  #  
  #  Returns:
  #   The IO table 'A' ready for further calculations
  A <- data.matrix(TableSetup(filepath), rownames.force = NA)
  A <- t(A)  # Need to take transpose for calculation.
  return(A)
}


IOSolutionPhysicalUnits <- function(A, y) {
  # Solves for total requirements from each sector in cost
  #
  # Args:
  #  A: input-output vector
  #  y: direct requirements vector
  # 
  # Returns:
  #  The total (direct + indirect) monetary requirements by sector
  #
  # Makes sure that y is a matrix. Won't solve if y has become a dataframe
  y <- as.matrix(y)
  #
  num.sectors <- dim(A)[1]
  I <- diag(num.sectors)
  solution <- solve((I - A), y)
  return(solution)
}


#------------------------------------------------------------------------------
# GHG Functions #
#------------------------------------------------------------------------------


GHGImpactVectorSum <- function(co2.filepath, ch4.filepath, n2o.filepath, 
                               time.horizon) {
  # Computes an impact vector equal to the total kg co2 equivalents per physical 
  # output unit for each sector
  #
  # Args:
  #  co2.filepath: csv file path for co2 impact vector (kg/physical output unit)
  #  ch4.filepath: csv file path for ch4 impact vector (kg/physical output unit)
  #  n2o.filepath: csv file path for n2o impact vector (kg/physical output unit)
  #  time.horizon: number of years used for time horizon of IPCC factors - 
  #   default is 100 years, can also to 20
  # Returns:
  #  The total kg co2e/dollar for each sector in a vector form
  filepaths <- c(co2.filepath, ch4.filepath, n2o.filepath)
  # IPCC 100-year multipliers for different GHGs to normalize to CO2e
  ipcc.ch4.100 <- 28  
  ipcc.ch4.20 <- 72 
  ipcc.n2o.100 <- 298  
  ipcc.n2o.20 <- 289
  ipcc.multipliers <- c(1, 
                        get(paste("ipcc.ch4.", 
                                  as.character(time.horizon), sep = "")), 
                        get(paste("ipcc.n2o.", 
                                  as.character(time.horizon), sep = "")))  
  ghg.total.kg <- 0
  for(x in 1:3) {
    ghg.total.kg <- ghg.total.kg + TableSetup(filepaths[x]) * 
      ipcc.multipliers[x]
  }
  return(ghg.total.kg)
}


TotalGHGEmissions <- function(A, y, co2.filepath, 
                              ch4.filepath, n2o.filepath, 
                              time.horizon) {
  # Returns a vector of of all GHG emissions in the form of kg CO2e
  #
  # Args:
  #  A: input-output vector in dollar ratios
  #  y: direct requirements vector in dollars
  #  co2.filepath: filepath to csv file containing kg CO2/kg output for 
  #   each sector
  #  ch4.filepath: filepath to csv file containing kg CH4/kg output for 
  #   each sector
  #  n2o.filepath: filepath to csv file containing kg N2O/kg output for 
  #   each sector
  #  time.horizon: number of years used for time horizon of normalized GHG 
  #   forcing
  #  biorefinery.direct.ghg: kg fossil CO2e emitted directly at the biorefinery
  #  combustion.direct.ghg: kg fossil CO2e emitted during product combustion/
  #   end-of-life.  Only applicable where some fossil carbon is in product
  #   or there is net biogenic carbon sequestration
  # Returns:
  #  The net GHG emissions (kg CO2e) for the product life cycle by sector
  #
  # Makes sure that y is a matrix. Won't solve if y has become a dataframe
  y <- as.matrix(y)
  #
  io.ghg.results.kg <- IOSolutionPhysicalUnits(A, y) * 
                                                GHGImpactVectorSum(co2.filepath, 
                                                ch4.filepath, 
                                                n2o.filepath, 
                                                time.horizon)
  return(io.ghg.results.kg)
}


#------------------------------------------------------------------------------
# CO Function #
#------------------------------------------------------------------------------


COEmissions <- function(A, y, co.filepath) {
  # Returns a vector of of all GHG emissions in the form of kg CO
  #
  # Args:
  #  A: input-output vector in dollar ratios
  #  y: direct requirements vector in dollars
  #  co.filepath: filepath to csv file containing kg CO/kg output for
  #   each sector
  # Returns:
  #  The net GHG emissions (kg CO) for the product life cycle by sector
  #
  # Makes sure that y is a matrix. Won't solve if y has become a dataframe
  y <- as.matrix(y)
  #
  io.co.results.kg <- IOSolutionPhysicalUnits(A, y) * TableSetup(co.filepath)
  return(io.co.results.kg)
}


#------------------------------------------------------------------------------
# NOX Function #
#------------------------------------------------------------------------------


NOXEmissions <- function(A, y, nox.filepath) {
  # Returns a vector of of all GHG emissions in the form of kg nox
  #
  # Args:
  #  A: input-output vector in dollar ratios
  #  y: direct requirements vector in dollars
  #  nox.filepath: filepath to csv file containing kg nox/kg output for
  #   each sector
  # Returns:
  #  The net GHG emissions (kg CO) for the product life cycle by sector
  #
  # Makes sure that y is a matrix. Won't solve if y has become a dataframe
  y <- as.matrix(y)
  #
  io.nox.results.kg <- IOSolutionPhysicalUnits(A, y) * TableSetup(nox.filepath)
  return(io.nox.results.kg)
}

#------------------------------------------------------------------------------
# SOX Function #
#------------------------------------------------------------------------------


SOXEmissions <- function(A, y, sox.filepath) {
  # Returns a vector of of all GHG emissions in the form of kg sox
  #
  # Args:
  #  A: input-output vector in dollar ratios
  #  y: direct requirements vector in dollars
  #  sox.filepath: filepath to csv file containing kg sox/kg output for
  #   each sector
  # Returns:
  #  The net GHG emissions (kg sox) for the product life cycle by sector
  #
  # Makes sure that y is a matrix. Won't solve if y has become a dataframe
  y <- as.matrix(y)
  #
  io.sox.results.kg <- IOSolutionPhysicalUnits(A, y) * TableSetup(sox.filepath)
  return(io.sox.results.kg)
}

#------------------------------------------------------------------------------
# PM25 Function #
#------------------------------------------------------------------------------


PM25Emissions <- function(A, y, pm25.filepath) {
  # Returns a vector of of all GHG emissions in the form of kg pm25
  #
  # Args:
  #  A: input-output vector in dollar ratios
  #  y: direct requirements vector in dollars
  #  pm25.filepath: filepath to csv file containing kg pm25/kg output for
  #   each sector
  # Returns:
  #  The net GHG emissions (kg pm25) for the product life cycle by sector
  #
  # Makes sure that y is a matrix. Won't solve if y has become a dataframe
  y <- as.matrix(y)
  #
  io.pm25.results.kg <- IOSolutionPhysicalUnits(A, y) * TableSetup(pm25.filepath)
  return(io.pm25.results.kg)
}

#------------------------------------------------------------------------------
# VOC Function #
#------------------------------------------------------------------------------


VOCEmissions <- function(A, y, voc.filepath) {
  # Returns a vector of of all GHG emissions in the form of kg VOC
  #
  # Args:
  #  A: input-output vector in dollar ratios
  #  y: direct requirements vector in dollars
  #  voc.filepath: filepath to csv file containing kg VOC/kg output for
  #   each sector
  # Returns:
  #  The net GHG emissions (kg VOC) for the product life cycle by sector
  #
  # Makes sure that y is a matrix. Won't solve if y has become a dataframe
  y <- as.matrix(y)
  #
  io.co.results.kg <- IOSolutionPhysicalUnits(A, y) * TableSetup(voc.filepath)
  return(io.co.results.kg)
}
