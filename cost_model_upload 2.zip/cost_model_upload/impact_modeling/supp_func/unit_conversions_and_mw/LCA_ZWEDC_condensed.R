#### Config ####

#Define CO2EQ GWP IPCC Constants

ipcc.ch4.100 <- 28 
ipcc.n2o.100 <- 298

#Read in filepaths for emissions calculations

co2.filepath <- CO2VectorFilepath()
ch4.filepath <- CH4VectorFilepath()
n2o.filepath <- N2OVectorFilepath()
nox.filepath <- NOXVectorFilepath()
pm25.filepath <- PM25VectorFilepath()
co.filepath <- COVectorFilepath()
h2s.filepath <- H2SVectorFilepath()
nh3.filepath <- NH3VectorFilepath()
bc.filepath <- BCVectorFilepath()
voc.filepath <- VOCVectorFilepath()
so2.filepath <- SO2VectorFilepath()
h2s.filepath <- H2SVectorFilepath()
so2.filepath <- SO2VectorFilepath()
voc.filepath <- VOCVectorFilepath()

# Facility Direct Emissions Assumptions

facility.lifetime <- 20 #years
lifecycle.scalar <- facility.lifetime *365 / length(btb.df$Date)

#Scenario and results dataframe setup

cases <- c('bau', 'digestate.landfill', 'digestate.fertilizer', 'cng.onsite', 'cng.pipeline')
results.total.list <- c()
aggregated.results.total.list <- c()
aggregated.results.total.graph.list <- c()
trucking.results <- data.frame()
#Begin loop for each scenarios

  for(scenario in 1:length(cases)) {

    functional.unit <- 'kg.per.ton.accepted' # 'kg.per.kWh.produced' or 'kg.per.ton.accepted'
    zwedc.case <- cases[scenario]
    biogas.density.kg.per.cu.m <- 1.15

#I-O and Y Setup
    
A <- IOTableSetup(IOTableFilepath())
y <- YSetUp(co2.filepath)
cost <- TableSetup(co2.filepath)
time.horizon <- 100

##### Process Calculations and Y Definition

#All Scenarios:
#'bau', 'digestate.landfill', 'digestate.fertilizer', 'cng.onsite', 'cng.pipeline'

##### BIOFILTER RELEASE ----

#assumes 0.1% total venting factor: biofilter 0.075% venting and bladder vent 0.025%
#uses facility data on biogas cu_m, % composition to calculate venting emissions
#assumes biogas feedstock composition is equivalent to venting emissions
biofilter.venting.factor <- 0.00075

#Add Biofilter to Y
y['biogas_biofilter.m3','y'] <- sum(btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m, na.rm=T) * biofilter.venting.factor #m3

##### TRUCKING ----



#Calculates varying total trucking distances per scenario
#first compile tonnage data
all.tonnage.daily <- rbind(tonnage.by.location.daily, outbound.tonnage.by.location.daily)

id <- all.tonnage.daily$Var1[all.tonnage.daily$Var2 == 'republic']
tonnage.daily <- dcast(all.tonnage.daily, id~all.tonnage.daily$Var2, fun.aggregate = sum, value.var = "value")
tonnage.daily <- tonnage.daily %>%
  mutate(total = republic + paloalto + sanjose + smartstation + zbest + losaltoshills)

colnames(tonnage.daily)[1] <- 'Date'
tonnage.daily$zbest[tonnage.daily$Date < '2016-02-07'] <- 
  tonnage.daily$total[tonnage.daily$Date < '2016-02-07']*
  mean((tonnage.daily$zbest[tonnage.daily$Date > '2016-02-07']/
          tonnage.daily$total[tonnage.daily$Date > '2016-02-07'])[is.finite(tonnage.daily$zbest[tonnage.daily$Date > '2016-02-07']/
                                                                              tonnage.daily$total[tonnage.daily$Date > '2016-02-07'])]) #0.35625 average post 2016-02-07
#incorporate tonnage data to fill trucking data
distance.zbest.km <- 45 * ud.convert(1,'mi','km')
id <- tonne.km.by.location.daily$Var1[tonne.km.by.location.daily$Var2 == 'republic']
tonne.km.daily <- dcast(tonne.km.by.location.daily, id~tonne.km.by.location.daily$Var2,fun.aggregate = sum, value.var = "value")
tonne.km.daily$zbest[tonne.km.daily$Date > '2016-02-07'] <- tonnage.daily$zbest[tonnage.daily$Date > '2016-02-07']*ud.convert(1,'ton','tonne')*distance.zbest.km

if (zwedc.case == 'digestate.landfill') {
  #replaces outbound trucking distances with new landfill location in metrictonne.km
  #calculation for newby landfill tonne km
  newby.distance <- 8 * ud.convert(1,'mi','km') # km to newby landfill
  tonne.km.daily$zbest[tonne.km.daily$id > '2016-02-07'] <- tonnage.daily$zbest[tonnage.daily$Date > '2016-02-07']*ud.convert(1,'ton','tonne')*newby.distance
} else if (zwedc.case == 'digestate.fertilizer'){
  #replaces outbound trucking distances with new landfill location and farm distance in metrictonne.km
  #calculation for landfill and farm tonne km
  newby.distance <- 8 * ud.convert(1,'mi','km') # km to newby landfill
  farm.distance <- 32.3 * ud.convert(1,'mi','km') # km to gilroy
  
  #winter landfilled digestate
  #October to April digestate is landfilled   
  #otherwise fertilizer at farm for summer months
  tonne.km.daily$zbest <- ifelse(test = tonnage.daily$Date > "2014-10-01" & tonnage.daily$Date < "2015-04-01" | 
                                   tonnage.daily$Date > "2015-10-01" & tonnage.daily$Date > "2016-04-01" |
                                   tonnage.daily$Date > "2016-10-01" & tonnage.daily$Date < "2017-04-01" |
                                   tonnage.daily$Date > "2017-10-01" & tonnage.daily$Date < "2018-04-01",
                                 tonnage.daily$zbest*ud.convert(1,'ton','tonne')*newby.distance,
                                 tonnage.daily$zbest*ud.convert(1,'ton','tonne')*farm.distance)
} else if (zwedc.case == 'cng.onsite' |
           zwedc.case == 'cng.pipeline') {
  tonne.km.daily$zbest[tonne.km.daily$id > "2014-10-01"] <- tonnage.daily$zbest[tonnage.daily$Date > "2014-10-01"]*ud.convert(1,'ton','tonne')*farm.distance
}

tonne.km.by.location.daily.2 <- tonne.km.daily %>%
  transmute(Date = id,
            value = republic + paloalto + sanjose + smartstation + zbest + losaltoshills)

# Add Trucking to Y 
y["flatbedtruck.mt_km", "y"] <- sum(tonne.km.by.location.daily.2$value, na.rm = T)  #mt.km
farts <- data.frame(cases[scenario],y["flatbedtruck.mt_km", "y"])
trucking.results <- rbind(trucking.results, farts)

##### LANDFILL -----

# binds inbound and outbound tonnage data and varies data relative to scenario definitions. 

daily.landfill <- tonnage.daily %>%
  select(Date, zbest)
colnames(daily.landfill) <- c('Date', 'value')
daily.landfill$variable <- 'Daily Landfill'
daily.landfill$value <- daily.landfill$value*ud.convert(1,'ton','kg')

if (zwedc.case == 'bau' |
    zwedc.case == 'cng.onsite' |
    zwedc.case == 'cng.pipeline') {
  daily.landfill$value <- -daily.landfill$value
}
if (zwedc.case == 'digestate.landfill') {
  daily.landfill$value <- daily.landfill$value
}
if (zwedc.case == 'digestate.fertilizer') {
  #winter landfilled digestate
  #October to April digestate is landfilled each year
  #Otherwise in summer, digestate is land applied, and landfill becomes credit
  daily.landfill$value <- ifelse(test = daily.landfill$Date > "2014-10-01" & daily.landfill$Date < "2015-04-01" | 
                                   daily.landfill$Date > "2015-10-01" & daily.landfill$Date > "2016-04-01" |
                                   daily.landfill$Date > "2016-10-01" & daily.landfill$Date < "2017-04-01" |
                                   daily.landfill$Date > "2017-10-01" & daily.landfill$Date < "2018-04-01",
                                 daily.landfill$value,
                                 -daily.landfill$value)
}

#Add Landfill to Y
y["landfill_mixedorganics.wet_kg", "y"] <- sum(daily.landfill$value, na.rm = TRUE) #kg

##### Daily Electricity Consumption ----

#Add Daily Electricity Consumption to Y
y["electricity.NGCC.kWh", "y"] <- sum(rep(3773, times = length(btb.df$Date))) #kWh

##### FLARE ----
#100% flare for bau, fertilizer, landfill scenarios
#50% flare for cng scenarios
#Add Biogas Flare to Y

if (zwedc.case == 'bau' |
    zwedc.case == 'digestate.fertilizer' |
    zwedc.case == 'digestate.landfill') {
  y['biogas_flare.m3','y'] <- sum(btb.df$Flare_Gas_Daily_Amount_cu_m, na.rm = T)#m3
} else {
  y['biogas_flare.m3','y'] <- sum(btb.df$Flare_Gas_Daily_Amount_cu_m, na.rm = T)*0.5 #m3
}
##### CHP and NGCC OFFSET =====
#emissions from biogas combustion at CHP
#missing data from prior to April 2016 for biogas consumption
#use average ratio between consumption and power production after April 2016 to estimate missing data prior

if (zwedc.case == 'bau' |
    zwedc.case == 'digestate.fertilizer' |
    zwedc.case == 'digestate.landfill') {

  btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m[btb.df$Date < '2016-04-21'] <- 
    btb.df$CHP_Sum_Daily_Power_Production_kWh[btb.df$Date < '2016-04-21']*
    mean((btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m[btb.df$Date > '2016-04-21']/
            btb.df$CHP_Sum_Daily_Power_Production_kWh[btb.df$Date > '2016-04-21'])[is.finite(btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m[btb.df$Date > '2016-04-21']/
                                                                                               btb.df$CHP_Sum_Daily_Power_Production_kWh[btb.df$Date > '2016-04-21'])])
  #Add Biogas to Y
  
  y['biogas_CHP.m3','y'] <- sum(btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m, na.rm = T) #m3
  y['biogas_CHP.m3','y'] <- sum(btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m, na.rm = T) #m3
  #NGCC offset
  #Added to existing Y value so that they don't overwrite
  y['electricity.NGCC.kWh','y'] <- -sum(btb.daily.electricity.output$value, na.rm = T) + sum(rep(3773, times = length(btb.df$Date))) #kWh
} 

#COMPOSTING AND COMPOST APPLICATION =====
#uses outbound tonnage (in short tons) to composting facility to calculate emissions
#prior to 2016 composting done onsite
#calculate digestate production from post 2016 to predict pre 2016 digestate production
#assume 20% mass reduction post composting for application

daily.outdoor.compost <- tonnage.daily %>%
  select(Date, zbest)
colnames(daily.outdoor.compost) <- c('Date', 'value')
daily.outdoor.compost$variable <- 'Daily Outdoor Compost'
daily.outdoor.compost$value <- daily.outdoor.compost$value*ud.convert(1,'ton','kg')

if (zwedc.case == 'bau' |
    zwedc.case == 'cng.onsite' |
    zwedc.case == 'cng.pipeline') {

y["organics_composting_wet.kg", "y"] <- sum(daily.outdoor.compost$value, na.rm = T)
y["compost_application.kg", "y"] <- sum(daily.outdoor.compost$value, na.rm = T)*0.8 #20% mass reduction 
} else {
  y["organics_composting_wet.kg", "y"] <- -sum(daily.outdoor.compost$value, na.rm = T)
  y["compost_application.kg", "y"] <- -sum(daily.outdoor.compost$value, na.rm = T)*0.8 #20% mass reduction 
}

#DIGESTATE LAND APPLICATION

if (zwedc.case == 'digestate.fertilizer') {
  
  #summer months land application quantity
  daily.digestate.app <- tonnage.daily %>%
    select(Date, zbest)
  colnames(daily.digestate.app) <- c('Date', 'value')
  daily.digestate.app$variable <- 'Daily Digestate Application'
  daily.digestate.app$value <- daily.digestate.app$value*ud.convert(1,'ton','kg')
  daily.digestate.app$value <- ifelse(test = daily.digestate.app$Date > btb.df$Date[1] & daily.digestate.app$Date < "2014-10-01" | 
                                        daily.digestate.app$Date > "2015-04-01" & daily.digestate.app$Date < "2015-10-01" |
                                        daily.digestate.app$Date > "2016-04-01" & daily.digestate.app$Date < "2016-10-01" |
                                        daily.digestate.app$Date > "2017-04-01" & daily.digestate.app$Date < "2017-10-01" |
                                        daily.digestate.app$Date > "2018-04-01" & daily.digestate.app$Date < btb.df$Date[length(btb.df$Date)],
                                      daily.digestate.app$value,
                                      0)
  #Add digestate application to Y
  y["biosolids_land_application_dry.kg", "y"] <- sum(daily.digestate.app$value, na.rm = T) #kg
  
}
#UREA FERTILIZER CREDIT =====

daily.fertilizer <- tonnage.daily %>%
  select(Date, zbest)
colnames(daily.fertilizer) <- c('Date', 'value')
daily.fertilizer$variable <- 'Daily Fertilizer'
daily.fertilizer$value <- daily.fertilizer$value*ud.convert(1,'ton','kg')

if (zwedc.case == 'digestate.fertilizer'){
  #summer months fertilizer credit
  #assumes N:N compost:urea ratio of 1 : 0.19
  daily.fertilizer$value <- ifelse(test = daily.fertilizer$Date > btb.df$Date[1] & daily.fertilizer$Date < "2014-10-01" | 
                                     daily.fertilizer$Date > "2015-04-01" & daily.fertilizer$Date < "2015-10-01" |
                                     daily.fertilizer$Date > "2016-04-01" & daily.fertilizer$Date < "2016-10-01" |
                                     daily.fertilizer$Date > "2017-04-01" & daily.fertilizer$Date < "2017-10-01" |
                                     daily.fertilizer$Date > "2018-04-01" & daily.fertilizer$Date < btb.df$Date[length(btb.df$Date)],
                                   daily.fertilizer$value,
                                   0)
  #Add fertilizer credit to Y
  y["urea.kg", "y"] <- -sum(daily.fertilizer$value, na.rm = T)*.19
  } else if (zwedc.case == 'bau' |
           zwedc.case == 'cng.onsite' |
           zwedc.case == 'cng.pipeline') {
    #fertilizer offset for compost application
    #assumes 20% mass reduction and N:N compost:urea ratio of 1 : 0.19
    #Add fertilizer credit to Y
  y["urea.kg", "y"] <- -sum(daily.fertilizer$value, na.rm = T)*.8*.19
} 

#CNG UPGRADE ELECTRICITY EMISSIONS =====
#electricity consumption for raw biogas separation + clean biogas enhancement
# 0.18 kWh/Nm3 raw biogas
# 0.14 kWh/Nm3 clean biogas

if (zwedc.case == 'cng.onsite' |
    zwedc.case == 'cng.pipeline') {
  #Add Upgrade Electricity to existing Y
  y["electricity.NGCC.kWh", "y"] <-
    sum(rep(3773, times = length(btb.df$Date))) + #kWh 
  sum(btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m, na.rm=T)*0.18 + # 0.18 kWh/Nm3 raw biogas
 sum(btb.df$Total_CNG_m3_perday, na.rm = T)*0.14 # 0.14 kWh/Nm3 clean biogas
}

#CNG ONSITE DIESEL OFFSET =====
#Add diesel offset to Y
if (zwedc.case == 'cng.onsite') {
  y["diesel.MJ", "y"] <- sum(-FuelConvertMJ(btb.df$Total_CNG_m3_perday,'diesel','liter'),na.rm = T) #MJ
}

#CNG PIPELINE NATURAL GAS OFFSET =====
#Add natural gas offset to Y
if (zwedc.case == 'cng.pipeline') {
  y["naturalgas.MJ", "y"] <- sum(-FuelConvertMJ(btb.df$Total_CNG_m3_perday,'naturalgas','m3'), na.rm = T) #MJ
}

#BLADDER VENTING =====
#Y vector not used - added directly to results below
#assumes 0.1% total venting factor, biofilter 0.075% venting and bladder vent 0.025%
#uses facility data on biogas cu_m, % composition to calculate venting emissions
#assumes biogas feedstock composition is equivalent to venting emissions
#assumes 50:50 split biogas consumption between two modules prior to 2016 missing data

btb.df$CHP_1_Daily_Gas_Consumption_cu_m[btb.df$Date < '2016-04-21'] <- (btb.df$CHP_Sum_Daily_Power_Production_kWh[btb.df$Date < '2016-04-21']*0.5)*
  mean((btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m[btb.df$Date > '2016-04-21']/
          btb.df$CHP_Sum_Daily_Power_Production_kWh[btb.df$Date > '2016-04-21'])[is.finite(btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m[btb.df$Date > '2016-04-21']/
                                                                                             btb.df$CHP_Sum_Daily_Power_Production_kWh[btb.df$Date > '2016-04-21'])])

btb.df$CHP_2_Daily_Gas_Consumption_cu_m[btb.df$Date < '2016-04-21'] <- (btb.df$CHP_Sum_Daily_Power_Production_kWh[btb.df$Date < '2016-04-21']*0.5)*
  mean((btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m[btb.df$Date > '2016-04-21']/
          btb.df$CHP_Sum_Daily_Power_Production_kWh[btb.df$Date > '2016-04-21'])[is.finite(btb.df$CHP_Sum_Daily_Gas_Consumption_cu_m[btb.df$Date > '2016-04-21']/
                                                                                             btb.df$CHP_Sum_Daily_Power_Production_kWh[btb.df$Date > '2016-04-21'])])

bladder.venting.factor <- 0.00025

#CNG ONSITE CH4 LOSS =====
#Y vector not used - added directly to results below
#0.6% loss during cng upgrading
#95% methane content of upgraded cng

ch4.loss.factor <- 0.006
cng.methane.ratio <- 0.95

#Normalization Factor ----

normalization.factor <- sum(tonnage.by.location.daily$value, na.rm = T)

y[,"y"] <- y[,"y"] / normalization.factor

# RESULTS ----

# Create separate vector with only negative values and zero out negative values
#    in original y vector to ensure math works out for I-O
y1 <- y
y1[y1>0] <- 0
y1 <- abs(y1)
y[y<0] <- 0

results.total.kg <- data.frame()
aggregated.results.total.kg <- data.frame()
aggregated.results.total.graph.kg <- data.frame()

#co2eq

results.kg.co2eq <- TotalGHGEmissions(A, data.matrix(y, rownames.force = NA),
                                      co2.filepath,
                                      ch4.filepath, n2o.filepath,
                                      time.horizon)
results.kg.co2eq.credits <- TotalGHGEmissions(A, data.matrix(y1, rownames.force = NA),
                                              co2.filepath,
                                              ch4.filepath, n2o.filepath,
                                              time.horizon)
results.kg.co2eq <- results.kg.co2eq - results.kg.co2eq.credits # Subtract off credits

# BLADDER ----

bladder.co2 <- (btb.df$Module_1_CO2_Percent*btb.df$CHP_1_Daily_Gas_Consumption_cu_m/100 + btb.df$Module_2_CO2_Percent*btb.df$CHP_2_Daily_Gas_Consumption_cu_m/100)
bladder.ch4 <- (btb.df$Module_1_CH4_Percent*btb.df$CHP_1_Daily_Gas_Consumption_cu_m/100 + btb.df$Module_2_CH4_Percent*btb.df$CHP_2_Daily_Gas_Consumption_cu_m/100)
bladder <- (sum(bladder.co2, na.rm = T) + (sum(bladder.ch4, na.rm = T)*ipcc.ch4.100))*bladder.venting.factor*biogas.density.kg.per.cu.m*lifecycle.scalar/normalization.factor

if (zwedc.case == 'cng.pipeline' |
    zwedc.case == 'cng.onsite') {
  bladder <- bladder*0.5 #assumed 50% bladder release 
  
# CNG LOSS ----
  cng.loss <- sum(btb.df$Total_CNG_m3_perday, na.rm = T)*biogas.density.kg.per.cu.m*ch4.loss.factor*cng.methane.ratio*ipcc.ch4.100*lifecycle.scalar/normalization.factor
  rownames <- row.names(results.kg.co2eq)
  results.kg.co2eq <-  rbind(results.kg.co2eq, cng.loss)
  rownames <- append(rownames, c("CNG Loss"))
  row.names(results.kg.co2eq) <- rownames
}
rownames <- row.names(results.kg.co2eq)
results.kg.co2eq <-  rbind(results.kg.co2eq, bladder)
rownames <- append(rownames, c("Bladder"))
row.names(results.kg.co2eq) <- rownames

results.kg.co2eq$emission <- 'co2eq'

results.total.kg <- results.kg.co2eq

LCA.results.aggregation.ZWEDC <- read.csv(LCAResultsAggregationGuideZWEDC(), header=T)
rownames(LCA.results.aggregation.ZWEDC) <- LCA.results.aggregation.ZWEDC$Contributors
aggregated.results.co2eq <- ResultsAggregationZWEDC(results.kg.co2eq, 'r', LCA.results.aggregation.ZWEDC)
aggregated.results.co2eq$emission <- 'co2eq'
aggregated.results.co2eq <- filter(aggregated.results.co2eq, !is.na(r))
aggregated.results.total.kg <- aggregated.results.co2eq

aggregated.results.co2eq.graph <- data.frame(Contributors = 'Other',
                                             r = 0, RGB = 'slategray2')
temp <- aggregated.results.co2eq
for(i in 1:nrow(aggregated.results.co2eq)) {
  if (abs(temp$r[i]) < (0.01*sum(abs(temp$r), na.rm = T))) {
    aggregated.results.co2eq.graph$r <- sum(aggregated.results.co2eq.graph$r[1], temp$r[i], na.rm = T)
    temp$r[i] <- NA
  }
}
aggregated.results.co2eq.graph$emission <- 'co2eq'
aggregated.results.co2eq.graph <- rbind(aggregated.results.co2eq.graph, temp)
aggregated.results.co2eq.graph <- filter(aggregated.results.co2eq.graph, !is.na(r))
aggregated.results.total.graph.kg <- aggregated.results.co2eq.graph

# 'co','bc','nh3','nox','pm25','so2','voc','h2s'

results.emissions <- c('co','bc','nh3','nox','pm25','so2','voc','h2s')

emissions.filepaths <- c(co.filepath, bc.filepath, nh3.filepath, nox.filepath, pm25.filepath,
               so2.filepath, voc.filepath, h2s.filepath)

for (h in 1:length(results.emissions)) {
  results.df <- TotalEmissions(A, data.matrix(y, rownames.force = NA), emissions.filepaths[h])
  results.credits.df <- TotalEmissions(A, data.matrix(y1, rownames.force = NA), emissions.filepaths[h])
  results.df <- results.df - results.credits.df
  
  if (results.emissions[h] == 'h2s') {
    bladder.h2s <- sum((btb.df$Module_1_H2S_Percent*btb.df$Module_1_H2S_ppm/1E6 +
       btb.df$Module_2_H2s_Percent*btb.df$Module_2_H2S_ppm/1E6), na.rm = T)*
      bladder.venting.factor*
      biogas.density.kg.per.cu.m
    if (zwedc.case == 'cng.pipeline' |
        zwedc.case == 'cng.onsite') {
    bladder.h2s <- bladder.h2s*0.5
      }
    rownames <- row.names(results.df)
    results.df <-  rbind(results.df, bladder.h2s)
    rownames <- append(rownames, c("Bladder"))
    row.names(results.df) <- rownames
  }
  
  results.df$emission <- results.emissions[h]
  results.total.kg <- rbind(results.total.kg, results.df) 
  
  aggregated.results.df <- ResultsAggregationZWEDC(results.df, 'r', LCA.results.aggregation.ZWEDC)
  aggregated.results.df$Contributors <- row.names(aggregated.results.df)
  aggregated.results.df <- filter(aggregated.results.df, !is.na(r))
  aggregated.results.df$emission <- results.emissions[h]
  aggregated.results.total.kg <- rbind(aggregated.results.total.kg, aggregated.results.df)
  
  aggregated.results.graph.df <- data.frame(Contributors = 'Other',
                                               r = 0, RGB = 'slategray2')
  temp <- aggregated.results.df
  for(i in 1:nrow(aggregated.results.df)) {
    if (abs(temp$r[i]) < (0.01*sum(abs(temp$r), na.rm = T))) {
      aggregated.results.graph.df$r <- sum(aggregated.results.graph.df$r[1], temp$r[i], na.rm = T)
      temp$r[i] <- NA
    }
  }
  aggregated.results.graph.df$emission <- results.emissions[h]
  aggregated.results.graph.df <- rbind(aggregated.results.graph.df, temp)
  aggregated.results.graph.df <- filter(aggregated.results.graph.df, !is.na(r))
  aggregated.results.total.graph.kg <- rbind(aggregated.results.total.graph.kg, aggregated.results.graph.df)
}
results.total.kg$scenario <- zwedc.case
aggregated.results.total.kg$scenario <- zwedc.case
aggregated.results.total.graph.kg$scenario <- zwedc.case

results.total.list[[scenario]] <- results.total.kg
aggregated.results.total.list[[scenario]] <- aggregated.results.total.kg
aggregated.results.total.graph.list[[scenario]] <- aggregated.results.total.graph.kg 
} #end first loop here


complete.results <- data.frame()
complete.aggregated.results <- data.frame()
complete.aggregated.results.graph <- data.frame()

for (i in 1:length(results.total.list)) {
  complete.results <- rbind(complete.results, results.total.list[[i]])
  complete.aggregated.results <- rbind(complete.aggregated.results, aggregated.results.total.list[[i]])
  complete.aggregated.results.graph <- rbind(complete.aggregated.results.graph, aggregated.results.total.graph.list[[i]])
}
results.filepath <- paste(this.dir.zwedc.model,'/results/',functional.unit,sep='')

write.csv(complete.results, file.path(results.filepath, paste('/complete.results.csv', sep = '')))
write.csv(complete.aggregated.results, file.path(results.filepath, paste('/aggregated.results.total.csv', sep = '')))

labels <- c("Business as Usual","RNG Onsite","RNG Pipeline","Digestate Land Applied","Digestate Landfilled")

if(functional.unit == 'kg.per.kWh.produced') {
  stackguide <- read.csv('stack_graph_guide_kWh.csv')
} else if (functional.unit == 'kg.per.ton.accepted') {
  stackguide <- read.csv('stack_graph_guide_ton.csv')
}

plot.filepath <- paste(this.dir.zwedc.model,'/plots/',functional.unit,sep='')

cbPalette <- rep(c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7"), 3)



plot_list <- list()
complete.aggregated.results.graph <- filter(complete.aggregated.results.graph, r != 0)
for (z in 1:nrow(stackguide))  {
  temp <- filter(complete.aggregated.results.graph, complete.aggregated.results.graph$emission == stackguide$emission[z])
  RGB <- temp$RGB
  p <- ggplot(temp) +
    geom_col(mapping = aes(x = scenario, y = r, fill = Contributors),
             position = 'stack') +
    stat_summary_bin(fun.y = sum, mapping = aes(x = scenario, y = r), color = 'black', na.rm = TRUE, geom ='col', fill = NA, linetype = 'dashed') +
    #scale_fill_hue() +
    scale_fill_hue() +
    scale_x_discrete(breaks = waiver(), labels=labels) +
    ggtitle(stackguide$title[z]) +
    ylab(stackguide$ylab[z]) +
    xlab('Scenario') +
    theme_classic() +
    theme(plot.title = element_text(hjust = 0.5)) +
    theme(axis.text.x=element_text(angle = 45, hjust = 1)) +
    theme(panel.grid.major = element_line(color = 'grey88'))
  
  plot_list[[z]] <- p
}

for (z in 1:nrow(stackguide)) {
  ggsave(plot_list[[z]],
         filename = paste(stackguide$emission[z],'.', functional.unit, ".jpeg", sep=""),
         path = plot.filepath,
         device = 'jpeg',
         width = 26, 
         height = 20,
         units = "cm")
}


# tonne.km.by.location.daily %>%
#   group_by(Var2) %>%
#   summarize(sum = sum(value, na.rm = T))

#### unused ####

# #summer landfill credit from fertilizer app
# #May to September digestate is fertilizer, landfill calculated as credit
# daily.landfill$value <- ifelse(test = daily.landfill$Date > btb.df$Date[1] & daily.landfill$Date < "2014-10-01" | 
#                                  daily.landfill$Date > "2015-04-01" & daily.landfill$Date < "2015-10-01" |
#                                  daily.landfill$Date > "2016-04-01" & daily.landfill$Date < "2016-10-01" |
#                                  daily.landfill$Date > "2017-04-01" & daily.landfill$Date < "2017-10-01" |
#                                  daily.landfill$Date > "2018-04-01" & daily.landfill$Date < btb.df$Date[length(btb.df$Date)],
#                                -daily.landfill$value,
#                                0)
# 

# co2_impact <- read.csv(CO2VectorFilepath(), header = T, row.names = 1)
# bc_impact <- read.csv(BCVectorFilepath(), header = T, row.names = 1)
# ch4_impact <- read.csv(CH4VectorFilepath(), header = T, row.names = 1)
# co_impact <- read.csv(COVectorFilepath(), header = T, row.names = 1)
# n2o_impact <- read.csv(N2OVectorFilepath(), header = T, row.names = 1)
# nh3_impact <- read.csv(NH3VectorFilepath(), header = T, row.names = 1)
# nox_impact <- read.csv(NOXVectorFilepath(), header = T, row.names = 1)
# pm25_impact <- read.csv(PM25VectorFilepath(), header = T, row.names = 1)
# so2_impact <- read.csv(SO2VectorFilepath(), header = T, row.names = 1)
# voc_impact <- read.csv(VOCVectorFilepath(), header = T, row.names = 1)
# h2s_impact <- read.csv(H2SVectorFilepath(), header = T, row.names = 1)
# 
# filepaths <- c(co2.filepath, n2o.filepath, ch4.filepath, co.filepath,
#                bc.filepath, nh3.filepath, nox.filepath, pm25.filepath,
#                so2.filepath, voc.filepath, h2s.filepath)
# 
# emissions <- c('co2','n2o','ch4','co',
#                'bc','nh3','nox','pm25',
#                'so2','voc','h2s')
# 
# daily.flare.df <- data.frame(Date = c(), value = c(), variable = c(), emission = c())
# for (i in 1:length(filepaths)) {
#   df <- read.csv(filepaths[i], header = T, row.names = 1)
#   Date = btb.df$Date
#   value = df['biogas_flare.m3','r']*daily.flare
#   variable = c('Flare')
#   emission = emissions[i]
#   daily.df <- data.frame(Date, value, variable, emission)
#   daily.flare.df <- rbind(daily.flare.df, daily.df)
# }
# 
# #co2
# daily.bladder.co2.kg <- data.frame(Date = btb.df$Date, 
#                                    value = (btb.df$Module_1_CO2_Percent*btb.df$CHP_1_Daily_Gas_Consumption_cu_m/100 +
#                                               btb.df$Module_2_CO2_Percent*btb.df$CHP_2_Daily_Gas_Consumption_cu_m/100)*
#                                      bladder.venting.factor*
#                                      biogas.density.kg.per.cu.m,
#                                    variable = c('Bladder Venting'))
# #ch4
# daily.bladder.ch4.kg <- data.frame(Date = btb.df$Date, 
#                                    value = (btb.df$Module_1_CH4_Percent*btb.df$CHP_1_Daily_Gas_Consumption_cu_m/100 +
#                                               btb.df$Module_2_CH4_Percent*btb.df$CHP_2_Daily_Gas_Consumption_cu_m/100)*
#                                      bladder.venting.factor*
#                                      biogas.density.kg.per.cu.m,
#                                    variable = c('Bladder Venting'))
# 
# #h2s
# 
# daily.bladder.h2s.kg <- data.frame(Date = btb.df$Date,
#                                    value = (btb.df$Module_1_H2S_Percent*btb.df$Module_1_H2S_ppm/1E6 +
#                                               btb.df$Module_2_H2s_Percent*btb.df$Module_2_H2S_ppm/1E6)*
#                                      bladder.venting.factor*
#                                      biogas.density.kg.per.cu.m,
#                                    variable = c('Bladder Venting'))
# 
# #ch4
# daily.cng.loss.ch4.kg <- data.frame(Date = btb.df$Date, 
#                                     value = btb.df$Total_CNG_m3_perday*biogas.density.kg.per.cu.m*ch4.loss.factor*cng.methane.ratio,
#                                     variable = c('CNG Loss'))