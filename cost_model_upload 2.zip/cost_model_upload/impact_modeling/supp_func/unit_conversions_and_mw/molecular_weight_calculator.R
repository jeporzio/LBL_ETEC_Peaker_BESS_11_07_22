# Molecular weight calculator
# Corinne D Scown
# August 2014
# Amended June 2015

library(udunits2)
library(gsubfn)
library(boot)

# Molecular weights of individual elements and a few common compounds
mw.C <- 12
mw.O <- 16
mw.N <- 14
mw.H <- 1
mw.S <- 32
mw.Ca <- 40
mw.Cl <- 35.5
mw.Na <- 23
mw.Al <- 27
mw.P <- 30
sucrose <- "C12H22O11"
glucose <- "C6H12O6"
fructose <- "C6H12O6"
ethanol <- "C2H6O"
acetone <- "C3H6O"
butanol <- "C4H10O"
furfural <- "C5H4O2"
HMF <- "C6H6O3"
ethylhexanol <- "C8H18O"
pentanone <- "C5H10O"
hexanone <- "C6H12O"
heptanone <- "C7H14O"
DMF <- "C6H8O"
methane <- "CH4"
#
# Imports list of common molecules and their respective molecular formulas
this.dir.energy_content_fuels <- dirname(parent.frame(2)$ofile)
formulas <- read.csv(file.path(this.dir.energy_content_fuels, 
                              "molecular_formulas.csv"), header = T)
rownames(formulas) <- formulas$Molecule
#
# Calculates MW of lube based on C number
LubeMW <- function(numC) {
  # Computes the approximate molecular weight for a lubricant with a given carbon
  # number
  #
  # Args:
  # numC: number of carbon atoms in a molecule of lube
  #
  # Returns:
  # The grams per mole (molecular weight) of the lubricant
  return(numC * MW("C") + 2 * numC * MW("H"))
}
#
# Calculates mw of any compond given its chemical formula in string form
MW <- function(form) {
  # Computes the molecular weight of a given string molecular formula
  #
  # Args:
  #  form: Molecular formula like "CH4" for methane
  #
  # Returns:
  #  The grams per mole (molecular weight)
  #
  if(form %in% formulas$Molecule) {
      form <- toString(formulas[form,"Formula"])
    } 
  DF <- strapply(form, 
                 "([A-Z][a-z]*)(\\d*)", 
                 ~ c(..1, if (nchar(..2)) ..2 else 1), 
                 simplify = ~ as.data.frame(t(matrix(..1, 2)), 
                                            stringsAsFactors = FALSE)) 
  DF[[2]] <- as.numeric(DF[[2]]) 
  molecularweight <- 0
  for(i in 1:nrow(DF)) {
    molecularweight <- molecularweight + 
      get(paste("mw.",DF[i,1], sep="")) * DF[i,2]
  }
  return(molecularweight)
}