# Product aggregation for creation of GHG figures
# Corinne D. Scown
# Created 11/18/15
# 
ResultsAggregation <- function(results.data.frame, colname,
                               aggregation.data.frame) {
  # Produces aggregated data frame ready for stacked bar graph creation in
  # ggplot2 from original results data frame
  #
  # Args:
  #   results.data.frame: raw results data frame produced by the main script
  #   aggregation.data.frame: filepath for aggregation file with list of products
  #     included in the results
  #
  # Returns:
  #   The aggregated data frame in a format usable by ggplot
  #
  aggregated.results <- aggregation.data.frame
  
  aggregated.results["Petroleum Products", colname] <- 
      sum(results.data.frame["diesel.MJ", colname],
          results.data.frame["rfo.MJ", colname],
          results.data.frame["refgas.MJ", colname],
          results.data.frame["gasoline.MJ", colname],
          results.data.frame["crudeoil.MJ", colname])
  aggregated.results["Electricity", colname] <-
      sum(results.data.frame["electricity.US.kWh", colname],
          results.data.frame["electricity.NG.kWh", colname],
          results.data.frame["electricity.NGCC.kWh", colname],
          results.data.frame["electricity.Coal.kWh", colname],
          results.data.frame["electricity.Lignin.kWh", colname],
          results.data.frame["electricity.Renewables.kWh", colname],
          results.data.frame["electricity.WECC.kWh", colname],
          results.data.frame["electricity.MRO.kWh", colname],
          results.data.frame["electricity.SPP.kWh", colname],
          results.data.frame["electricity.TRE.kWh", colname],
          results.data.frame["electricity.SERC.kWh", colname],
          results.data.frame["electricity.RFC.kWh", colname],
          results.data.frame["electricity.NPCC.kWh", colname],
          results.data.frame["electricity.FRCC.kWh", colname])
  aggregated.results["Natural Gas Upstream", colname] <-
          results.data.frame["naturalgas.MJ", colname]
  aggregated.results["Truck Transportation", colname] <-
      sum(results.data.frame["flatbedtruck.mt_km", colname],
          results.data.frame["tankertruck.mt_km", colname])
  aggregated.results["Other Transportation", colname] <-
      sum(results.data.frame["gaspipeline.mt_km", colname],
          results.data.frame["liquidpipeline.mt_km", colname],
          results.data.frame["rail.mt_km", colname],
          results.data.frame["marinetanker.mt_km", colname],
          results.data.frame["barge.mt_km", colname])
  aggregated.results["Facility Direct Emissions", colname] <-
          results.data.frame["facility direct", colname]
  aggregated.results["Biogas Offset Credit", colname] <-
          results.data.frame["biogas offset credit", colname]
  aggregated.results["Landfill CH4 Offsets", colname] <-
      sum(results.data.frame["landfill_cardboard.wet_kg", colname],
          results.data.frame["landfill_magazines.wet_kg", colname],
          results.data.frame["landfill_newspaper.wet_kg", colname],
          results.data.frame["landfill_officepaper.wet_kg", colname],
          results.data.frame["landfill_phonebooks.wet_kg", colname],
          results.data.frame["landfill_textbooks.wet_kg", colname],
          results.data.frame["landfill_lumber.wet_kg", colname],
          results.data.frame["landfill_fiberboard.wet_kg", colname],
          results.data.frame["landfill_foodwaste.wet_kg", colname],
          results.data.frame["landfill_foodwaste_nonmeat.wet_kg", colname],
          results.data.frame["landfill_foodwaste_meat.wet_kg", colname],
          results.data.frame["landfill_beef.wet_kg", colname],
          results.data.frame["landfill_poultry.wet_kg", colname],
          results.data.frame["landfill_grains.wet_kg", colname],
          results.data.frame["landfill_bread.wet_kg", colname],
          results.data.frame["landfill_fruit_vegetables.wet_kg", colname],
          results.data.frame["landfill_dairy_products.wet_kg", colname],
          results.data.frame["landfill_yard_trimmings.wet_kg", colname],
          results.data.frame["landfill_grass.wet_kg", colname],
          results.data.frame["landfill_leaves.wet_kg", colname],
          results.data.frame["landfill_branches.wet_kg", colname],
          results.data.frame["landfill_mixedpaper.wet_kg", colname],
          results.data.frame["landfill_residentialpaper.wet_kg", colname],
          results.data.frame["landfill_mixedofficepaper.wet_kg", colname],
          results.data.frame["landfill_mixedrecyclables.wet_kg", colname],
          results.data.frame["landfill_mixedorganics.wet_kg", colname],
          results.data.frame["landfill_mixedMSW.wet_kg", colname],
          results.data.frame["landfill_inorganics_wet.kg", colname])
    aggregated.results["Lost Landfill CO2 Sequestration", colname] <-
          results.data.frame["landfill_CO2_sequestration.kg", colname]
    aggregated.results["Chemicals", colname] <- 
       sum(results.data.frame["h2so4.kg", colname],
          results.data.frame["naoh.kg", colname],
          results.data.frame["ferric_chloride.kg", colname],
          results.data.frame["polymers_WWT.kg", colname],
          results.data.frame["calcium_hypochlorite.kg", colname])
    aggregated.results["Char CO2 Sequestration", colname] <-
          results.data.frame["biochar_ag_application.kg", colname]
    aggregated.results["Organics Composting", colname] <-
          results.data.frame["organics_composting_wet.kg", colname]
    aggregated.results["Avoided WWT Cake CO2 Sequestration", colname] <-
          results.data.frame["biosolids_land_application_dry.kg", colname]
  return(aggregated.results)
}

ResultsAggregationZWEDC <- function(results.data.frame, colname,
                                    aggregation.data.frame) {
  # Produces aggregated data frame ready for stacked bar graph creation in
  # ggplot2 from original results data frame
  #
  # Args:
  #   results.data.frame: raw results data frame produced by the main script
  #   aggregation.data.frame: filepath for aggregation file with list of products
  #     included in the results
  #
  # Returns:
  #   The aggregated data frame in a format usable by ggplot
  #
  # Includes ZWEDC facility results
  aggregated.results <- aggregation.data.frame
  aggregated.results["Petroleum Products", colname] <- 
    sum(results.data.frame["rfo.MJ", colname],
        results.data.frame["refgas.MJ", colname],
        results.data.frame["gasoline.MJ", colname],
        results.data.frame["crudeoil.MJ", colname], 
        na.rm = T)
  aggregated.results["Diesel", colname] <-
    sum(results.data.frame["diesel.MJ", colname],
        na.rm = T)
  aggregated.results["Other Electricity", colname] <-
    sum(results.data.frame["electricity.US.kWh", colname],
        results.data.frame["electricity.NG.kWh", colname],
        results.data.frame["electricity.Coal.kWh", colname],
        results.data.frame["electricity.Lignin.kWh", colname],
        results.data.frame["electricity.Renewables.kWh", colname],
        results.data.frame["electricity.WECC.kWh", colname],
        results.data.frame["electricity.MRO.kWh", colname],
        results.data.frame["electricity.SPP.kWh", colname],
        results.data.frame["electricity.TRE.kWh", colname],
        results.data.frame["electricity.SERC.kWh", colname],
        results.data.frame["electricity.RFC.kWh", colname],
        results.data.frame["electricity.NPCC.kWh", colname],
        results.data.frame["electricity.FRCC.kWh", colname],
        na.rm = T)
  aggregated.results["NGCC Electricity", colname] <- 
    sum(results.data.frame["electricity.NGCC.kWh", colname],
        na.rm = T)
  aggregated.results["Natural Gas", colname] <-
    sum(results.data.frame["naturalgas.MJ", colname],
        na.rm = T)
  aggregated.results["Transportation", colname] <-
    sum(results.data.frame["flatbedtruck.mt_km", colname],
        results.data.frame["tankertruck.mt_km", colname],
        results.data.frame["gaspipeline.mt_km", colname],
        results.data.frame["liquidpipeline.mt_km", colname],
        results.data.frame["rail.mt_km", colname],
        results.data.frame["marinetanker.mt_km", colname],
        results.data.frame["barge.mt_km", colname],
        na.rm = T)
  aggregated.results["Landfill", colname] <-
    sum(results.data.frame["landfill_cardboard.wet_kg", colname],
        results.data.frame["landfill_magazines.wet_kg", colname],
        results.data.frame["landfill_newspaper.wet_kg", colname],
        results.data.frame["landfill_officepaper.wet_kg", colname],
        results.data.frame["landfill_phonebooks.wet_kg", colname],
        results.data.frame["landfill_textbooks.wet_kg", colname],
        results.data.frame["landfill_lumber.wet_kg", colname],
        results.data.frame["landfill_fiberboard.wet_kg", colname],
        results.data.frame["landfill_foodwaste.wet_kg", colname],
        results.data.frame["landfill_foodwaste_nonmeat.wet_kg", colname],
        results.data.frame["landfill_foodwaste_meat.wet_kg", colname],
        results.data.frame["landfill_beef.wet_kg", colname],
        results.data.frame["landfill_poultry.wet_kg", colname],
        results.data.frame["landfill_grains.wet_kg", colname],
        results.data.frame["landfill_bread.wet_kg", colname],
        results.data.frame["landfill_fruit_vegetables.wet_kg", colname],
        results.data.frame["landfill_dairy_products.wet_kg", colname],
        results.data.frame["landfill_yard_trimmings.wet_kg", colname],
        results.data.frame["landfill_grass.wet_kg", colname],
        results.data.frame["landfill_leaves.wet_kg", colname],
        results.data.frame["landfill_branches.wet_kg", colname],
        results.data.frame["landfill_mixedpaper.wet_kg", colname],
        results.data.frame["landfill_residentialpaper.wet_kg", colname],
        results.data.frame["landfill_mixedofficepaper.wet_kg", colname],
        results.data.frame["landfill_mixedrecyclables.wet_kg", colname],
        results.data.frame["landfill_mixedorganics.wet_kg", colname],
        results.data.frame["landfill_mixedMSW.wet_kg", colname],
        results.data.frame["landfill_inorganics_wet.kg", colname],
        na.rm = T)
  aggregated.results["Sequestration", colname] <-
    sum(results.data.frame["landfill_CO2_sequestration.kg", colname],
        results.data.frame["biochar_ag_application.kg", colname],
        results.data.frame["compost_application.kg", colname],
        na.rm = T)
  aggregated.results["Chemicals", colname] <- 
    sum(results.data.frame["h2so4.kg", colname],
        results.data.frame["naoh.kg", colname],
        results.data.frame["ferric_chloride.kg", colname],
        results.data.frame["polymers_WWT.kg", colname],
        results.data.frame["calcium_hypochlorite.kg", colname],
        na.rm = T)
  aggregated.results["Organics Composting", colname] <-
    sum(results.data.frame["organics_composting_wet.kg", colname],
        results.data.frame["outdoor_compost.wet_kg", colname],
        na.rm = T)
  aggregated.results["Land Application", colname] <-
    sum(results.data.frame["biosolids_land_application_dry.kg", colname],
        na.rm = T)
  aggregated.results["Fertilizer Use", colname] <-
    sum(results.data.frame["ammonia.kg", colname],
        results.data.frame["urea.kg", colname],
        na.rm = T)
  aggregated.results["CHP", colname] <-
    sum(results.data.frame["biogas_CHP.m3", colname],
        na.rm = T)
  aggregated.results["Facility Flare", colname] <-
    sum(results.data.frame["biogas_flare.m3", colname],
        na.rm = T)
  aggregated.results["Biofilter Release", colname] <-
    sum(results.data.frame["biogas_biofilter.m3", colname],
        na.rm = T)
  aggregated.results["Methane Loss", colname] <-
    results.data.frame["CNG Loss", colname]
  aggregated.results["Bladder", colname] <-
    results.data.frame["Bladder", colname]
  
  return(aggregated.results)
}
