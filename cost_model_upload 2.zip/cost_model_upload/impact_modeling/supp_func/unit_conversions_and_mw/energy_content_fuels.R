# Copyright Corinne D Scown 2015
# This file contains one function that converts any unit of a material that
# could be used as a fuel to MJ-equivalents
#
library(udunits2)
#
# Sets working directory to current location of this script.  Now we can use 
# relative paths for other files.
#
this.dir.energy_content_fuels <- dirname(parent.frame(2)$ofile)
#
FuelConvertMJ <- function(num, fuel.name, unit) {
  # Computes the equivalent MJ (HHV) for any physical unit measure of a
  # fuel-type material
  #
  # Args:
  #  num: Physical quantity of material in whatever input unit is chosen
  #       (numeric)
  #  fuel.name: String name of the fuel material in all lower-case letters.
  #  unit: String abbreviated name of unit in which the input is measured in
  #        (num) and must be either volume or mass. Must enter units that the
  #        udunits2 package can handle. See documentation here:
  #        http://cran.r-project.org/web/packages/udunits2/udunits2.pdf
  #
  # Returns:
  #  The equivalent MJ (HHV) of num quantity of the fuel material denoted by 
  #  fuel.name  
  #
  # Read in two files:
  # 1) list of fuels with corresponding MJ HHV by liter and kg;
  # 2) file with all possible aliases for each fuel that can be entered by user
  energy.content <- read.csv(file.path(this.dir.energy_content_fuels, 
                                      "energy_content_by_mass_and_volume.csv"),
                                      header = T)  # Import conversion table
  rownames(energy.content) <- energy.content$Fuel
  aliases <- read.csv(file.path(this.dir.energy_content_fuels, 
                                 "fuel_aliases.csv"),
      header = T)  # Import table of aliases for fuels and units
  rownames(aliases) <- aliases$Alias
  #
  # Check to make sure units entered are valid and detect whether it's a unit of 
  # mass or volume
  if(ud.are.convertible(unit, "kg")) {
    # Check if units are valid and, if so, convert num to kg or liter.  
    quantity <- ud.convert(num, unit, "kg")
    measure <- "kg"
  } else if(ud.are.convertible(unit, "liter")) {
    quantity <- ud.convert(num, unit, "liter")
    measure <- "liter"
  } else {
    stop("Invalid unit entered. Please use only units included in the udunits2 
         package.")
  }
  #
  # Pull official fuel name from list of aliases and lookup energy content to 
  # calculate final HHV in MJ
  # Takes any number of potential fuel aliases from user input and returns 
  # official fuel name for calculations
  fuel <- as.character(aliases[fuel.name, "Fuel"])  
  content.MJ <- energy.content[fuel, measure]
  if(content.MJ == "N/A") {
    stop("Invalid unit entered. You may not enter a unit of volume for solid 
         fuels.")
  } else {
    # liter column of data frame requires that the output be converted to a 
    # character, then to numeric.  Converting directly to numeric doesn't work 
    # because the column is a combination of numbers and strings.
    energy.MJ <- quantity * as.numeric(as.character(energy.content[fuel, 
                                                                   measure]))  
    return(energy.MJ)
  } 
}