#------------------------------------------------------------------------------
# func_LCA_plot_percent #
#------------------------------------------------------------------------------

# Used to clean LCA outputs from func.monte.carlo.plot for plotting

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------


function_LCA_plot_percent <- function(df_LCA, df_losses) {
  
  # df_LCA = long_beach_1[[3]] # DELETE ME
  # df_losses = long_beach_1[[11]] # DELETE ME
  dim_df_LCA = dim(df_LCA)
  
  #------------------------------------------------------------------------------
  # Residual from standard # (Keep to use some calse)
  #------------------------------------------------------------------------------
  
  plot_categories = unique(df_LCA$Category)
  df_categories = data.frame(matrix(NA, nrow = length(plot_categories), ncol = dim_df_LCA[2]-1))
  colnames(df_categories) = c("Mean", "STDev", "5th P", "95th P", "Category")
  
  results = vector(mode = "list", length = length(plot_categories) + 1)
  
  for (i in 1:length(plot_categories)) {
    
    #df creation for each category - has values for each component in each category
    assign(paste("df",plot_categories[i], sep = "_"), df_LCA[df_LCA$Category == plot_categories[i],])
    
    df_categories$Mean[i] = sum(df_LCA$Mean[df_LCA$Category==plot_categories[i]])
    df_categories$STDev[i] = sum(df_LCA$STDev[df_LCA$Category==plot_categories[i]])
    df_categories$`5th P`[i] = sum(df_LCA$`5th P`[df_LCA$Category==plot_categories[i]])
    df_categories$`95th P`[i] = sum(df_LCA$`95th P`[df_LCA$Category==plot_categories[i]])
    df_categories$Category[i] = str_replace(plot_categories[i], "_", " ")
    
    results[[i+1]] = get(paste("df",plot_categories[i], sep = "_"))
    
  }
  
  results[[1]] = df_categories
  
  
  
  ### change system_other_list to change what's included in other ###
  
  system_other_list = c("inverter.count", "Switchgear.count", "Conductor.ft",
                        "Conduit.ft", "Battcont.cont", "Invcont.cont",
                        "Found.quant", "Rack.cont")
  
  system_oth_mean = 0
  system_oth_STDev = 0
  system_oth_5thP = 0
  system_oth_95thP = 0
  system_oth_row = rep(NA,6)
  
  for (j in system_other_list) {
    
    system_oth_mean = system_oth_mean + results[[3]]$Mean[results[[3]]$Component==j]
    system_oth_STDev = system_oth_STDev + results[[3]]$STDev[results[[3]]$Component==j]
    system_oth_5thP = system_oth_5thP + results[[3]]$`5th P`[results[[3]]$Component==j]
    system_oth_95thP = system_oth_95thP + results[[3]]$`95th P`[results[[3]]$Component==j]
    
    results[[3]] = results[[3]][!(results[[3]]$Component==j),]
    
  }
  
  system_row_names = row.names(results[[3]])
  results[[3]] = rbind(results[[3]], system_oth_row)
  row.names(results[[3]]) = c(system_row_names, "Other BOS")
  
  results[[3]]["Other BOS",]$Mean = system_oth_mean
  results[[3]]["Other BOS",]$STDev = system_oth_STDev
  results[[3]]["Other BOS",]$`5th P` = system_oth_5thP
  results[[3]]["Other BOS",]$`95th P` = system_oth_95thP
  results[[3]]["Other BOS",]$Component = "Other BOS"
  results[[3]]["Other BOS",]$Category = "BOS_Materials"
  
  
  
  ### change battery_other_list to change what's included in other ###
  
  batt_other_list = c("BMS.kg", "LiPF6.kg", "PVFD.kg", "ethylene.carbonate.kg", 
                      "dimethyl.carbonate.kg", "HDPE.kg", "PP.kg", "PET.kg", 
                      "NMP.kg", "carbon.black.kg", "copper.kg", "aluminum.virgin.wrought.kg")
  
  batt_oth_mean = 0
  batt_oth_STDev = 0
  batt_oth_5thP = 0
  batt_oth_95thP = 0
  batt_oth_row = rep(NA,6)
  
  for (k in batt_other_list) {
    
    batt_oth_mean = batt_oth_mean + results[[4]]$Mean[results[[4]]$Component==k]
    batt_oth_STDev = (batt_oth_STDev^2 + results[[4]]$STDev[results[[4]]$Component==k]^2)^0.5
    batt_oth_5thP = batt_oth_5thP + results[[4]]$`5th P`[results[[4]]$Component==k]
    batt_oth_95thP = batt_oth_95thP + results[[4]]$`95th P`[results[[4]]$Component==k]
    
    results[[4]] = results[[4]][!(results[[4]]$Component==k),]
    
  }
  
  batt_row_names = row.names(results[[4]])
  results[[4]] = rbind(results[[4]], batt_oth_row)
  row.names(results[[4]]) = c(batt_row_names, "Other Battery Materials")
  
  results[[4]]["Other Battery Materials",]$Mean = batt_oth_mean
  results[[4]]["Other Battery Materials",]$STDev = batt_oth_STDev
  results[[4]]["Other Battery Materials",]$`5th P` = batt_oth_5thP
  results[[4]]["Other Battery Materials",]$`95th P` = batt_oth_95thP
  results[[4]]["Other Battery Materials",]$Component = "Other Battery Materials"
  results[[4]]["Other Battery Materials",]$Category = "Battery_Materials"
  
  results[[7]] = rbind(results[[2]], results[[3]], results[[4]], results[[5]], results[[6]])
  
  # renaming items for graphing
  
  results[[7]][results[[7]]=="Battery_Assembly"] = "Module Materials & Assembly" #"Battery Assembly"
  results[[7]][results[[7]]=="BOS_Materials"] = "Energy Storage BOS"
  results[[7]][results[[7]]=="Battery_Materials"] = "Module Materials & Assembly"
  results[[7]][results[[7]]=="Purchased_Electricity"] = "Battery Charging & Losses" # "Purchased Electricity"
  results[[7]][results[[7]]=="Sold_Electricity"] = "Offset Electricity" # "Offset Electricity"
  
  results[[7]][results[[7]]=="battery.assembly.kWh"] = "Battery Assembly"
  results[[7]][results[[7]]=="transformer.count"]  = "Transformer"
  results[[7]][results[[7]]=="Fire.cont"] = "Fire Suppression"
  results[[7]][results[[7]]=="HVAC.cont"] = "HVAC"
  results[[7]][results[[7]]=="graphite.kg"] = "Graphite"
  results[[7]][results[[7]]=="copper.kg"] = "Copper"
  results[[7]][results[[7]]=="aluminum.virgin.wrought.kg"] = "Aluminum"
  results[[7]][results[[7]]=="purchased.electricity.cycle"] = "Battery Charging & Losses"
  results[[7]][results[[7]]=="sold.electricity.cycle"] = "Offset Electricity"
  
  results[[7]][results[[7]]=="NCA.kg"] = "NCA Cathode"
  results[[7]][results[[7]]=="LFP-HT.kg"] = "LFP Cathode (Hydrothermal Prod.)"
  results[[7]][results[[7]]=="NMC-811.kg"] = "NMC-811 Cathode"
  results[[7]][results[[7]]=="LMO.kg"] = "LMO Cathode"
  results[[7]][results[[7]]=="NMC-111.kg"] = "NMC-111 Cathode"
  results[[7]][results[[7]]=="NMC-532,kg"] = "NMC-532 Cathode"
  results[[7]][results[[7]]=="NMC-622.kg"] = "NMC-622 Cathode"
  results[[7]][results[[7]]=="NMC-811.kg"] = "NMC-811 Cathode"
  results[[7]][results[[7]]=="LFP-SS.kg"] = "LFP Cathode"
  
  
  batt_factor = ceiling(Lifetime / Lifespan)
  results[[7]]$Mean[results[[7]]$Category=="Module Materials & Assembly"] = results[[7]]$Mean[results[[7]]$Category=="Module Materials & Assembly"] * batt_factor
  results[[7]]$STDev[results[[7]]$Category=="Module Materials & Assembly"] = ((results[[7]]$STDev[results[[7]]$Category=="Module Materials & Assembly"])^2 * batt_factor)^0.5
  
  results[[7]]$Mean[results[[7]]$Component=="Offset Electricity"] =  results[[7]]$Mean[results[[7]]$Component=="Offset Electricity"] # * -1
  
  
  
  results[[8]] = subset(results[[7]], select = -c(Component, `5th P`, `95th P`))
  temp_results8 = results[[8]]
  results[[8]] = ddply(results[[8]], "Category", numcolwise(sum))
  
  for (m in unique(results[[8]]$Category)) {
    
    results[[8]]$STDev[results[[8]]$Category==m]= sum(temp_results8$STDev[temp_results8$Category==m]^2)^0.5
    
  }
  
  
  
  cathode_name = results[[7]][results[[7]]$Category=="Module Materials & Assembly",]
  cathode_name = cathode_name$Component[!(cathode_name$Component=="Battery Assembly" | cathode_name$Component=="Graphite" | cathode_name$Component=="Other Battery Materials")]
  
  eff_losses = results[[7]]$Mean[results[[7]]$Component=="Battery Charging & Losses"] *(1 - (1 - df_losses["Transformer","Mean"])^2 * (1 - df_losses["Inverter","Mean"])^2  * (1 - df_losses["Battery","Mean"])^2 * (1 - df_losses["Thermal","Mean"])^2 * (1 - df_losses["Misc.","Mean"])^2) 
  
  eff_losses_std = eff_losses * sqrt(2 * (df_losses["Transformer","STDev"]/df_losses["Transformer","Mean"])^2 + 
                                       2 * (df_losses["Transformer","STDev"]/df_losses["Inverter","Mean"])^2 + 
                                       2 * (df_losses["Transformer","STDev"]/df_losses["Battery","Mean"])^2 +
                                       2 * (df_losses["Transformer","STDev"]/df_losses["Thermal","Mean"])^2 +
                                       2 * (df_losses["Transformer","STDev"]/df_losses["Misc","Mean"])^2)
  
  df_eff_losses = data.frame(c(eff_losses), c(eff_losses_std), c(NA), c(NA), c("Energy Losses"), c("Battery Charging & Losses"))
  colnames(df_eff_losses) = colnames(results[[7]])
  
  results[[7]] = rbind(results[[7]], df_eff_losses)
  row.names(results[[7]]) = c("Battery Assembly", "Transformer", "Fire Suppression", "HVAC", "Other BOS", "LFP Cathode", "Graphite", "Other Battery Materials", "Battery Charging & Losses", "Offset Electricity", "Energy Losses")
  
  results[[7]]["Battery Charging & Losses", "Mean"] = results[[7]]["Battery Charging & Losses", "Mean"] - results[[7]]["Energy Losses", "Mean"]
  # results[[7]]["Battery Charging & Losses", "STDev"] = (results[[7]]["Battery Charging & Losses", "STDev"]^2 + results[[7]]["Losses", "STDev"]^2)^0.5
  
  results[[8]]$STDev[results[[8]]$Category=="Battery Charging & Losses"] = (results[[7]]["Battery Charging & Losses", "STDev"]^2 + results[[7]]["Energy Losses", "STDev"]^2)^0.5
  
  
  # might need to delete these two lines
  results[[7]]$Category = factor(results[[7]]$Category, levels = c("Module Materials & Assembly", "Energy Storage BOS", "Battery Charging & Losses", "Offset Electricity"))
  results[[7]]$Component = factor(results[[7]]$Component, levels = c("Other Battery Materials", "Graphite", cathode_name, "Battery Assembly", "Other BOS", "Transformer", "Fire Suppression", "HVAC", "Energy Losses", "Battery Charging & Losses", "Offset Electricity"))
  results[[8]]$Category = factor(results[[8]]$Category, levels = c("Module Materials & Assembly", "Energy Storage BOS", "Battery Charging & Losses", "Offset Electricity"))
  
  
  df_wf = data.frame(results[[7]]$Category, results[[7]]$Component, results[[7]]$Mean)
  colnames(df_wf) = c("Category", "Component", "Mean")
  
  df_wf = df_wf[order(df_wf$Category),]
  df_wf = mutate(df_wf, end.bar = cumsum(Mean), start.bar = c(0, head(end.bar, -1)))
  # do group indicies manually, # group.id = group_indices(., Category))
  group.id = c(1,1,1,1,2,2,2,2,3,3,4)
  end.id = c(0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1)
  df_wf = cbind(df_wf, group.id, end.id)
  
  df_wf_std = results[[8]][order(results[[8]]$Category),]
  df_wf_std = cbind(df_wf_std, df_wf$end.bar[df_wf$end.id==1])
  colnames(df_wf_std) = c("Category", "Mean", "STDev", "Pos")
  df_wf_std = mutate(df_wf_std, end.bar = cumsum(Mean), start.bar = c(0, head(end.bar, -1)))
  
  group.id = c(1,2,3,4)
  end.id = c(1,1,1,1)
  df_wf_std = cbind(df_wf_std, group.id, end.id)
  
  results[[9]] = df_wf
  results[[10]] = df_wf_std
  
  #------------------------------------------------------------------------------
  # Code for percent #
  #------------------------------------------------------------------------------
  
  # Category Rename
  
  results_p = df_LCA
  results_p$Category[results_p$Category=="Battery_Assembly"] = "Module Materials & Assembly"
  results_p$Category[results_p$Category=="BOS_Materials"] = "Energy Storage BOS"
  results_p$Category[results_p$Category=="Battery_Materials"] = "Module Materials & Assembly"
  results_p$Category[results_p$Category=="Purchased_Electricity"] = "Battery Charging & Losses"
  results_p$Category[results_p$Category=="Sold_Electricity"] = "Offset Electricity"
  
  # remove 5th and 95th p
  
  results_p = subset(results_p, select = -c(`5th P`, `95th P`) )
  
  # extract battery losses and new purchased electricity as new variables (mean and std)
  
  batt_losses_mean = results[[7]]["Energy Losses", "Mean"]
  batt_losses_std = results[[7]]["Energy Losses", "STDev"]
  
  new_purch_elec_mean = results[[7]]["Battery Charging & Losses", "Mean"]
  new_purch_elec_std = results[[7]]["Battery Charging & Losses", "STDev"]
  
  # remove purchased electricity from df
  
  results_p = results_p[!(row.names(results_p) %in% c("purchased.electricity.cycle")),]
  
  # add rows for battery losses and new purchased electricity
  
  results_p_add = data.frame(c(batt_losses_mean, new_purch_elec_mean),
                             c(batt_losses_std, new_purch_elec_std),
                             c("Losses","Purchased Electricity"),
                             c("Battery Charging & Losses", "Battery Charging & Losses"))
  colnames(results_p_add) = c("Mean", "STDev", "Component", "Category")
  
  rownames(results_p) <- NULL
  results_p = rbind(results_p, results_p_add)
  
  # Component Rename
  
  results_p$Component[results_p$Component=="battery.assembly.kWh"] = "Cell & Module Assembly"
  results_p$Component[results_p$Component=="inverter.count"] = "Inverter"
  results_p$Component[results_p$Component=="transformer.count"] = "Transformer"
  results_p$Component[results_p$Component=="Switchgear.count"] = "Switchgear"
  results_p$Component[results_p$Component=="Conductor.ft"] = "Conductor"
  results_p$Component[results_p$Component=="Conduit.ft"] = "Conduit"
  results_p$Component[results_p$Component=="BMS.kg"] = "Battery Management System"
  results_p$Component[results_p$Component=="Fire.cont"] = "Fire Suppression System"
  results_p$Component[results_p$Component=="HVAC.cont"] = "HVAC"
  results_p$Component[results_p$Component=="Battcont.cont"] = "Battery Storage Housing"
  results_p$Component[results_p$Component=="Invcont.cont"] = "Inverter Housing"
  results_p$Component[results_p$Component=="Found.quant"] = "Foundation"
  results_p$Component[results_p$Component=="Rack.cont"] = "Battery Storage Racking"
  results_p$Component[results_p$Component=="sold.electricity.cycle"] = "Offset Electricity"
  results_p$Component[results_p$Component=="NCA.kg"] = "NCA Cathode Active Material"
  results_p$Component[results_p$Component=="LFP-HT.kg"] = "LFP Cathode Active Material (Hydrothermal Prod.)"
  results_p$Component[results_p$Component=="NMC-811.kg"] = "NMC-811 Cathode Active Material"
  results_p$Component[results_p$Component=="LMO.kg"] = "LMO Cathode Active Material"
  results_p$Component[results_p$Component=="NMC-111.kg"] = "NMC-111 Cathode Active Material"
  results_p$Component[results_p$Component=="NMC-532,kg"] = "NMC-532 Cathode Active Material"
  results_p$Component[results_p$Component=="NMC-622.kg"] = "NMC-622 Cathode Active Material"
  results_p$Component[results_p$Component=="NMC-811.kg"] = "NMC-811 Cathode Active Material"
  results_p$Component[results_p$Component=="LFP-SS.kg"] = "LFP Cathode Active Material"
  results_p$Component[results_p$Component=="LiPF6.kg"] = "LiPF6"
  results_p$Component[results_p$Component=="PVFD.kg"] = "PVFD"
  results_p$Component[results_p$Component=="ethylene.carbonate.kg"] = "Ethylene Carbonate"
  results_p$Component[results_p$Component=="dimethyl.carbonate.kg"] = "Dimethyl Carbonate"
  results_p$Component[results_p$Component=="graphite.kg"] = "Graphite"
  results_p$Component[results_p$Component=="HDPE.kg"] = "HDPE"
  results_p$Component[results_p$Component=="PP.kg"] = "PP"
  results_p$Component[results_p$Component=="PET.kg"] = "PET"
  results_p$Component[results_p$Component=="NMP.kg"] = "NMP"
  results_p$Component[results_p$Component=="carbon.black.kg"] = "Carbon Black"
  results_p$Component[results_p$Component=="copper.kg"] = "Copper"
  results_p$Component[results_p$Component=="aluminum.virgin.wrought.kg"] = "Aluminum"
  
  # convert mean values to %
  
  results_p_mod_mean = sum(results_p$Mean[results_p$Category=="Module Materials & Assembly"])
  results_p_bos_mean = sum(results_p$Mean[results_p$Category=="Energy Storage BOS"])
  results_p_off_mean = sum(results_p$Mean[results_p$Category=="Offset Electricity"])
  results_p_cha_mean = sum(results_p$Mean[results_p$Category=="Battery Charging & Losses"])
  
  results_p$Mean[results_p$Category=="Module Materials & Assembly"] = results_p$Mean[results_p$Category=="Module Materials & Assembly"] / results_p_mod_mean
  results_p$Mean[results_p$Category=="Energy Storage BOS"] = results_p$Mean[results_p$Category=="Energy Storage BOS"] / results_p_bos_mean
  results_p$Mean[results_p$Category=="Offset Electricity"] = results_p$Mean[results_p$Category=="Offset Electricity"] / results_p_off_mean
  results_p$Mean[results_p$Category=="Battery Charging & Losses"] = results_p$Mean[results_p$Category=="Battery Charging & Losses"] / results_p_cha_mean
  
  results_p_list = vector(mode = "list", length = 2)
  results_p_list[[1]] = results_p
  results_p_list[[2]] = results_p
  
  
  
  ### Option 1 for plotting - combining similar items into groups
  
  # plastics - HDPE, PET, PP, PVFD # Module Materials & Assembly
  
  plas_items = c("HDPE", "PET", "PP", "PVFD")
  plas_mean = 0
  plas_ind = rep(NA, length(plas_items))
  
  for (i in 1:length(plas_items)) {
    
    plas_mean = plas_mean + results_p_list[[2]]$Mean[results_p_list[[2]]$Component==plas_items[i]]
    plas_ind[i] = which(results_p_list[[2]]$Component == plas_items[i])
    
  }
  
  # Housing and structures - Batt housing, inv housing, racks, foundations # Energy Storage BOS
  
  hous_items = c("Battery Storage Housing", "Battery Storage Racking", "Foundation", "Inverter Housing")
  hous_mean = 0
  hous_ind = rep(NA, length(hous_items))
  
  for (i in 1:length(hous_items)) {
    
    hous_mean = hous_mean + results_p_list[[2]]$Mean[results_p_list[[2]]$Component==hous_items[i]]
    hous_ind[i] = which(results_p_list[[2]]$Component == hous_items[i])
    
  }
  
  # Conduits & Conductors# Energy Storage BOS
  
  cond_items = c("Conductor", "Conduit")
  cond_mean = 0
  cond_ind = rep(NA, length(cond_items))
  
  for (i in 1:length(cond_items)) {
    
    cond_mean = cond_mean + results_p_list[[2]]$Mean[results_p_list[[2]]$Component==cond_items[i]]
    cond_ind[i] = which(results_p_list[[2]]$Component == cond_items[i])
    
  }
  
  # Electrolyte fluid # Module Materials and Assembly
  
  elef_items = c("Dimethyl Carbonate", "Ethylene Carbonate")
  elef_mean = 0
  elef_ind = rep(NA, length(elef_items))
  
  for (i in 1:length(elef_items)) {
    
    elef_mean = elef_mean + results_p_list[[2]]$Mean[results_p_list[[2]]$Component==elef_items[i]]
    elef_ind[i] = which(results_p_list[[2]]$Component == elef_items[i])
    
  }
  
  # remove repeated entries
  
  results_p_list[[2]] = results_p_list[[2]][-c(plas_ind, hous_ind, cond_ind, elef_ind), ]
  
  # add new entries
  
  opt_1_add = data.frame(Mean = c(plas_mean, hous_mean, cond_mean, elef_mean), 
                         STDev = c(NA, NA, NA, NA), 
                         Component = c("Plastics", "Equipment Housing & Structures", "Conduits & Conductors", "Electrolyte Fluid"),
                         Category = c("Module Materials & Assembly", "Energy Storage BOS", "Energy Storage BOS", "Module Materials & Assembly"))
  
  results_p_list[[2]] = rbind(results_p_list[[2]], opt_1_add)
  
  
  
  ### Option 2 for plotting - Same as option 1, but with other for non-visible items
  
  results_p_list[[3]] = results_p_list[[2]]
  
  # Module Materials & Assembly Other
  
  mod_oth_items = c("Carbon Black", "Electrolyte Fluid", "LiPF6", "NMP", "Plastics")
  mod_oth_mean = 0
  mod_oth_ind = rep(NA, length(mod_oth_items))
  
  for (i in 1:length(mod_oth_items)) {
    
    mod_oth_mean = mod_oth_mean + results_p_list[[2]]$Mean[results_p_list[[2]]$Component==mod_oth_items[i]]
    mod_oth_ind[i] = which(results_p_list[[2]]$Component == mod_oth_items[i])
    
  }
  
  # Energy Storage BOS Other
  
  BOS_oth_items = c("Battery Management System", "Switchgear", "Conduits & Conductors") # chabge here 02_08_22
  BOS_oth_mean = 0
  BOS_oth_ind = rep(NA, length(BOS_oth_items))
  
  for (i in 1:length(BOS_oth_items)) {
    
    BOS_oth_mean = BOS_oth_mean + results_p_list[[2]]$Mean[results_p_list[[2]]$Component==BOS_oth_items[i]]
    BOS_oth_ind[i] = which(results_p_list[[2]]$Component == BOS_oth_items[i])
    
  }
  
  # remove repeated entries
  
  results_p_list[[3]] = results_p_list[[3]][-c(mod_oth_ind, BOS_oth_ind), ]
  
  # add new entries
  
  opt_2_add = data.frame(Mean = c(mod_oth_mean, BOS_oth_mean), 
                         STDev = c(NA, NA), 
                         Component = c("Other Module Materials & Assembly", "Other Energy Storage BOS"),
                         Category = c("Module Materials & Assembly", "Energy Storage BOS"))
  
  results_p_list[[3]] = rbind(results_p_list[[3]], opt_2_add)

  
  ### Option 3 for plotting - same as option 2, but removing offset electricity and combing plastics into other
  
  results_p_list[[4]] = results_p_list[[3]]
  results_p_list[[4]] = results_p_list[[4]][!(results_p_list[[4]]$Category=="Offset Electricity"),]
  
  results_p_list[[4]]$Category = factor(results_p_list[[4]]$Category, levels = (c("Module Materials & Assembly", "Energy Storage BOS", "Battery Charging & Losses")))
  results_p_list[[4]] = results_p_list[[4]][order(results_p_list[[4]]$Category, results_p_list[[4]]$Mean),]
  
  comp_order = results_p_list[[4]]$Component
  results_p_list[[4]]$Component = factor(results_p_list[[4]]$Component, levels = rev(comp_order))
  
  ### Option 4 for plotting - same as option 3, but setting df for rectangle plotting instead of bar plotting
  
  results_p_list[[5]] = results_p_list[[4]]
  
  end.bar = c(cumsum(results_p_list[[5]]$Mean[results_p_list[[5]]$Category=="Module Materials & Assembly"]),
              cumsum(results_p_list[[5]]$Mean[results_p_list[[5]]$Category=="Energy Storage BOS"]),
              cumsum(results_p_list[[5]]$Mean[results_p_list[[5]]$Category=="Battery Charging & Losses"]))
  results_p_list[[5]] = cbind(results_p_list[[5]], end.bar)
  results_p_list[[5]] = mutate(results_p_list[[5]], start.bar = c(0, head(end.bar, -1)))

  group.id = c(rep(1,6), rep(2, 6), rep(3,2))
  end.id = c(0,0,0,0,0,1,0,0,0,0,0,1,0,1)
  start.id = c(1,0,0,0,0,0,1,0,0,0,0,0,1,0)
  results_p_list[[5]] = cbind(results_p_list[[5]], group.id, end.id, start.id)
  
  results_p_list[[5]]$start.bar[results_p_list[[5]]$start.id==1] = 0
  
  
  
  return(results_p_list)
  
}


