#------------------------------------------------------------------------------
# function__lnnorm_dist #
#------------------------------------------------------------------------------

# Used in battery cost modeling

# creates lognormal distribution for price ranges

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------

function_lnnorn_dist <- function(alpha, beta, mu, sd, min, max, n) {
  
  result_set = NA
  
  while (is.na(result_set)) {
  
  base_set = alpha + beta * c(rlnorm(n, meanlog = mu, sdlog = sd))
  
  for (i in 1:length(base_set)) {
    
    if (base_set[i] > max | base_set[i] < min) {
      
      base_set[i] = NA
      
    }
    
  }
  
  base_set = base_set[!is.na(base_set)]
  
  result_set = alpha + beta * c(rlnorm(n, meanlog = mu, sdlog = sd))
  
  for (i in 1:length(result_set)) {
    
    if (result_set[i] > max | result_set[i] < min) {
      
      j = runif(1, min = 1, max = length(base_set))
      
      result_set[i] = base_set[j]
      
    }
    
  }
  
  }
  
  return(result_set)
  
}


#------------------------------------------------------------------------------
# Specifications #
#------------------------------------------------------------------------------
# 
# # NMC pricing # 
# 
# alpha= 115
# beta = 100
# mu = 0
# sd = 5
# min = 115
# max = 525
# n = 100
# 
# test = function_lnnorn_dist(alpha, beta, mu, sd, min, max, n)
# test = data.frame(test)
# 
# ggplot(test) + 
#   geom_histogram(aes(x = test))
# 
# min(test$test)
# mean(test$test)
# max(test$test)
# 
# 
# 
# # LFP pricing # 
# 
# alpha= 99
# beta = 1.25
# mu = 0
# sd = 5
# min = 99
# max = 225
# n = 100
# 
# test = function_lnnorn_dist(alpha, beta, mu, sd, min, max, n)
# test = data.frame(test)
# 
# ggplot(test) + 
#   geom_freqpoly(aes(x = test))
# 
# min(test$test)
# mean(test$test)
# max(test$test)
# 
# 
# 
# # NCA pricing # 
# 
# alpha= 115
# beta = 0.000005
# mu = 0
# sd = 20
# min = 115
# max = 415
# n = 100
# 
# test = function_lnnorn_dist(alpha, beta, mu, sd, min, max, n)
# test = data.frame(test)
# 
# ggplot(test) + 
#   geom_freqpoly(aes(x = test))
# 
# min(test$test)
# mean(test$test)
# max(test$test)




