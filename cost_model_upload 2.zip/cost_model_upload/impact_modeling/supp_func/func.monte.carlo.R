#------------------------------------------------------------------------------
# function_monte_carlo #
#------------------------------------------------------------------------------

# Used in battery cost modeling

# performs multiple runs of func_li_BESS

# v-1 (11/29/21): checkpoint before lca integration

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

source("supp_func/func.li.BESS.R")

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------

function_monte_carlo<- function(City, # Average,
                                State, # National,
                                Power_MW, # 60 MW
                                Duration, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                Year, # 2020,
                                Lifespan, # [15, 20],
                                Chem,
                                Fire,
                                Cycle_per_year,
                                DoD,
                                m,
                                Deg_opt,
                                eBOS_MW,
                                purchased_electricity,
                                sold_electricity,
                                refrigerant,
                                peaker_name) {
  
  
  # DELETE BELOW

  # City = "Average"
  # State = "National"
  # Power_MW = 114 # 60 MW
  # Duration = 4 # [4, 3, 2, 1, 0.75, 0.5, 0.25]
  # Year = 2020 # 2020,
  # Lifespan = 7.5 # [15, 20],
  # Chem = "LFP Graphite SS"
  # Fire = 2001
  # Cycle_per_year = 56
  # DoD = 0.95
  # m = 10
  # Deg_opt = "Yes"
  # 
  # eBOS_MW = 65
  # 
  # purchased_electricity = "electricity.Solar.kWh"
  # sold_electricity = "electricity.NG.kWh"
  # refrigerant = "r410a.kg" # "r32.kg"
  # 
  # peaker_name = "Long Beach Generating Station - Unit 1"
  # 
  # n = 1
  
  
  ##############################################################################
  # func.li.BESS runs #
  ##############################################################################
  
  Capacity_MWh = Power_MW * Duration
  
  n = 1
  
  cost_all_runs = matrix(ncol = m, nrow = 8)
  mats_all_runs = matrix(ncol = m, nrow = 20)
  
  # LCA_all_runs = matrix(ncol = m, nrow = LCA_dim[1]) # replace nrow with fixed dimension when finished
  ghg_all_runs = matrix(ncol = m, nrow = 28)
  co_all_runs = matrix(ncol = m, nrow = 28)
  nox_all_runs = matrix(ncol = m, nrow = 28)
  sox_all_runs = matrix(ncol = m, nrow = 28)
  pm25_all_runs = matrix(ncol = m, nrow = 28)
  voc_all_runs = matrix(ncol = m, nrow = 28)
  
  cases_all_runs = matrix(ncol = m, nrow = 28)
  losses_all_runs = matrix(ncol = m, nrow = 5)
  
  NPV_all_runs = array(NA, dim=c(Lifetime+1, 10, m))# matrix(ncol = m, nrow = 10) # adjust if including more npv categories
  
  
  for (i in 1:m) {
    
    # i = 1
    
    temp = function_li_BESS(City, # Average,
                            State, # National,
                            Power_MW, # 60 MW
                            Duration, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                            Year, # 2020,
                            Lifespan, # [15, 20],
                            Chem,
                            Fire,
                            Cycle_per_year,
                            DoD,
                            n,
                            Deg_opt,
                            eBOS_MW,
                            purchased_electricity,
                            sold_electricity,
                            refrigerant,
                            peaker_name)
    
    cost = temp[[1]] # added 8/30
    mat = temp[[2]]
    case = temp[[9]]
    NPV = temp[[10]]
    losses = temp[[11]]
    
    ghg = rep(0,length(temp[[3]]))
    co = rep(0,length(temp[[3]]))
    nox = rep(0,length(temp[[3]]))
    sox = rep(0,length(temp[[3]]))
    pm25 = rep(0,length(temp[[3]]))
    voc = rep(0,length(temp[[3]]))
    
    for (j in 1:length(temp[[3]])) {
      
      ghg[j] = sum(temp[[3]][[j]]$r)
      co[j] = sum(temp[[4]][[j]]$r)
      nox[j] = sum(temp[[5]][[j]]$r)
      sox[j] = sum(temp[[6]][[j]]$r)
      pm25[j] = sum(temp[[7]][[j]]$r)
      voc[j] = sum(temp[[8]][[j]]$r)
      
    }
    
    
    cost_all_runs[,i] = cost$Cost
    mats_all_runs[,i] = mat$Quant
    cases_all_runs[,i] = case$Mat_vals
    NPV_all_runs[,,i] = as.matrix(NPV)
    losses_all_runs[,i] = losses$Percent_Loss
    
    # LCA = temp[[3]] # added 9/13
    
    ghg_all_runs[,i] = ghg
    co_all_runs[,i] = co
    nox_all_runs[,i] = nox
    sox_all_runs[,i] = sox
    pm25_all_runs[,i] = pm25
    voc_all_runs[,i] = voc
    
  }
  
  cost_names = temp[[1]]$Component
  # mats_names
  lca_names = temp[[9]]$Mat_names
  
  row.names(cost_all_runs) = cost_names
  row.names(ghg_all_runs) = lca_names
  row.names(co_all_runs) = lca_names
  row.names(nox_all_runs) = lca_names
  row.names(sox_all_runs) = lca_names
  row.names(pm25_all_runs) = lca_names
  row.names(voc_all_runs) = lca_names
  row.names(cases_all_runs) = lca_names
  colnames(NPV_all_runs) = colnames(temp[[10]])
  row.names(losses_all_runs) = losses$Equipment
  
  results = list(cost_all_runs, mats_all_runs, ghg_all_runs, co_all_runs,
                 nox_all_runs, sox_all_runs, pm25_all_runs, voc_all_runs,
                 cases_all_runs, NPV_all_runs, losses_all_runs)
  
  return(results)
  
}
