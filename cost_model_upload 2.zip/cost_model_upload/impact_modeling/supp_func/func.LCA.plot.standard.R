#------------------------------------------------------------------------------
# func_LCA_plot_standard #
#------------------------------------------------------------------------------

# Used to clean LCA outputs from func.monte.carlo.plot for plotting

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------


function_LCA_plot_standard <- function(df_LCA, df_losses) {
  
  # df_LCA = test_mcp_LFP[[3]] # DELETE ME
  # df_losses = test_mcp_LFP[[11]] # DELETE ME
  dim_df_LCA = dim(df_LCA)
  
  plot_categories = unique(df_LCA$Category)
  df_categories = data.frame(matrix(NA, nrow = length(plot_categories), ncol = dim_df_LCA[2]-1))
  colnames(df_categories) = c("Mean", "STDev", "5th P", "95th P", "Category")
  
  results = vector(mode = "list", length = length(plot_categories) + 1)
  
  for (i in 1:length(plot_categories)) {
    
    #df creation for each category - has values for each component in each category
    assign(paste("df",plot_categories[i], sep = "_"), df_LCA[df_LCA$Category == plot_categories[i],])
    
    df_categories$Mean[i] = sum(df_LCA$Mean[df_LCA$Category==plot_categories[i]])
    df_categories$STDev[i] = sum(df_LCA$STDev[df_LCA$Category==plot_categories[i]])
    df_categories$`5th P`[i] = sum(df_LCA$`5th P`[df_LCA$Category==plot_categories[i]])
    df_categories$`95th P`[i] = sum(df_LCA$`95th P`[df_LCA$Category==plot_categories[i]])
    df_categories$Category[i] = str_replace(plot_categories[i], "_", " ")
    
    results[[i+1]] = get(paste("df",plot_categories[i], sep = "_"))
    
  }
  
  results[[1]] = df_categories
  
  
  
  ### change system_other_list to change what's included in other ###
  
  system_other_list = c("inverter.count", "Switchgear.count", "Conductor.ft",
                        "Conduit.ft", "Battcont.cont", "Invcont.cont",
                        "Found.quant", "Rack.cont")
  
  system_oth_mean = 0
  system_oth_STDev = 0
  system_oth_5thP = 0
  system_oth_95thP = 0
  system_oth_row = rep(NA,6)
  
  for (j in system_other_list) {
    
    system_oth_mean = system_oth_mean + results[[3]]$Mean[results[[3]]$Component==j]
    system_oth_STDev = system_oth_STDev + results[[3]]$STDev[results[[3]]$Component==j]
    system_oth_5thP = system_oth_5thP + results[[3]]$`5th P`[results[[3]]$Component==j]
    system_oth_95thP = system_oth_95thP + results[[3]]$`95th P`[results[[3]]$Component==j]
    
    results[[3]] = results[[3]][!(results[[3]]$Component==j),]
    
  }
  
  system_row_names = row.names(results[[3]])
  results[[3]] = rbind(results[[3]], system_oth_row)
  row.names(results[[3]]) = c(system_row_names, "Other BOS")
  
  results[[3]]["Other BOS",]$Mean = system_oth_mean
  results[[3]]["Other BOS",]$STDev = system_oth_STDev
  results[[3]]["Other BOS",]$`5th P` = system_oth_5thP
  results[[3]]["Other BOS",]$`95th P` = system_oth_95thP
  results[[3]]["Other BOS",]$Component = "Other BOS"
  results[[3]]["Other BOS",]$Category = "BOS_Materials"
  
  
  
  ### change battery_other_list to change what's included in other ###
  
  batt_other_list = c("BMS.kg", "LiPF6.kg", "PVFD.kg", "ethylene.carbonate.kg", 
                      "dimethyl.carbonate.kg", "HDPE.kg", "PP.kg", "PET.kg", 
                      "NMP.kg", "carbon.black.kg", "copper.kg", "aluminum.virgin.wrought.kg")
  
  batt_oth_mean = 0
  batt_oth_STDev = 0
  batt_oth_5thP = 0
  batt_oth_95thP = 0
  batt_oth_row = rep(NA,6)
  
  for (k in batt_other_list) {
    
    batt_oth_mean = batt_oth_mean + results[[4]]$Mean[results[[4]]$Component==k]
    batt_oth_STDev = (batt_oth_STDev^2 + results[[4]]$STDev[results[[4]]$Component==k]^2)^0.5
    batt_oth_5thP = batt_oth_5thP + results[[4]]$`5th P`[results[[4]]$Component==k]
    batt_oth_95thP = batt_oth_95thP + results[[4]]$`95th P`[results[[4]]$Component==k]
    
    results[[4]] = results[[4]][!(results[[4]]$Component==k),]
    
  }
  
  batt_row_names = row.names(results[[4]])
  results[[4]] = rbind(results[[4]], batt_oth_row)
  row.names(results[[4]]) = c(batt_row_names, "Other Battery Materials")
  
  results[[4]]["Other Battery Materials",]$Mean = batt_oth_mean
  results[[4]]["Other Battery Materials",]$STDev = batt_oth_STDev
  results[[4]]["Other Battery Materials",]$`5th P` = batt_oth_5thP
  results[[4]]["Other Battery Materials",]$`95th P` = batt_oth_95thP
  results[[4]]["Other Battery Materials",]$Component = "Other Battery Materials"
  results[[4]]["Other Battery Materials",]$Category = "Battery_Materials"
  
  results[[7]] = rbind(results[[2]], results[[3]], results[[4]], results[[5]], results[[6]])
  
  # renaming items for graphing
  
  results[[7]][results[[7]]=="Battery_Assembly"] = "Module Materials & Assembly" #"Battery Assembly"
  results[[7]][results[[7]]=="BOS_Materials"] = "Energy Storage BOS"
  results[[7]][results[[7]]=="Battery_Materials"] = "Module Materials & Assembly"
  results[[7]][results[[7]]=="Purchased_Electricity"] = "Battery Charging & Losses" # "Purchased Electricity"
  results[[7]][results[[7]]=="Sold_Electricity"] = "Business as Usual" # "Offset Electricity"
  
  results[[7]][results[[7]]=="battery.assembly.kWh"] = "Battery Assembly"
  results[[7]][results[[7]]=="transformer.count"]  = "Transformer"
  results[[7]][results[[7]]=="Fire.cont"] = "Fire Suppression"
  results[[7]][results[[7]]=="HVAC.cont"] = "HVAC"
  results[[7]][results[[7]]=="graphite.kg"] = "Graphite"
  results[[7]][results[[7]]=="copper.kg"] = "Copper"
  results[[7]][results[[7]]=="aluminum.virgin.wrought.kg"] = "Aluminum"
  results[[7]][results[[7]]=="purchased.electricity.cycle"] = "Battery Charging & Losses"
  results[[7]][results[[7]]=="sold.electricity.cycle"] = "Business as Usual"
  
  results[[7]][results[[7]]=="NCA.kg"] = "NCA Cathode"
  results[[7]][results[[7]]=="LFP-HT.kg"] = "LFP Cathode (Hydrothermal Prod.)"
  results[[7]][results[[7]]=="NMC-811.kg"] = "NMC-811 Cathode"
  results[[7]][results[[7]]=="LMO.kg"] = "LMO Cathode"
  results[[7]][results[[7]]=="NMC-111.kg"] = "NMC-111 Cathode"
  results[[7]][results[[7]]=="NMC-532,kg"] = "NMC-532 Cathode"
  results[[7]][results[[7]]=="NMC-622.kg"] = "NMC-622 Cathode"
  results[[7]][results[[7]]=="NMC-811.kg"] = "NMC-811 Cathode"
  results[[7]][results[[7]]=="LFP-SS.kg"] = "LFP Cathode"
  
  
  batt_factor = ceiling(Lifetime / Lifespan)
  results[[7]]$Mean[results[[7]]$Category=="Module Materials & Assembly"] = results[[7]]$Mean[results[[7]]$Category=="Module Materials & Assembly"] * batt_factor
  results[[7]]$STDev[results[[7]]$Category=="Module Materials & Assembly"] = ((results[[7]]$STDev[results[[7]]$Category=="Module Materials & Assembly"])^2 * batt_factor)^0.5
  
  results[[7]]$Mean[results[[7]]$Component=="Business as Usual"] = -1 * results[[7]]$Mean[results[[7]]$Component=="Business as Usual"]
  
  
  
  results[[8]] = subset(results[[7]], select = -c(Component, `5th P`, `95th P`))
  temp_results8 = results[[8]]
  results[[8]] = ddply(results[[8]], "Category", numcolwise(sum))
  
  for (m in unique(results[[8]]$Category)) {
    
    results[[8]]$STDev[results[[8]]$Category==m]= sum(temp_results8$STDev[temp_results8$Category==m]^2)^0.5
    
  }
  
  
  
  cathode_name = results[[7]][results[[7]]$Category=="Module Materials & Assembly",]
  cathode_name = cathode_name$Component[!(cathode_name$Component=="Battery Assembly" | cathode_name$Component=="Graphite" | cathode_name$Component=="Other Battery Materials")]

  eff_losses = results[[7]]$Mean[results[[7]]$Component=="Battery Charging & Losses"] *(1 - (1 - df_losses["Transformer","Mean"])^2 * (1 - df_losses["Inverter","Mean"])^2  * (1 - df_losses["Battery","Mean"])^2 * (1 - df_losses["Thermal","Mean"])^2 * (1 - df_losses["Misc.","Mean"])^2) 
  
  eff_losses_std = eff_losses * sqrt(2 * (df_losses["Transformer","STDev"]/df_losses["Transformer","Mean"])^2 + 
                          2 * (df_losses["Transformer","STDev"]/df_losses["Inverter","Mean"])^2 + 
                          2 * (df_losses["Transformer","STDev"]/df_losses["Battery","Mean"])^2 +
                          2 * (df_losses["Transformer","STDev"]/df_losses["Thermal","Mean"])^2 +
                          2 * (df_losses["Transformer","STDev"]/df_losses["Misc","Mean"])^2)
             
  df_eff_losses = data.frame(c(eff_losses), c(eff_losses_std), c(NA), c(NA), c("Energy Losses"), c("Battery Charging & Losses"))
  colnames(df_eff_losses) = colnames(results[[7]])
  
  results[[7]] = rbind(results[[7]], df_eff_losses)
  row.names(results[[7]]) = c("Battery Assembly", "Transformer", "Fire Suppression", "HVAC", "Other BOS", "LFP Cathode", "Graphite", "Other Battery Materials", "Battery Charging & Losses", "Business as Usual", "Energy Losses")
  
  results[[7]]["Battery Charging & Losses", "Mean"] = results[[7]]["Battery Charging & Losses", "Mean"] - results[[7]]["Energy Losses", "Mean"]
  # results[[7]]["Battery Charging & Losses", "STDev"] = (results[[7]]["Battery Charging & Losses", "STDev"]^2 + results[[7]]["Losses", "STDev"]^2)^0.5
  
  results[[8]]$STDev[results[[8]]$Category=="Battery Charging & Losses"] = (results[[7]]["Battery Charging & Losses", "STDev"]^2 + results[[7]]["Energy Losses", "STDev"]^2)^0.5
  
  
  results[[7]]$Category = factor(results[[7]]$Category, levels = c("Module Materials & Assembly", "Energy Storage BOS", "Battery Charging & Losses", "Business as Usual"))
  results[[7]]$Component = factor(results[[7]]$Component, levels = c("Other Battery Materials", "Graphite", cathode_name, "Battery Assembly", "Other BOS", "Transformer", "Fire Suppression", "HVAC", "Energy Losses", "Battery Charging & Losses", "Business as Usual"))
  
  
  return(results)
  
}
  

