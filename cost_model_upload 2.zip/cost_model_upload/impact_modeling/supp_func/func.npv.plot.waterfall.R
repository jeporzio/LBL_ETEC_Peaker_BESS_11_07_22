#------------------------------------------------------------------------------
# func_npv_plot_waterfall #
#------------------------------------------------------------------------------

# Used to clean LCA outputs from func.monte.carlo.plot for plotting

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------

function_npv_plot_waterfall <- function(df_npv, df_std, df_damages, discount_series, peaker_name, peaker_name_short, plant_profits, elec_prices, RTE_npv, chem_npv) {
  
  # Delete below
# 
#   df_npv = long_beach_1[[10]]
#   df_std = long_beach_1[[12]]
#   df_damages = batt_damages_raw
# 
#   discount_series = discount_series
#   peaker_name = "Long Beach Generating Station - Unit 1"
#   peaker_name_short = "Long Beach 1"
#   plant_profits = plant_profits
#   elec_prices = elec_prices
# 
#   RTE_npv = "RTE85" # ["RTE80", "RTE85", "RTE90", "RTE100"]
#   chem_npv = "LFP" # ["LFP", "NCA", "NMC"]

  # Delete above
  
  
  ### Data Loading ###
  
  timeshift_discharge_raw = read_excel("timeshift_discharge.xlsx", sheet = paste(RTE_npv, chem_npv, sep = "_"))
  timeshift_discharge_high_raw = read_excel("timeshift_discharge.xlsx", sheet = paste(RTE_npv, chem_npv, "HIGH", sep = "_"))
  timeshift_discharge_low_raw = read_excel("timeshift_discharge.xlsx", sheet = paste(RTE_npv, chem_npv, "LOW", sep = "_"))
  
  timeshift_charge_raw = read_excel("timeshift_charge.xlsx", sheet = paste(RTE_npv, chem_npv, sep = "_"))
  timeshift_charge_high_raw = read_excel("timeshift_charge.xlsx", sheet = paste(RTE_npv, chem_npv, "HIGH", sep = "_"))
  timeshift_charge_low_raw = read_excel("timeshift_charge.xlsx", sheet = paste(RTE_npv, chem_npv, "LOW", sep = "_"))
  
  timeshift_discharge = timeshift_discharge_raw[,peaker_name]
  timeshift_discharge_high = timeshift_discharge_high_raw[,peaker_name]
  timeshift_discharge_low = timeshift_discharge_low_raw[,peaker_name]
  
  timeshift_charge = timeshift_charge_raw[,peaker_name]
  timeshift_charge_high = timeshift_charge_high_raw[,peaker_name]
  timeshift_charge_low = timeshift_charge_low_raw[,peaker_name]
  
  plant_nodes = read_excel("PlantNodes_v2.xlsx")
  p_node = plant_nodes$Zone[plant_nodes$plant_id==peaker_name]
  elec_prices_plant = elec_prices[,p_node]

  kgCO2eq_per_kWh_elec_ng = 0 # 0.4664202 - us electricity # 0.5266283 - ng electricity

    
  ### NPV and Plotting Calcs ###
  
  dim_npv = dim(df_npv)
  
  df_npv = df_npv * discount_series / 10^6 # convert from $ to millions of $
  df_std = df_std * discount_series / 10^6
  
  
  df_npv  = colSums(df_npv)
  df_stdev = rep(NA, dim_npv[2])
  
  for(i in 1:dim_npv[2]) {
    
    df_stdev[i] = sum(df_std[,i]^2)^0.5
    
  }
  
  results_df = data.frame(df_npv,
                                   df_stdev,
                                   `NPV Category` = c("Upfront Materials & Assembly",
                                                      "Upfront Materials & Assembly",
                                                      "Battery Replacement",
                                                      "Battery Replacement",
                                                      "Operations & Maintenance",
                                                      "Operations & Maintenance",
                                                      "Battery Charging & Losses",
                                                      "Battery Charging & Losses",
                                                      "Offset Peaker Activity",
                                                      "Offset Peaker Activity"),
                                   `Cost Type` = c("Monetary",
                                                   "Emissions",
                                                   "Monetary",
                                                   "Emissions",
                                                   "Monetary",
                                                   "Emissions",
                                                   "Monetary",
                                                   "Emissions",
                                                   "Monetary",
                                                   "Emissions"))
  colnames(results_df) = c("Mean", "STDev", "NPV Category", "Cost Type")
  
  results_df$Mean[results_df$`Cost Type`=="Emissions"] = scc * results_df$Mean[results_df$`Cost Type`=="Emissions"]
  results_df$STDev[results_df$`Cost Type`=="Emissions"] = scc * results_df$STDev[results_df$`Cost Type`=="Emissions"]
  
  
  ### update with Derek's damages ##
  
  # Monetary # not included
  # long_beach_1_NPV_df["usd_charge",]$Mean = sum(rep(batt_damages_raw$E_DIFF_Total_OtherPlant[batt_damages_raw$peaker_name=="Long Beach Generating Station - Unit 1"],dim_npv[1]) * discount_series)
  # long_beach_1_NPV_df["usd_discharge",]$Mean = sum(rep(batt_damages_raw$E_DIFF_Total_ReplacedPlant[batt_damages_raw$peaker_name=="Long Beach Generating Station - Unit 1"],dim_npv[1]) * discount_series)
  # long_beach_1_NPV_df["usd_charge",]$STDev = 0
  # long_beach_1_NPV_df["usd_discharge",]$STDev = 0
  
  # Emissions # These numbers are already in million $ / year
  results_df["kgco2_charge",]$Mean = sum(rep(df_damages$E_DIFF_Total_OtherPlant[df_damages$peaker_name==peaker_name],dim_npv[1]) * discount_series) + sum(rep(df_damages$CO2TDIFF_OtherPlant_TSC_Charge[df_damages$peaker_name==peaker_name],dim_npv[1]) * discount_series * scc * 1000/10^6)
  results_df["kgco2_discharge",]$Mean  = sum(rep(df_damages$E_DIFF_Total_ReplacedPlant[df_damages$peaker_name==peaker_name],dim_npv[1]) * discount_series)
  results_df["kgco2_charge",]$STDev = 0
  results_df["kgco2_discharge",]$STDev = 0
  
  
  
  results_df$`NPV Category` = factor(results_df$`NPV Category`, 
                                              levels = c("Upfront Materials & Assembly",
                                                         "Battery Replacement",
                                                         "Operations & Maintenance",
                                                         "Battery Charging & Losses",
                                                         "Offset Peaker Activity"))
  
  results_df$`Cost Type` = factor(results_df$`Cost Type`, 
                                           levels = c("Monetary",
                                                      "Emissions"))
  
  results_df = results_df[order(results_df$`NPV Category`, results_df$`Cost Type`),]
  
  
  
  ### adding timeshifting costs to battery charging and losses
  
  charge_timeshift_npv = sum(sum(timeshift_charge * elec_prices_plant)/3 * discount_series)/10^6
  charge_timeshift_high_npv = sum(sum(timeshift_charge_high * elec_prices_plant)/3 * discount_series)/10^6
  charge_timeshift_low_npv = sum(sum(timeshift_charge_low * elec_prices_plant)/3 * discount_series)/10^6
  
  results_df$Mean[results_df$`NPV Category`=="Battery Charging & Losses"&results_df$`Cost Type`=="Emissions"] = results_df$Mean[results_df$`NPV Category`=="Battery Charging & Losses"&results_df$`Cost Type`=="Emissions"] + charge_timeshift_npv
  
  
  
  
  ### adding columns for plotting

  results_df = mutate(results_df, end.bar = cumsum(Mean), start.bar = c(0, head(end.bar, -1)))
  # do group indicies manually, # group.id = group_indices(., Category))
  group.id = c(1,1,2,2,3,3,4,4,5,5)
  end.id = c(0, 1, 0, 1, 0, 1, 0, 1, 0, 1)
  results_df = cbind(results_df, group.id, end.id)
  
  results_df$STDev[results_df$`NPV Category`=="Battery Charging & Losses" & results_df$`Cost Type`=="Monetary"] = results_df$Mean[results_df$`NPV Category`=="Battery Charging & Losses" & results_df$`Cost Type`=="Monetary"]*0.125 
  results_df$STDev[results_df$`NPV Category`=="Offset Peaker Activity" & results_df$`Cost Type`=="Monetary"] = results_df$Mean[results_df$`NPV Category`=="Offset Peaker Activity" & results_df$`Cost Type`=="Monetary"]*0.125 
  
  
  results_df_std = results_df[results_df$end.id==1,]

  NPV_cat = results_df_std$`NPV Category`

  for (i in NPV_cat) {

    results_df_std$STDev[results_df_std$`NPV Category`==i] = sum(results_df$STDev[results_df$`NPV Category`==i]^2)^0.5


  }
  
  results_df$Mean = results_df$Mean * -1
  results_df$end.bar = results_df$end.bar * -1
  results_df$start.bar = results_df$start.bar * -1
  
  results_df_std$Mean = results_df_std$Mean * -1
  results_df_std$end.bar = results_df_std$end.bar * -1
  results_df_std$start.bar = results_df_std$start.bar * -1
  
  std_up_temp = results_df_std$STDev
  std_dn_temp = results_df_std$STDev
  results_df_std = cbind(results_df_std, std_up_temp, std_dn_temp)
  colnames(results_df_std) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id", "STDev_Up", "STDev_Down")
  
  results_df_std$STDev_Up[results_df_std$`NPV Category`=="Battery Charging & Losses"] = results_df_std$STDev_Up[results_df_std$`NPV Category`=="Battery Charging & Losses"] + (charge_timeshift_low_npv - charge_timeshift_npv)
  results_df_std$STDev_Down[results_df_std$`NPV Category`=="Battery Charging & Losses"] = results_df_std$STDev_Down[results_df_std$`NPV Category`=="Battery Charging & Losses"] + (charge_timeshift_npv - charge_timeshift_high_npv)
  
  
  
  ### time-shifting calcs ### ADD IN ENV DAMAGES/BENEFITS ONCE DEREK PERFORMS
  
  timeshift_rev_ann = sum(timeshift_discharge * elec_prices_plant)/3 # export matlab series for elec price
  timeshift_rev_high_ann = sum(timeshift_discharge_high * elec_prices_plant)/3
  timeshift_rev_low_ann = sum(timeshift_discharge_low * elec_prices_plant)/3 # discharge series x price
  
  timeshift_cost_ann = 0 # sum(timeshift_charge * elec_prices_plant)
  timeshift_cost_high_ann = 0 # sum(timeshift_charge_high * elec_prices_plant)
  timeshift_cost_low_ann = 0 # sum(timeshift_charge_low * elec_prices_plant)
  
  timeshift_prof = timeshift_rev_ann - timeshift_cost_ann
  timeshift_prof_high = timeshift_rev_high_ann - timeshift_cost_high_ann
  timeshift_prof_low = timeshift_rev_low_ann - timeshift_cost_low_ann
  
  timeshift_prof_npv = sum(timeshift_prof * discount_series)/10^6
  timeshift_prof_npv_high = sum(timeshift_prof_high * discount_series)/10^6
  timeshift_prof_npv_low = sum(timeshift_prof_low * discount_series)/10^6
  
  timeshift_emis_npv = abs(sum(rep(df_damages$CO2TDIFF_OtherPlant_TSD_Discharge[df_damages$peaker_name==peaker_name],dim_npv[1]) * discount_series * scc * 1000/10^6))
  
  
  
  
  
  time_shift_df = data.frame(Mean = c(timeshift_prof_npv, timeshift_emis_npv), 
                             STDev = c(0, 0),
                             `NPV Category` = rep("Arbitrage",2),
                             `Cost Type` = c("Monetary", "Emissions"),
                             end.bar = c(results_df$end.bar[results_df$`NPV Category`=="Offset Peaker Activity" & results_df$`Cost Type`=="Emissions"] + timeshift_prof_npv,results_df$end.bar[results_df$`NPV Category`=="Offset Peaker Activity" & results_df$`Cost Type`=="Emissions"] + timeshift_prof_npv + timeshift_emis_npv),
                             start.bar = c(results_df$end.bar[results_df$`NPV Category`=="Offset Peaker Activity" & results_df$`Cost Type`=="Emissions"],results_df$end.bar[results_df$`NPV Category`=="Offset Peaker Activity" & results_df$`Cost Type`=="Emissions"] + timeshift_prof_npv),
                             group.id = rep(6,2),
                             end.id = c(0,1)
  )
  colnames(time_shift_df) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id")
  
  time_shift_df_std = data.frame(Mean = c(timeshift_prof_npv), 
                             STDev = c(0),
                             `NPV Category` = c("Arbitrage"),
                             `Cost Type` = c("Emissions"),
                             end.bar = c(results_df$end.bar[results_df$`NPV Category`=="Offset Peaker Activity" & results_df$`Cost Type`=="Emissions"] + timeshift_prof_npv),
                             start.bar = c(results_df$end.bar[results_df$`NPV Category`=="Offset Peaker Activity" & results_df$`Cost Type`=="Emissions"]),
                             group.id = c(6),
                             end.id = c(1),
                             STDev_Up = timeshift_prof_npv_low - timeshift_prof_npv,
                             STDev_Down = timeshift_prof_npv - timeshift_prof_npv_high
  )
  colnames(time_shift_df_std) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id", "STDev_Up", "STDev_Down")
  
  results_df = rbind(results_df, time_shift_df)
  results_df_std = rbind(results_df_std, time_shift_df_std)
  
  
  ### ancillary services calcs ### ASSUME ACTIVITY OFFSETS NATURAL GAS - find LC natural gas values, multiply by max load * 24 * days non active * SCC carbon * discount_series
  
  # as_cycles_colname = paste("Annual_cycles_ts", chem_npv, RTE_npv, sep = "_")
  # 
  # as_prof = 5.04421297545279 * plant_profits$Max_Load[plant_profits$Peaker==peaker_name] * 24*(365 - plant_profits$Annual_cycles[plant_profits$Peaker==peaker_name] - plant_profits[as_cycles_colname][plant_profits$Peaker==peaker_name,])
  # as_sd = 4.67964744228554 * plant_profits$Max_Load[plant_profits$Peaker==peaker_name] * 24*(365 - plant_profits$Annual_cycles[plant_profits$Peaker==peaker_name] - plant_profits[as_cycles_colname][plant_profits$Peaker==peaker_name,])
  # 
  # as_npv = sum(as.numeric(as_prof)*discount_series)/10^6
  # as_sd_npv = sum((as.double(as_sd)*discount_series)^2)^0.5/10^6
  # 
  # as_env = kgCO2eq_per_kWh_elec_ng * 1000 *  plant_profits$Max_Load[plant_profits$Peaker==peaker_name] * 24*(365 - plant_profits$Annual_cycles[plant_profits$Peaker==peaker_name] - plant_profits[as_cycles_colname][plant_profits$Peaker==peaker_name,]) * scc
  # as_env_npv = sum(as.numeric(as_env)*discount_series)/10^6
  #   
  # 
  # as_df = data.frame(Mean = c(as_npv, as_env_npv), 
  #                            STDev = c(as_sd_npv, 0),
  #                            `NPV Category` = rep("Spinning Reserves",2),
  #                            `Cost Type` = c("Monetary", "Emissions"),
  #                            end.bar = c(results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"] + as_npv,
  #                                        results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"] + as_npv + as_env_npv),
  #                            start.bar = c(results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"],
  #                                          results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"] + as_npv),
  #                            group.id = rep(7,2),
  #                            end.id = c(0,1)
  # )
  # colnames(as_df) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id")
  # 
  # as_df_std = data.frame(Mean = c(as_npv), 
  #                                STDev = c(as_sd_npv),
  #                                `NPV Category` = c("Spinning Reserves"),
  #                                `Cost Type` = c("Emissions"),
  #                                end.bar = c(results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"] + as_npv + as_env_npv),
  #                                start.bar = c(results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"]),
  #                                group.id = c(7),
  #                                end.id = c(1),
  #                                STDev_Up = as_sd_npv,
  #                                STDev_Down = as_sd_npv
  # )
  # colnames(as_df_std) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id", "STDev_Up", "STDev_Down")
  # 
  # results_df = rbind(results_df, as_df)
  # results_df_std = rbind(results_df_std, as_df_std)
  
  
  
  
  
  ### frequency regulatation ###
  
  # https://www.sandia.gov/ess-ssl/docs/other/SAND2016-1080C.pdf
  
  fr_prof = 19.57 * plant_profits$Max_Load[plant_profits$Peaker==peaker_name] * 24*(365 - plant_profits$Annual_cycles[plant_profits$Peaker==peaker_name])
  # 6394098.98/20*1.092*(365 - plant_profits$Annual_cycles[plant_profits$Peaker==peaker_name] - plant_profits[as_cycles_colname][plant_profits$Peaker==peaker_name,])/365 * plant_profits$Max_Load[plant_profits$Peaker==peaker_name]
  fr_sd = 7.75 * plant_profits$Max_Load[plant_profits$Peaker==peaker_name] * 24*(365 - plant_profits$Annual_cycles[plant_profits$Peaker==peaker_name])
  # 2134475.193/20*1.092*(365 - plant_profits$Annual_cycles[plant_profits$Peaker==peaker_name] - plant_profits[as_cycles_colname][plant_profits$Peaker==peaker_name,])/365 * plant_profits$Max_Load[plant_profits$Peaker==peaker_name]
  
  fr_npv = sum(as.numeric(fr_prof)*discount_series)/10^6
  fr_sd_npv = sum((as.double(fr_sd)*discount_series)^2)^0.5/10^6
  
  fr_env = 0
  fr_env_npv = sum(as.numeric(fr_env)*discount_series)/10^6
  
  fr_df = data.frame(Mean = c(fr_npv, fr_env_npv), 
                     STDev = c(fr_sd_npv, 0),
                     `NPV Category` = rep("Frequency Regulation",2),
                     `Cost Type` = c("Monetary", "Emissions"),
                     end.bar = c(results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"] + fr_npv,
                                 results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"] + fr_npv + fr_env_npv),
                     start.bar = c(results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"],
                                   results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"] + fr_npv),
                     group.id = rep(7,2),
                     end.id = c(0,1)
  )
  colnames(fr_df) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id")
  
  fr_df_std = data.frame(Mean = c(fr_npv), 
                         STDev = c(fr_sd_npv),
                         `NPV Category` = c("Frequency Regulation"),
                         `Cost Type` = c("Emissions"),
                         end.bar = c(results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"] + fr_npv + fr_env_npv),
                         start.bar = c(results_df$end.bar[results_df$`NPV Category`=="Arbitrage" & results_df$`Cost Type`=="Emissions"]),
                         group.id = c(7),
                         end.id = c(1),
                         STDev_Up = fr_sd_npv,
                         STDev_Down = fr_sd_npv
  )
  colnames(fr_df_std) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id", "STDev_Up", "STDev_Down")
  
  results_df = rbind(results_df, fr_df)
  results_df_std = rbind(results_df_std, fr_df_std)
  
  
  ### adjust std_up and down ###
  
  results_df_std$STDev_Up = results_df_std$STDev_Up * 2 # remove this effect for Arbitrage upon second analysis
  results_df_std$STDev_Down = results_df_std$STDev_Down * 2 # remove this effect for Arbitrage upon second analysis
  
  
  # remove and recalc net emissions
  # 
  # results_df = results_df[!(results_df$`NPV Category`=="Total NPV"),]
  # results_df = rbind(results_df, time_shift_df)
  
  results_df_tot = data.frame(Mean = sum(results_df$Mean),
                              STDev = sum(results_df$STDev^2)^0.5,
                              # Pos = results_df$Pos[results_df$Category=="Offset Peaker Activity"],
                              `NPV Category` = "Total NPV",
                              `Cost Type` = "Total NPV",
                              end.bar = results_df$end.bar[results_df$`NPV Category`=="Frequency Regulation"][2],
                              start.bar = 0,
                              group.id = 8,
                              end.id = 1
  )
  colnames(results_df_tot) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id")
  
  results_df_tot_std = data.frame(Mean = sum(results_df$Mean),
                              STDev = sum(results_df$STDev^2)^0.5,
                              # Pos = results_df$Pos[results_df$Category=="Offset Peaker Activity"],
                              `NPV Category` = "Total NPV",
                              `Cost Type` = "Total NPV",
                              end.bar = results_df$end.bar[results_df$`NPV Category`=="Frequency Regulation"][2],
                              start.bar = 0,
                              group.id = 8,
                              end.id = 1,
                              STDev_Up = sum(results_df_std$STDev_Up^2)^0.5,
                              STDev_Down = sum(results_df_std$STDev_Down^2)^0.5
                              
  )
  colnames(results_df_tot_std) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id", "STDev_Up", "STDev_Down")
  
  
  results_df = rbind(results_df, results_df_tot)
  results_df_std = rbind(results_df_std, results_df_tot_std)
  
  

  
  
  # results_df_std = results_df[results_df$end.id==1,]
  
  NPV_cat = results_df_std$`NPV Category`
  
  for (i in NPV_cat) {
    
    results_df_std$STDev[results_df_std$`NPV Category`==i] = sum(results_df$STDev[results_df$`NPV Category`==i]^2)^0.5
    
    
  }
  
  results_df$`NPV Category` = factor(results_df$`NPV Category`, 
                                     levels = c("Upfront Materials & Assembly",
                                                "Battery Replacement",
                                                "Operations & Maintenance",
                                                "Battery Charging & Losses",
                                                "Offset Peaker Activity",
                                                "Arbitrage",
                                                # "Spinning Reserves",
                                                "Frequency Regulation",
                                                "Total NPV"))
  
  
  results_df = cbind(results_df, rep(peaker_name, length(results_df$Mean)), rep(peaker_name_short, length(results_df$Mean)))
  colnames(results_df) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id", "Peaker Plant Long", "Peaker Plant")
  
  results_df_std = cbind(results_df_std, rep(peaker_name, length(results_df_std$Mean)), rep(peaker_name_short, length(results_df_std$Mean)))
  colnames(results_df_std) = c("Mean", "STDev", "NPV Category", "Cost Type", "end.bar", "start.bar", "group.id", "end.id", "STDev_Up", "STDev_Down", "Peaker Plant Long", "Peaker Plant")
  
  
  
  ### df for all plots plotting
  
  results_all_df = results_df
  dim_results_all_df = dim(results_all_df)
  indc = 0
  
  for (i in 1:dim_results_all_df[1]) {
    
    if (results_all_df$Mean[i]>0 & indc==0) {
      
      indc = 1
      
      results_all_df$start.bar[i] = results_all_df$start.bar[i] + abs(results_all_df$end.bar[i-1]) 
      results_all_df$end.bar[i] = results_all_df$end.bar[i] + abs(results_all_df$end.bar[i-1])
      
    } else if (results_all_df$Mean[i]>=0 & indc==1) {
      
      results_all_df$start.bar[i] = abs(results_all_df$end.bar[i-1])
      results_all_df$end.bar[i] = abs(results_all_df$end.bar[i-1]) + results_all_df$Mean[i]
      
      
      
    }
 
  }
  
  results_all_df = results_all_df[results_all_df$`NPV Category`!="Total NPV",]
  
  ### return variables
  
  
  results_list = list(results_df, results_df_std, results_all_df)
  
  return(results_list)
  
}