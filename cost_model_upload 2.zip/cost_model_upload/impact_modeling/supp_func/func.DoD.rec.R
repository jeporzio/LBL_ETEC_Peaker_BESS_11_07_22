#------------------------------------------------------------------------------
# function__DoD_rec #
#------------------------------------------------------------------------------

# Used in battery cost modeling

# Outputs oversizing ratio of battery

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------

function_DoD_rec <- function(Cycles_tot, r, DoD) {
  
  temp = DoD
  
  if(Cycles_tot!=0) {
    
    
    for (i in 1:Cycles_tot) {
      
      temp = temp * (1 + r*temp)
      
    }
    
    temp = temp*DoD
    
  } else {}
  
  
  return(temp)
}
