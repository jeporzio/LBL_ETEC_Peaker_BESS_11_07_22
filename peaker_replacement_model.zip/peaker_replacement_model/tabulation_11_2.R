##############################################################################
# Results Data Tabulation Ranges #
##############################################################################

runs = 1
runs_2 = 1

lifetime_table = c(5, 7.5, 10)
size_mw_table = c(2.5, 5, 10, 25, 50, 100, 250)
duration_hr_table = c(0.25, 0.5, 1, 2, 4)
chem_table = c("LFP Graphite", "NCA Graphite", "NMC Graphite")
cycles_table = c(50, 100, 250, 500)

array_dim_1 = 8
array_dim_2 = 18
array_dim_3 = length(lifetime_table) * length(size_mw_table) * length(duration_hr_table) * length(chem_table) * length(cycles_table)

results_kW_3d = array(numeric(), c(length(size_mw_table)*length(chem_table)*length(lifetime_table), length(duration_hr_table)*length(cycles_table), 0))
results_kWh_3d = array(numeric(), c(length(size_mw_table)*length(chem_table)*length(lifetime_table), length(duration_hr_table)*length(cycles_table), 0))

##############################################################################
# Results Data Tabulation Processing #
##############################################################################

for (h in 1:runs_2) {
  
  
  temp = data.frame(`Mean` = numeric(), 
                    `STDev` = numeric(),
                    `5th P` = numeric(),
                    `95th P` = numeric(),
                    `Component` = factor(), 
                    `temp` = numeric(), 
                    `YPos_Cum` = numeric(), 
                    `YPos_Ind` = numeric(),
                    `City` = factor(),
                    `State` = factor(),
                    `Capacity MWh` = numeric(),
                    `Power MW` = numeric(),
                    `Duration Hr` = numeric(),
                    `Year` = numeric(),
                    `Lifespan Yr` = numeric(),
                    `Chemistry` = factor(),
                    `Fire Suppression` = numeric(),
                    `Cycles per Year` = numeric(),
                    `Depth of Discharge` = numeric(),
                    `Stdev` = numeric())
  
  results_raw = data.frame(`Mean` = numeric(), 
                           `STDev` = numeric(), 
                           `5th P` = numeric(),
                           `95th P` = numeric(),
                           `Component` = factor(), 
                           `temp` = numeric(), 
                           `YPos_Cum` = numeric(), 
                           `YPos_Ind` = numeric(),
                           `City` = factor(),
                           `State` = factor(),
                           `Capacity MWh` = numeric(),
                           `Power MW` = numeric(),
                           `Duration Hr` = numeric(),
                           `Year` = numeric(),
                           `Lifespan Yr` = numeric(),
                           `Chemistry` = factor(),
                           `Fire Suppression` = numeric(),
                           `Cycles per Year` = numeric(),
                           `Depth of Discharge` = numeric(),
                           `Stdev` = numeric())
  
  temp_tot = data.frame(`Mean` = numeric(1), 
                        `STDev` = numeric(1), 
                        `5th P` = numeric(1),
                        `95th P` = numeric(1),
                        `Component` = factor(1), 
                        `temp` = numeric(1), 
                        `YPos_Cum` = numeric(1), 
                        `YPos_Ind` = numeric(1),
                        `City` = factor(1),
                        `State` = factor(1),
                        `Capacity MWh` = numeric(1),
                        `Power MW` = numeric(1),
                        `Duration Hr` = numeric(1),
                        `Year` = numeric(1),
                        `Lifespan Yr` = numeric(1),
                        `Chemistry` = factor(1),
                        `Fire Suppression` = numeric(1),
                        `Cycles per Year` = numeric(1),
                        `Depth of Discharge` = numeric(1),
                        `Stdev` = numeric(1))
  
  colnames(temp_tot) = c("Mean", 
                         "STDev", 
                         "5th P",
                         "95th P",
                         "Component", 
                         "temp", 
                         "YPos_Cum", 
                         "YPos_Ind",
                         "City",
                         "State",
                         "Capacity MWh",
                         "Power MW",
                         "Duration Hr",
                         "Year",
                         "Lifespan Yr",
                         "Chemistry",
                         "Fire Suppression",
                         "Cycles per Year",
                         "Depth of Discharge",
                         "STdev"
  )
  
  count = 1
  
  # i = 5
  # j = 2.5
  # k = 0.25
  # l = "LFP Graphite"
  # m = 50
  
  for (i in lifetime_table) {
    
    for (j in size_mw_table) {
      
      for (k in duration_hr_table) {
        
        for (l in chem_table) {
          
          for (m in cycles_table) {
            
            temp = function_monte_carlo_plot("Average",
                                             "National",
                                             j, # size MW
                                             k, # duration hr
                                             2020, # year
                                             i, # lifetime yr
                                             l, # chem
                                             2001,
                                             m, #cycles
                                             0.8,
                                             runs,
                                             "Yes")
            
            temp_tot$Mean = sum(temp$Mean)
            temp_tot$STDev = sum(temp$STDev)
            temp_tot$`5th P` = sum(temp$`5th P`)
            temp_tot$`95th P` = sum(temp$`95th P`)
            temp_tot$Component = "Total"
            temp_tot$temp = NA
            temp_tot$YPos_Cum = temp$YPos_Cum[1]
            temp_tot$YPos_Ind = sum(temp$YPos_Ind)
            temp_tot$City = temp$City[1]
            temp_tot$State = temp$State[1]
            temp_tot$`Capacity MWh` = temp$`Capacity MWh`[1]
            temp_tot$`Power MW` = temp$`Power MW`[1]
            temp_tot$`Duration Hr` = temp$`Duration Hr`[1]
            temp_tot$Year = temp$Year[1]
            temp_tot$`Lifespan Yr` = temp$`Lifespan Yr`[1]
            temp_tot$Chemistry = temp$Chemistry[1]
            temp_tot$`Fire Suppression` = temp$`Fire Suppression`[1]
            temp_tot$`Cycles per Year` = temp$`Cycles per Year`[1]
            temp_tot$`Depth of Discharge` = temp$`Depth of Discharge`[1]
            temp_tot$STdev = sum(temp$STdev)
            
            temp = rbind(temp, temp_tot)
            
            results_raw = rbind(results_raw, temp)
            
            count = count + 1
            
          }
        }
      }
    }
  }
  
  
  Mean_USD_pkW = results_raw$Mean * results_raw$`Capacity MWh` / results_raw$`Power MW`
  
  results = data.frame(results_raw, Mean_USD_pkW)
  
  results_tot = results[results$Component=="Total",]
  
  results_kWh = results_tot$Mean
  results_kW = results_tot$Mean_USD_pkW
  
  results_cost = data.frame(results_kWh, results_kW)
  
  colnames(results_cost) = c("CapEx USD/kWh", "CapEx USD/kW")
  
  results_tot_2 = cbind(results_tot, results_cost)
  
  temp_1 = data.frame(matrix(, nrow = 1, ncol = length(duration_hr_table)))
  temp_2 = data.frame(matrix(, nrow = length(size_mw_table), ncol = length(duration_hr_table)))
  temp_3 = data.frame(matrix(, nrow = length(size_mw_table)*length(chem_table), ncol = length(duration_hr_table)))
  temp_4 = data.frame(matrix(, nrow = length(size_mw_table)*length(chem_table), ncol = length(duration_hr_table)*length(cycles_table)))
  temp_5 = data.frame(matrix(, nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table), ncol = length(duration_hr_table)*length(cycles_table)))
  
  
  # kwh
  
  count_5 = 1
  
  for (i in lifetime_table) {
    
    # i = 5
    
    count_4 = 1
    
    for (j in cycles_table) {
      
      # j = 50
      # i = 5
      
      count_3 = 1
      
      for (k in chem_table) {
        
        # k = "LFP Graphite"
        # j = 50
        # i = 5
        
        count_2 = 1
        
        for (l in size_mw_table) {
          
          # l = 2.5
          # k = "LFP Graphite"
          # j = 50
          # i = 5
          
          count_1 = 1
          
          for (m in duration_hr_table) {
            
            temp = results_tot_2$`CapEx USD/kWh`[results_tot_2$Duration.Hr==m & results_tot_2$Power.MW ==l & results_tot_2$Chemistry==k & results_tot_2$Cycles.per.Year==j & results_tot_2$Lifespan.Yr==i]
            temp_1[,count_1] = temp
            
            count_1 = count_1 + 1
            
          }
          
          temp_2[count_2,] = temp_1
          
          count_2 = count_2 + 1
          
        }
        
        temp_3[count_3:(count_3+length(size_mw_table)-1),] = temp_2
        
        count_3 = count_3 + length(size_mw_table)
        
      }
      
      temp_4[,count_4:(count_4 + length(duration_hr_table) - 1)] = temp_3
      
      count_4 = count_4 + length(duration_hr_table)
      
    }
    
    temp_5[count_5:(count_5 + length(size_mw_table)*length(chem_table) - 1),] = temp_4
    
    count_5 = count_5 + length(size_mw_table)*length(chem_table)
    
  }
  
  results_kWh = temp_5
  
  
  
  temp_1 = data.frame(matrix(, nrow = 1, ncol = length(duration_hr_table)))
  temp_2 = data.frame(matrix(, nrow = length(size_mw_table), ncol = length(duration_hr_table)))
  temp_3 = data.frame(matrix(, nrow = length(size_mw_table)*length(chem_table), ncol = length(duration_hr_table)))
  temp_4 = data.frame(matrix(, nrow = length(size_mw_table)*length(chem_table), ncol = length(duration_hr_table)*length(cycles_table)))
  temp_5 = data.frame(matrix(, nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table), ncol = length(duration_hr_table)*length(cycles_table)))
  
  
  # kw
  
  count_5 = 1
  
  for (i in lifetime_table) {
    
    count_4 = 1
    
    for (j in cycles_table) {
      
      count_3 = 1
      
      for (k in chem_table) {
        
        count_2 = 1
        
        for (l in size_mw_table) {
          
          count_1 = 1
          
          for (m in duration_hr_table) {
            
            temp = results_tot_2$`CapEx USD/kW`[results_tot_2$Duration.Hr==m & results_tot_2$Power.MW ==l & results_tot_2$Chemistry==k & results_tot_2$Cycles.per.Year==j & results_tot_2$Lifespan.Yr==i]
            temp_1[,count_1] = temp
            
            count_1 = count_1 + 1
            
          }
          
          temp_2[count_2,] = temp_1
          
          count_2 = count_2 + 1
          
        }
        
        temp_3[count_3:(count_3+length(size_mw_table)-1),] = temp_2
        
        count_3 = count_3 + length(size_mw_table)
        
      }
      
      temp_4[,count_4:(count_4 + length(duration_hr_table) - 1)] = temp_3
      
      count_4 = count_4 + length(duration_hr_table)
      
    }
    
    temp_5[count_5:(count_5 + length(size_mw_table)*length(chem_table) - 1),] = temp_4
    
    count_5 = count_5 + length(size_mw_table)*length(chem_table)
    
  }
  
  results_kW = temp_5
  
  results_kW_3d = abind(results_kW_3d, results_kW, along = 3)
  results_kWh_3d = abind(results_kWh_3d, results_kWh, along = 3)
  
}

results_kW_mean = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kW_median = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kW_std = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kW_5 = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kW_10 = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kW_90 = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kW_95 = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))


results_kWh_mean = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kWh_median = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kWh_std = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kWh_5 = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kWh_10 = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kWh_90 = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))
results_kWh_95 = data.frame(matrix(nrow = length(size_mw_table)*length(chem_table)*length(lifetime_table),ncol = length(duration_hr_table)*length(cycles_table)))


for (i in 1:(length(size_mw_table)*length(chem_table)*length(lifetime_table))) {
  
  for (j in 1:(length(duration_hr_table)*length(cycles_table))) {
    
    results_kW_mean[i,j] = mean(results_kW_3d[i,j,])
    results_kW_median[i,j] = median(results_kW_3d[i,j,])
    results_kW_std[i,j] = sd(results_kW_3d[i,j,])
    results_kW_5[i,j] = quantile(results_kW_3d[i,j,], 0.05)
    results_kW_10[i,j] = quantile(results_kW_3d[i,j,], 0.10)
    results_kW_90[i,j] = quantile(results_kW_3d[i,j,], 0.90)
    results_kW_95[i,j] = quantile(results_kW_3d[i,j,], 0.95)
    
    results_kWh_mean[i,j] = mean(results_kWh_3d[i,j,])
    results_kWh_median[i,j] = median(results_kWh_3d[i,j,])
    results_kWh_std[i,j] = sd(results_kWh_3d[i,j,])
    results_kWh_5[i,j] = quantile(results_kWh_3d[i,j,], 0.05)
    results_kWh_10[i,j] = quantile(results_kWh_3d[i,j,], 0.10)
    results_kWh_90[i,j] = quantile(results_kWh_3d[i,j,], 0.90)
    results_kWh_95[i,j] = quantile(results_kWh_3d[i,j,], 0.95)
    
  }
  
}

write.xlsx(results_kW_mean, file = "results_deg/results_kW_mean.xlsx")
write.xlsx(results_kW_median, file = "results_deg/results_kW_median.xlsx")
write.xlsx(results_kW_std, file = "results_deg/results_kW_std.xlsx")
write.xlsx(results_kW_5, file = "results_deg/results_kW_5.xlsx")
write.xlsx(results_kW_10, file = "results_deg/results_kW_10.xlsx")
write.xlsx(results_kW_90, file = "results_deg/results_kW_90.xlsx")
write.xlsx(results_kW_95, file = "results_deg/results_kW_95.xlsx")

write.xlsx(results_kWh_mean, file = "results_deg/results_kWh_mean.xlsx")
write.xlsx(results_kWh_median, file = "results_deg/results_kWh_median.xlsx")
write.xlsx(results_kWh_std, file = "results_deg/results_kWh_std.xlsx")
write.xlsx(results_kWh_5, file = "results_deg/results_kWh_5.xlsx")
write.xlsx(results_kWh_10, file = "results_deg/results_kWh_10.xlsx")
write.xlsx(results_kWh_90, file = "results_deg/results_kWh_90.xlsx")
write.xlsx(results_kWh_95, file = "results_deg/results_kWh_95.xlsx")


