#------------------------------------------------------------------------------
# arbitrage v peaker replacement #
#------------------------------------------------------------------------------

# Documents/Shell Research/peaker replacement/arbitrage vs frequency response 07_14_22

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

rm(list = ls())

library(readxl)
library(ggplot2)
library(RColorBrewer)
library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)
library(lemon)
library(waterfalls)
library(tidyverse)
library(cowplot)
library(ggpattern)

#------------------------------------------------------------------------------
# Data Loading and Cleaning #
#------------------------------------------------------------------------------

charge_raw = as.data.frame(read_excel("timeshift_charge.xlsx"))
discharge_raw = as.data.frame(read_excel("timeshift_discharge.xlsx"))
timeshift_existing = as.data.frame(read_excel("timeshift_long_april_14_22_allRTE_p95LFP.xlsx"))

dims_wide = dim(charge_raw)
dims_long = dim(timeshift_existing)

peaker_names = colnames(charge_raw)

results_long = data.frame(matrix(NA, nrow = dims_long[1], ncol = 7))
colnames(results_long) = c("facility_name", "facilid", "unitid", "date", "hour", "charge", "discharge")

results_long$facility_name = timeshift_existing$facility_name
results_long$facilid = timeshift_existing$facilid
results_long$unitid = timeshift_existing$unitid
results_long$date = timeshift_existing$date
results_long$hour = timeshift_existing$hour

temp_charge = rep(NA, dims_long[1])
temp_discharge = rep(NA, dims_long[1])

for (i in 1:dims_wide[2]) {

  start_idx = dims_wide[1] * (i-1) + 1
  end_idx = dims_wide[1] * i
  
  temp_charge[start_idx:end_idx] = charge_raw[,i]
  temp_discharge[start_idx:end_idx] = discharge_raw[,i]
  
}

results_long$charge = temp_charge
results_long$discharge = temp_discharge

temp = unique(paste(results_long$facilid, results_long$unitid, sep = " - "))

#  write.xlsx(results_long, "arbitrage_behavior_8_18_20_v2.xlsx")


