## mock RTE ##


rm(list = ls())

runs = 100000

eff_trans = runif(runs, min = 98.20, max = 99.53)/100 # need to turn into normal dist

loss_trans = 1 - eff_trans
loss_trans_2 = loss_trans

for(i in 1:length(loss_trans)) {
  
  loss_trans_2[i] = rnorm(1, mean = loss_trans[i], sd = 0.25 * loss_trans[i])
  
}

loss_inv = rnorm(runs, mean = 1.89, sd = 0.599)/100

eff_batt = (runif(runs, min = 98, max = 99)/100)^2

loss_therm = runif(runs, min = 0.5, max = 2.5)/100

loss_misc = runif(runs, min = 1, max = 5)/100

rte = (1 - loss_trans_2)^2 * (1 - loss_inv)^2 * eff_batt * (1 - loss_misc - loss_therm)


hist(rte)
summary (rte)
