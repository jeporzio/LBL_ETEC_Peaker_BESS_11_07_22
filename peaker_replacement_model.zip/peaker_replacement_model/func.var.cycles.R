#------------------------------------------------------------------------------
# function_var_cycles_sum #
#------------------------------------------------------------------------------

# Used in battery cost modeling

# preps variable cycles results

# NEED TO UPDATE TO REFLECT CHANGES ON func_li_BESS

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------

function_var_cycles_sum <- function(var_cycles) {
  
  var_cycles_sum = data.frame(`Tot` = numeric(), 
                              `STDev` = numeric(),
                              `5th P` = numeric(),
                              `95th P` = numeric(),
                              `Component` = factor(), 
                              `temp` = numeric(), 
                              `YPos_Cum` = numeric(), 
                              `YPos_Ind` = numeric(),
                              `City` = factor(),
                              `State` = factor(),
                              `Capacity MWh` = numeric(),
                              `Power MW` = numeric(),
                              `Duration Hr` = numeric(),
                              `Year` = numeric(),
                              `Lifespan Yr` = numeric(),
                              `Chemistry` = factor(),
                              `Fire Suppression` = numeric(),
                              `Cycles per Year` = numeric(),
                              `Depth of Discharge` = numeric())
  
  cycles = seq(1,501, by=50)
  count = 1
  count_8 = 1
  
  for (i in cycles) {
    
    var_cycles_sum[count,] = var_cycles[count_8,]
    var_cycles_sum$Tot[count] = sum(var_cycles$Mean[var_cycles$`Cycles per Year`==i])
    var_cycles_sum$STDev[count] = sum(var_cycles$STDev[var_cycles$`Cycles per Year`==i])
    var_cycles_sum$`5th P`[count] = sum(var_cycles$`5th P`[var_cycles$`Cycles per Year`==i])
    var_cycles_sum$`95th P`[count] = sum(var_cycles$`95th P`[var_cycles$`Cycles per Year`==i])
    
    count_8 = count_8 + 8
    count = count+1
    
  }
  
  var_cycles_sum$Component = "Tot"
  var_cycles_sum$City = var_cycles$City[1]
  var_cycles_sum$State = var_cycles$State[1]
  var_cycles_sum$Chemistry = var_cycles$Chemistry[1]
  
  colnames(var_cycles) = c("Tot", 
                           "STDev",
                           "5th P",
                           "95th P",
                           "Component", 
                           "temp", 
                           "YPos_Cum", 
                           "YPos_Ind",
                           "City",
                           "State",
                           "Capacity MWh",
                           "Power MW",
                           "Duration Hr",
                           "Year",
                           "Lifespan Yr",
                           "Chemistry",
                           "Fire Suppression",
                           "Cycles per Year",
                           "Depth of Discharge")
  
  return(var_cycles_sum)
  
}
