#------------------------------------------------------------------------------
# function_monte_carlo_plot #
#------------------------------------------------------------------------------

# Used in battery cost modeling

# preps func_monte_carlo results for plotting

# NEED TO UPDATE TO REFLECT CHANGES ON func_li_BESS

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)
library(magic)
library(Matrix)

source("func.monte.carlo.R")

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------

function_monte_carlo_plot <- function(City, # Average,
                                      State, # National,
                                      Power_MW, # 60 MW
                                      Duration, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                      Year, # 2020,
                                      Lifespan, # [15, 20],
                                      Chem,
                                      Fire,
                                      Cycle_per_year,
                                      DoD,
                                      m,
                                      Deg_opt,
                                      eBOS_MW,
                                      purchased_electricity,
                                      sold_electricity,
                                      refrigerant,
                                      peaker_name) {
  
  # DELETE BELOW
  
  # City = "Average"
  # State = "National"
  # Power_MW = 114 # 60 MW
  # Duration = 4 # [4, 3, 2, 1, 0.75, 0.5, 0.25]
  # Year = 2020 # 2020,
  # Lifespan = 7.5 # [15, 20],
  # Chem = "LFP Graphite SS"
  # Fire = 2001
  # Cycle_per_year = 1
  # DoD = 0.95
  # m = 10
  # Deg_opt = "Yes"
  # 
  # eBOS_MW = 65
  # 
  # purchased_electricity = "electricity.Solar.kWh"
  # sold_electricity = "electricity.NG.kWh"
  # refrigerant = "r410a.kg" # "r32.kg"
  # 
  # peaker_name = "Long Beach Generating Station - Unit 1"
  # 
  # n = 1
  
  # DELETE ABOVE
  
  
  Capacity_MWh = Power_MW * Duration
  
  n = 1
  runs_raw = function_monte_carlo(City, # Average,
                              State, # National,
                              Power_MW, # 60 MW
                              Duration, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                              Year, # 2020,
                              Lifespan, # [15, 20],
                              Chem,
                              Fire,
                              Cycle_per_year,
                              DoD,
                              m,
                              Deg_opt,
                              eBOS_MW,
                              purchased_electricity,
                              sold_electricity,
                              refrigerant,
                              peaker_name)
  
  
  ### Costs Organization ###
  
  runs = runs_raw[[1]] # added 8/30 # next section for costs
  
  results = data.frame(rowMeans(runs), 
                       rowStdevs(runs),
                       rowQuantiles(runs, prob = 0.05),
                       rowQuantiles(runs, prob = 0.95),
                       graph_order, 
                       c(1, 2, 3, 4, 5, 6, 7, 8), 
                       rep(as.character(Duration),8),
                       rep(1,8),
                       rep(2,8)
  )
  
  colnames(results) = c("Mean", "STDev", "5th P", "95th P", "Component", "temp", "Duration", "YPos_Cum", "YPos_Ind")
  
  results$Component = graph_order
  results$Component <- factor(results$Component, levels = results$Component[order(results$temp)])
  
  results$`YPos_Cum` =  c(results$Mean[8] + results$Mean[7] + results$Mean[6] + results$Mean[5] + results$Mean[4] + results$Mean[3] + results$Mean[2] + results$Mean[1],
                          results$Mean[8] + results$Mean[7] + results$Mean[6] + results$Mean[5] + results$Mean[4] + results$Mean[3] + results$Mean[2],
                          results$Mean[8] + results$Mean[7] + results$Mean[6] + results$Mean[5] + results$Mean[4] + results$Mean[3],
                          results$Mean[8] + results$Mean[7] + results$Mean[6] + results$Mean[5] + results$Mean[4],
                          results$Mean[8] + results$Mean[7] + results$Mean[6] + results$Mean[5],
                          results$Mean[8] + results$Mean[7] + results$Mean[6],
                          results$Mean[8] + results$Mean[7],
                          results$Mean[8]
  )
  
  results$`YPos_Ind` = c(results$Mean[1],
                         results$Mean[2],
                         results$Mean[3],
                         results$Mean[4],
                         results$Mean[5],
                         results$Mean[6],
                         results$Mean[7],
                         results$Mean[8]
  )
  
  
  results$Mean = round(results$Mean,2)
  results$STDev = round(results$STDev,2)
  results$`5th P` = round(results$`5th P`, 2)
  results$`95th P` = round(results$`95th P`, 2)
  
  City_col = rep(City, dim(results)[1])
  State_col = rep(State, dim(results)[1])
  Capacity_col = rep(Capacity_MWh, dim(results)[1])
  Power_col = rep(Power_MW, dim(results)[1])
  Duration_col = rep(Duration, dim(results)[1])
  Year_col = rep(Year, dim(results)[1])
  Lifespan_col = rep(Lifespan, dim(results)[1])
  Chem_col = rep(Chem, dim(results)[1])
  Fire_col = rep(Fire, dim(results)[1])
  Cycle_per_year_col = rep(Cycle_per_year, dim(results)[1])
  DoD_col = rep(DoD, dim(results)[1])
  
  results = cbind(results, 
                  City_col,
                  State_col,
                  Capacity_col,
                  Power_col,
                  Duration_col,
                  Year_col,
                  Lifespan_col,
                  Chem_col,
                  Fire_col,
                  Cycle_per_year_col,
                  DoD_col
  )
  
  results = subset(results, select = -c(Duration))
  
  colnames(results) = c("Mean", 
                        "STDev",
                        "5th P",
                        "95th P",
                        "Component", 
                        "temp", 
                        "YPos_Cum", 
                        "YPos_Ind",
                        "City",
                        "State",
                        "Capacity MWh",
                        "Power MW",
                        "Duration Hr",
                        "Year",
                        "Lifespan Yr",
                        "Chemistry",
                        "Fire Suppression",
                        "Cycles per Year",
                        "Depth of Discharge"
  )
  
  results$Mean = round(results$Mean, 0)
  results$STdev = round(results$STDev, 0)
  results$`Duration Hr` = as.character(results$`Duration Hr`)
  
  results_cost = results
  
  ### Materials Organization ###
  
  runs_mat = runs_raw[[2]]
  
  dim_runs_mat = dim(runs_mat)
  
  results_mat = data.frame(rowMeans(runs_mat), 
                       rowStdevs(runs_mat),
                       rowQuantiles(runs_mat, prob = 0.05),
                       rowQuantiles(runs_mat, prob = 0.95),
                       c("Battery", "Inverter", "Transformer", "Switchgear", 
                         "Conductor", "Conduits", "BMS", "Fire-Sup", 
                         "Thermal", "Batt House", "Inv House", "Foundation",
                         "Grading", "Trenching", "Backfill", "Hauling",
                         "Comm + Cont", "Gas Det", "Gas Det Cont", "Fire Det"), # components
                       c("MWh", "Quant", "Quant", "Quant", 
                         "Feet", "Feet", "Quant", "Cont Quant", 
                         "Cont Quant", "Cont Quant", "Inv Cont Quant", "Cu Yrd",
                         "Site Quant", "Cu Yrd", "Cu Yrd", "Cu Yrd",
                         "Quant", "Quant", "Quant", "Quant") # units
  )
  
  colnames(results_mat) = c("Mean", 
                            "STDev",
                            "5th P",
                            "95th P",
                            "Component", 
                            "Units")
  
  
  ### GHG Organization ###
  
  runs_ghg = runs_raw[[3]]
  dim_runs_ghg = dim(runs_ghg)
  
  results_ghg = data.frame(rowMeans(runs_ghg),
                           rowStdevs(runs_ghg),
                           rowQuantiles(runs_ghg, prob = 0.05),
                           rowQuantiles(runs_ghg, prob = 0.95),
                           row.names(runs_ghg),
                           c("Battery_Assembly", rep("BOS_Materials", 5),
                             "Battery_Materials", rep("BOS_Materials", 6),
                             "Purchased_Electricity",
                             "Sold_Electricity",
                             rep("Battery_Materials", 13))
  )
  
  colnames(results_ghg) = c("Mean", "STDev", "5th P", "95th P",
                            "Component", "Category")
  
  
  ### CO Organization ###
  
  runs_co = runs_raw[[4]]
  dim_runs_co = dim(runs_co)
  
  results_co = data.frame(rowMeans(runs_co),
                           rowStdevs(runs_co),
                           rowQuantiles(runs_co, prob = 0.05),
                           rowQuantiles(runs_co, prob = 0.95),
                           row.names(runs_co),
                          c("Battery_Assembly", rep("BOS_Materials", 5),
                            "Battery_Materials", rep("BOS_Materials", 6),
                            "Purchased_Electricity",
                            "Sold_Electricity",
                            rep("Battery_Materials", 13))
  )
  
  colnames(results_co) = c("Mean", "STDev", "5th P", "95th P",
                            "Component", "Category")
  
  
  ### NOx Organization ###
  
  runs_nox = runs_raw[[5]]
  dim_runs_nox = dim(runs_nox)
  
  results_nox = data.frame(rowMeans(runs_nox),
                           rowStdevs(runs_nox),
                           rowQuantiles(runs_nox, prob = 0.05),
                           rowQuantiles(runs_nox, prob = 0.95),
                           row.names(runs_nox),
                           c("Battery_Assembly", rep("BOS_Materials", 5),
                             "Battery_Materials", rep("BOS_Materials", 6),
                             "Purchased_Electricity",
                             "Sold_Electricity",
                             rep("Battery_Materials", 13))
  )
  
  colnames(results_nox) = c("Mean", "STDev", "5th P", "95th P",
                            "Component", "Category")
  
  
  ### SOx Organization ###
  
  runs_sox = runs_raw[[6]]
  dim_runs_sox = dim(runs_sox)
  
  results_sox = data.frame(rowMeans(runs_sox),
                           rowStdevs(runs_sox),
                           rowQuantiles(runs_sox, prob = 0.05),
                           rowQuantiles(runs_sox, prob = 0.95),
                           row.names(runs_sox),
                           c("Battery_Assembly", rep("BOS_Materials", 5),
                             "Battery_Materials", rep("BOS_Materials", 6),
                             "Purchased_Electricity",
                             "Sold_Electricity",
                             rep("Battery_Materials", 13))
  )
  
  colnames(results_sox) = c("Mean", "STDev", "5th P", "95th P",
                            "Component", "Category")

  
  ### PM25 Organization ###
  
  runs_pm25 = runs_raw[[7]]
  dim_runs_pm25 = dim(runs_pm25)
  
  results_pm25 = data.frame(rowMeans(runs_pm25),
                           rowStdevs(runs_pm25),
                           rowQuantiles(runs_pm25, prob = 0.05),
                           rowQuantiles(runs_pm25, prob = 0.95),
                           row.names(runs_pm25),
                           c("Battery_Assembly", rep("BOS_Materials", 5),
                             "Battery_Materials", rep("BOS_Materials", 6),
                             "Purchased_Electricity",
                             "Sold_Electricity",
                             rep("Battery_Materials", 13))
  )
  
  colnames(results_pm25) = c("Mean", "STDev", "5th P", "95th P",
                            "Component", "Category")
  
  
  ### VOC Organization ###
  
  runs_voc = runs_raw[[8]]
  dim_runs_voc = dim(runs_voc)
  
  results_voc = data.frame(rowMeans(runs_voc),
                           rowStdevs(runs_voc),
                           rowQuantiles(runs_voc, prob = 0.05),
                           rowQuantiles(runs_voc, prob = 0.95),
                           row.names(runs_voc),
                           c("Battery_Assembly", rep("BOS_Materials", 5),
                             "Battery_Materials", rep("BOS_Materials", 6),
                             "Purchased_Electricity",
                             "Sold_Electricity",
                             rep("Battery_Materials", 13))
  )
  
  colnames(results_voc) = c("Mean", "STDev", "5th P", "95th P",
                            "Component", "Category")
  
  
  
  ### Losses Organization ###
  
  runs_losses = runs_raw[[11]]
  dim_runs_losses = dim(runs_losses)
  
  results_losses = data.frame(rowMeans(runs_losses),
                           rowStdevs(runs_losses),
                           rowQuantiles(runs_losses, prob = 0.05),
                           rowQuantiles(runs_losses, prob = 0.95),
                           row.names(runs_losses))
  colnames(results_losses) = c("Mean", "STDev", "5th P", "95th P",
                            "losses Category")
  
  
  
  ### NPV Organization ###
  
  runs_NPV = runs_raw[[10]]
  dim_runs_NPV = dim(runs_NPV)
  
  NPV_means = rowMeans(runs_NPV, dims = 2)
  NPV_std = array(NA, c(dim_runs_NPV[1], dim_runs_NPV[2]))
  
  for (i in 1:dim_runs_NPV[1]) {
    
    for (j in 1:dim_runs_NPV[2]) {

      NPV_std[i,j] = sd(runs_NPV[i,j,])
      
    }
    
  }

  ### Cases (Y.input) Organization ###
  
  runs_input = runs_raw[[9]]
  dim_runs_input = dim(runs_input)
  
  results_input = data.frame(rowMeans(runs_input),
                           rowStdevs(runs_input),
                           rowQuantiles(runs_input, prob = 0.05),
                           rowQuantiles(runs_input, prob = 0.95),
                           row.names(runs_input),
                           c("Battery_Assembly", rep("BOS_Materials", 5),
                             "Battery_Materials", rep("BOS_Materials", 6),
                             "Purchased_Electricity",
                             "Sold_Electricity",
                             rep("Battery_Materials", 13))
  )
  
  colnames(results_input) = c("Mean", "STDev", "5th P", "95th P",
                            "Component", "Category")
  
  
  ### Final Results Organization ###
  
  results = list(results_cost, results_mat, results_ghg, results_co, results_nox,
                 results_sox, results_pm25, results_voc, results_input, NPV_means,
                 results_losses, NPV_std) # , results_mat_input_p95, results_mat_input_p5)
  
  return(results)
  
}