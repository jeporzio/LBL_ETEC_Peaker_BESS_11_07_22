#------------------------------------------------------------------------------
# func_LCA_plot #
#------------------------------------------------------------------------------

# Used to clean LCA outputs from func.monte.carlo.plot for plotting

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------


function_LCA_plot <- function(df_LCA) {
  
  # df_LCA = test_mcp_LFP[[3]] # DELETE ME
  dim_df_LCA = dim(df_LCA)
  
  plot_categories = unique(df_LCA$Category)
  df_categories = data.frame(matrix(NA, nrow = length(plot_categories), ncol = dim_df_LCA[2]-1))
  colnames(df_categories) = c("Mean", "STDev", "5th P", "95th P", "Category")
  
  results = vector(mode = "list", length = length(plot_categories) + 1)
  
  for (i in 1:length(plot_categories)) {
    
    #df creation for each category - has values for each component in each category
    assign(paste("df",plot_categories[i], sep = "_"), df_LCA[df_LCA$Category == plot_categories[i],])
    
    df_categories$Mean[i] = sum(df_LCA$Mean[df_LCA$Category==plot_categories[i]])
    df_categories$STDev[i] = sum(df_LCA$STDev[df_LCA$Category==plot_categories[i]])
    df_categories$`5th P`[i] = sum(df_LCA$`5th P`[df_LCA$Category==plot_categories[i]])
    df_categories$`95th P`[i] = sum(df_LCA$`95th P`[df_LCA$Category==plot_categories[i]])
    df_categories$Category[i] = str_replace(plot_categories[i], "_", " ")
    
    results[[i+1]] = get(paste("df",plot_categories[i], sep = "_"))
    
  }
  
  results[[1]] = df_categories
  
  
  
  ### change system_other_list to change what's included in other ###
  
  system_other_list = c("inverter.count", "Switchgear.count", "Conductor.ft",
                        "Conduit.ft", "Battcont.cont", "Invcont.cont",
                        "Found.quant", "Rack.cont")
  
  system_oth_mean = 0
  system_oth_STDev = 0
  system_oth_5thP = 0
  system_oth_95thP = 0
  system_oth_row = rep(NA,6)
  
  for (j in system_other_list) {
    
    system_oth_mean = system_oth_mean + results[[3]]$Mean[results[[3]]$Component==j]
    system_oth_STDev = system_oth_STDev + results[[3]]$STDev[results[[3]]$Component==j]
    system_oth_5thP = system_oth_5thP + results[[3]]$`5th P`[results[[3]]$Component==j]
    system_oth_95thP = system_oth_95thP + results[[3]]$`95th P`[results[[3]]$Component==j]
    
    results[[3]] = results[[3]][!(results[[3]]$Component==j),]
    
  }
  
  system_row_names = row.names(results[[3]])
  results[[3]] = rbind(results[[3]], system_oth_row)
  row.names(results[[3]]) = c(system_row_names, "Other BOS")
  
  results[[3]]["Other BOS",]$Mean = system_oth_mean
  results[[3]]["Other BOS",]$STDev = system_oth_STDev
  results[[3]]["Other BOS",]$`5th P` = system_oth_5thP
  results[[3]]["Other BOS",]$`95th P` = system_oth_95thP
  results[[3]]["Other BOS",]$Component = "Other BOS"
  results[[3]]["Other BOS",]$Category = "BOS_Materials"
  
  
  
  ### change battery_other_list to change what's included in other ###
  
  batt_other_list = c("BMS.kg", "LiPF6.kg", "PVFD.kg", "ethylene.carbonate.kg", 
                      "dimethyl.carbonate.kg", "HDPE.kg", "PP.kg", "PET.kg", 
                      "NMP.kg", "carbon.black.kg", "copper.kg", "aluminum.virgin.wrought.kg")
  
  batt_oth_mean = 0
  batt_oth_STDev = 0
  batt_oth_5thP = 0
  batt_oth_95thP = 0
  batt_oth_row = rep(NA,6)
  
  for (k in batt_other_list) {
    
    batt_oth_mean = batt_oth_mean + results[[4]]$Mean[results[[4]]$Component==k]
    batt_oth_STDev = (batt_oth_STDev^2 + results[[4]]$STDev[results[[4]]$Component==k]^2)^0.5
    batt_oth_5thP = batt_oth_5thP + results[[4]]$`5th P`[results[[4]]$Component==k]
    batt_oth_95thP = batt_oth_95thP + results[[4]]$`95th P`[results[[4]]$Component==k]
    
    results[[4]] = results[[4]][!(results[[4]]$Component==k),]
    
  }
  
  batt_row_names = row.names(results[[4]])
  results[[4]] = rbind(results[[4]], batt_oth_row)
  row.names(results[[4]]) = c(batt_row_names, "Other Battery Mat.")
  
  results[[4]]["Other Battery Mat.",]$Mean = batt_oth_mean
  results[[4]]["Other Battery Mat.",]$STDev = batt_oth_STDev
  results[[4]]["Other Battery Mat.",]$`5th P` = batt_oth_5thP
  results[[4]]["Other Battery Mat.",]$`95th P` = batt_oth_95thP
  results[[4]]["Other Battery Mat.",]$Component = "Other Battery Mat."
  results[[4]]["Other Battery Mat.",]$Category = "Battery_Materials"
  
  results[[7]] = rbind(results[[2]], results[[3]], results[[4]], results[[5]], results[[6]])
  
  # renaming items for graphing
  
  results[[7]][results[[7]]=="Battery_Assembly"] = "Module Mat. and Asm." #"Battery Assembly"
  results[[7]][results[[7]]=="BOS_Materials"] = "Energy Storage BOS"
  results[[7]][results[[7]]=="Battery_Materials"] = "Module Mat. and Asm."
  results[[7]][results[[7]]=="Purchased_Electricity"] = "Charge/Discharge" # "Purchased Electricity"
  results[[7]][results[[7]]=="Sold_Electricity"] = "Charge/Discharge" # "Offset Electricity"
  
  results[[7]][results[[7]]=="battery.assembly.kWh"] = "Battery Assembly"
  results[[7]][results[[7]]=="transformer.count"]  = "Transformer"
  results[[7]][results[[7]]=="Fire.cont"] = "Fire Suppression"
  results[[7]][results[[7]]=="HVAC.cont"] = "HVAC"
  results[[7]][results[[7]]=="graphite.kg"] = "Graphite"
  results[[7]][results[[7]]=="copper.kg"] = "Copper"
  results[[7]][results[[7]]=="aluminum.virgin.wrought.kg"] = "Aluminum"
  results[[7]][results[[7]]=="purchased.electricity.cycle"] = "Purchased Electricity"
  results[[7]][results[[7]]=="sold.electricity.cycle"] = "Offset Electricity"
  
  results[[7]][results[[7]]=="NCA.kg"] = "NCA Cathode"
  results[[7]][results[[7]]=="LFP-HT.kg"] = "LFP Cathode (Hydeothermal Prod.) "
  results[[7]][results[[7]]=="NMC-811.kg"] = "NMC-811 Cathode"
  results[[7]][results[[7]]=="LMO.kg"] = "LMO Cathode"
  results[[7]][results[[7]]=="NMC-111.kg"] = "NMC-111 Cathode"
  results[[7]][results[[7]]=="NMC-532,kg"] = "NMC-532 Cathode"
  results[[7]][results[[7]]=="NMC-622.kg"] = "NMC-622 Cathode"
  results[[7]][results[[7]]=="NMC-811.kg"] = "NMC-811 Cathode"
  results[[7]][results[[7]]=="LFP-SS.kg"] = "LFP Cathode (Solid State Prod.) "
  
  
  batt_factor = ceiling(Lifetime / Lifespan)
  results[[7]]$Mean[results[[7]]$Category=="Module Mat. and Asm."] = results[[7]]$Mean[results[[7]]$Category=="Module Mat. and Asm."] * batt_factor
  results[[7]]$STDev[results[[7]]$Category=="Module Mat. and Asm."] = ((results[[7]]$STDev[results[[7]]$Category=="Module Mat. and Asm."])^2 * batt_factor)^0.5
  
  results[[8]] = subset(results[[7]], select = -c(Component, `5th P`, `95th P`))
  temp_results8 = results[[8]]
  results[[8]] = ddply(results[[8]], "Category", numcolwise(sum))
  
  for (m in unique(results[[8]]$Category)) {
    
    results[[8]]$STDev[results[[8]]$Category==m]= sum(temp_results8$STDev[temp_results8$Category==m]^2)^0.5
    
  }
  
  
  
  cathode_name = results[[7]][results[[7]]$Category=="Module Mat. and Asm.",]
  cathode_name = cathode_name$Component[!(cathode_name$Component=="Battery Assembly" | cathode_name$Component=="Graphite" | cathode_name$Component=="Other Battery Mat.")]

  
  results[[7]]$Category = factor(results[[7]]$Category, levels = c("Module Mat. and Asm.", "Energy Storage BOS", "Charge/Discharge"))
  results[[7]]$Component = factor(results[[7]]$Component, levels = c("Other Battery Mat.", "Graphite", cathode_name, "Battery Assembly", "Other BOS", "Transformer", "Fire Suppression", "HVAC", "Purchased Electricity", "Offset Electricity"))
  
  
  
  return(results)
  
}
  

