#------------------------------------------------------------------------------
# cost breakdown #
#------------------------------------------------------------------------------

# Documents/Shell Research/peaker replacement/cost_model_8_30_21

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

rm(list = ls())

fin_runs = 100

library(readxl)
library(ggplot2)
library(RColorBrewer)
library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)
library(lemon)
library(waterfalls)
library(tidyverse)
library(cowplot)
library(ggpattern)

source("func.lnnorm.dist.R")
source("func.DoD.rec.R")
source("func.li.BESS.R")
source("func.monte.carlo.R")
source("func.monte.carlo.plot.R")
source("func.var.cycles.R")
source("func.results.chem.stats.R")
source("func.LCA.plot.standard.R")
source("func.LCA.plot.waterfall.R")
source("func.LCA.plot.percent.R")
source("func.npv.plot.waterfall.R")


#------------------------------------------------------------------------------
#  scenario parameters #
#------------------------------------------------------------------------------

chem_loop = c("LFP Graphite SS", "NCA Graphite", "NMC Graphite")
irr_loop = c(0.03, 0.05, 0.07)
Lifetime = c(15, 20)
Lifespan_loop = c(7.5, 10)
scc_loop = c(51/1000, 185/1000)






#------------------------------------------------------------------------------
#  Inputs, Constants, and Other Prep #
#------------------------------------------------------------------------------

cbpalette = c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
cbpalette5 <- c("Module Materials & Assembly" = "#88CCEE", 
                 "Energy Storage BOS"  = "#CC6677", 
                 "Battery Charging & Losses"  = "#DDCC77", 
                 "Offset Electricity" = "#117733", 
                 "Net Emissions" = "#332288")
cbpalette4 = c("#E69F00", "#009E73", "#0072B2", "#CC79A7")

                                     
hex_codes = hue_pal()(15)
hex_codes1 = hex_codes[1:2]
hex_codes2 = hex_codes[3:9]
hex_codes3 = hex_codes[10:15]


runs = 100
runs_2 = 1

scc = 51/1000 # $/kg
irr = 0.05

Lifespan = 10 # [7.5, 10] years before battery replacement

Lifetime = 20 # [15, 20] facility lifetime

# 
# City = "Average"
# State = "National"
# Power_MW = 50
# Duration = 4
# Year = 2020
# Lifespan = 7.5
# Chem = "NMC Graphite"
# Fire = 2001
# Cycle_per_year = 450
# DoD = 0.9
# n = 1
# Deg_opt = "Yes"


graph_order = c("Developer Costs", 
                "Sales Tax", 
                "Inst. and Labor", 
                "Structural BOS", 
                "Electrical BOS",
                "Container BOS",
                "Inverter",
                "Battery")
graph_order = factor(graph_order)

#------------------------------------------------------------------------------
# Data Loading #
#------------------------------------------------------------------------------

eq_spacing = read_excel("equipment_spacing.xlsx")

site_hours = read_excel("site_hours.xlsx")

Batt_Costs = read_excel("batt_chem_costs.xlsx", sheet = "Batt_Costs_Adj")

Years = data.matrix(Batt_Costs[, 2])

Overdesign = read_excel("degredation_overdesign.xlsx", sheet = "Overdesign")

Price_Index_City_State = read_excel("state_cost_index.xlsx")

Permit_State = read_excel("permit.xlsx")

Chem_Mult = read_excel("chem_mult_v3.xlsx", sheet = "BNEF and Func")

Dur_Table = read_excel("dur_table.xlsx")

Sales_Tax_Table = read_excel("sales_tax.xlsx")

MV_Trans_Costs = read_excel("mv_trans_costs.xlsx")

Chemistry_Cycles_Life = read_excel("cycles_use_chemistry.xlsx", sheet = "Chemistry")

Use_Cycles_per_Year = read_excel("cycles_use_chemistry.xlsx", sheet = "Application")

Transformer_Eff = read_excel("transformer_efficiency.xlsx")

Cycle_Life = read_excel("cycle_lifes.xlsx")

Shelf_Life = read_excel("shelf_lifes.xlsx")

Battery_Eff_Charge = read_excel("battery_efficiency.xlsx", sheet = "charging")

Battery_Eff_Dis = read_excel("battery_efficiency.xlsx", sheet = "discharging")

Confidence_Interval = read_excel("confidence_intervals.xlsx")

Duration_DoD = read_excel("duration_dod.xlsx")

Battery_materials = read_excel("Battery_Materials.xlsx")

Li_ion_Battery_LCA = read_excel("Li_ion_Battery_LCA_data.xlsx")

io_data_LCA = read_excel("Complete_Working_IO_Impact_Vectors.xlsx", sheet = "IO")
co2_data_LCA = read_excel("Complete_Working_IO_Impact_Vectors.xlsx", sheet = "CO2")
ch4_data_LCA = read_excel("Complete_Working_IO_Impact_Vectors.xlsx", sheet = "CH4")
n2o_data_LCA = read_excel("Complete_Working_IO_Impact_Vectors.xlsx", sheet = "N2O")
co_data_LCA = read_excel("Complete_Working_IO_Impact_Vectors.xlsx", sheet = "CO")
nox_data_LCA = read_excel("Complete_Working_IO_Impact_Vectors.xlsx", sheet = "NOX")
so2_data_LCA = read_excel("Complete_Working_IO_Impact_Vectors.xlsx", sheet = "CO2")
pm25_data_LCA = read_excel("Complete_Working_IO_Impact_Vectors.xlsx", sheet = "PM25")
voc_data_LCA = read_excel("Complete_Working_IO_Impact_Vectors.xlsx", sheet = "VOC")

plant_profits = read_excel("Plant Elec Use.xlsx")

elec_prices = read_excel("Plant Elec Use.xlsx", sheet = "Prices")

# batt_damages_raw = read_excel("batt_damages_02_15_22.xlsx")
batt_damages_raw = read_excel("batt_damages_02_15_22_updated.xlsx")


#------------------------------------------------------------------------------
# For loop scenarios
#------------------------------------------------------------------------------

chem_loop = c("NMC Graphite") # c("LFP Graphite SS", "NCA Graphite", "NMC Graphite")
irr_loop = c(0.03, 0.05, 0.07)
Lifetime_loop = c(15, 20)
scc_loop = c(51/1000, 185/1000)

for (chem_var in chem_loop) {
  
  for (irr_var in irr_loop) {
    
    for (Lifetime_var in Lifetime_loop) {
      
      # Lifetime_var = 20
      
      if (Lifetime_var==15) {Lifespan_var=7.5}
      
      if (Lifetime_var==20) {Lifespan_var=10}
      
        for (scc_var in scc_loop) {
          
          # Delete Below #
          
          chem_var = "LFP Graphite SS"
          irr_var = 0.03
          Lifetime_var = 20
          Lifespan_var = 10
          scc_var = 51/1000
          
          # Delete Above #
          
  
          irr = irr_var
          Lifetime = Lifetime_var
          scc = scc_var
          
          Lifespan = Lifespan_var
          
          
          #------------------------------------------------------------------------------
          # Sub Inputs # MIGHT WANT TO CHANGE TO READ AN EXCEL FOR EASE
          #------------------------------------------------------------------------------
          
          base_price_batt = 218 # BNEF 2019
          chem_price_base = 156
          
          Module_size_kWh = 10
          Modules_per_rack = 20
          rack_per_cont = 12
          
          Container_Cap_MWh = rack_per_cont * Modules_per_rack * Module_size_kWh / 1000
          
          
          # Container_Cap_MWh = 2.5
          Container_Space_ft = 10
          
          
          Inv_Size_MW = 2.5
          
          
          MV_Trans_Size_MW = 2.5
          MV_Switch_Size_MW = 9.135
          MV_Trans_Length = 6
          MV_Trans_Width = 8.25
          MV_Trans_Pad_Length = 6.33
          MV_Trans_Pad_Width = 8.67
          MV_Switch_Length = 10.33
          MV_Switch_Width = 3
          MV_Switch_Space_ft = 10
          
          DC_Voltage = 800
          LV_AC_Voltage = 550
          MV_AC_Voltage = 34500
          Intercon_Voltage = 112000
          Intercon_Limit_MW = 100
          Intercon_Length_ft = 1000
          Intercon_Trans_Size_MW = 25
          Intercon_Switch_Size_MW = Intercon_Trans_Size_MW # check here
          
          Idx_2020 = 100
          Idx_2018 = 93.2
          Cost_Adj_2020 = Idx_2018/Idx_2020
          
          # Module_size_kWh = 10 # [5, 10]
          Module_install_time = 1 # hours
          
          EV_stat_adj = 1.26
          C = 4
          C_half = C/2
          
          
          Cont_type = "40 ft" # "40 ft" # ["40 ft", "20 ft", "Cabinet"]
          
          Inv_type = "20 ft" # ["20 ft", "Cabinet", "In_Batt"]
          
          therm_tech =  "HVAC" #  "HVAC" # ["HVAC", "Cell"]
          
          # rack_per_cont = 10
          
          Config = "Conv" # ["Conv", "Tesla"]
          
          Intercon_Level = 0 # [0 - Distribution, 1 - Transmission]
          
          
          
          plant_type = "Nth" # ["Pilot", "Nth", "Unspec"]
          batt_assembly_scen = "Max_therm" # ["Max_therm", "Min_therm", "Unspec"]
          batt_therm_fuel_type = "Nat_gas" # ["Nat_gas", "Coal", "Unspec"]
          
          batt_assembly_input = c(plant_type, batt_assembly_scen, batt_therm_fuel_type)
          
          discount_series = seq(from = 0, to = Lifetime)
          discount_series = (1/(1+irr)^discount_series)
          
          #------------------------------------------------------------------------------
          # Working Space
          #------------------------------------------------------------------------------
          
          
          # test = function_li_BESS("Average",
          #                         "National",
          #                         50,
          #                         4,
          #                         2020,
          #                         7.5,
          #                         "NMC Graphite 111",
          #                         2001,
          #                         251,
          #                         0.8,
          #                         1,
          #                         "Yes",
          #                         50)
          # 
          # # LCA_dim = dim(test[[3]])
          # 
          # 
          # test_mc = function_monte_carlo("Average",
          #                            "National",
          #                            50,
          #                            4,
          #                            2020,
          #                            7.5,
          #                            "NMC Graphite 111",
          #                            2001,
          #                            251,
          #                            0.8,
          #                            10,
          #                            "Yes",
          #                            25)
          
          # City = "Average"
          # State = "National"
          # Power_MW = 120 # 60 MW
          # Duration = 4 # [4, 3, 2, 1, 0.75, 0.5, 0.25]
          # Year = 2020 # 2020,
          # Lifespan = 7.5 # [15, 20],
          # Chem = "NMC Graphite 811"
          # Fire = 2001
          # Cycle_per_year = 28
          # DoD = 0.95
          # m = 10
          # Deg_opt = "Yes"
          # 
          # eBOS_MW = 51
          # 
          # purchased_electricity = "electricity.Solar.kWh"
          # sold_electricity = "electricity.NG.kWh"
          # refrigerant = "r410a.kg"
          # 
          # peaker_name = "Riverside Energy Resource Center - Unit 4"
          # 
          # n = 1
          
          #------------------------------------------------------------------------------
          # Long Beach 1 # Median electricity offset
          #------------------------------------------------------------------------------
          
          long_beach_1 = function_monte_carlo_plot("Average",
                                                   "National",
                                                   114,
                                                   4,
                                                   2020,
                                                   Lifespan,
                                                   chem_var, # "LFP Graphite SS",
                                                   2001,
                                                   24, # possibly change this to be a distribution of cycles
                                                   0.95,
                                                   fin_runs,
                                                   "Yes",
                                                   65,
                                                   "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                   "electricity.NG.kWh", # "electricity.NG.kWh"
                                                   "r410a.kg", # "r410a.kg", "r32.kg"
                                                   "Long Beach Generating Station - Unit 1") 
          
          
          long_beach_1_cost = long_beach_1[[1]]
          
          long_beach_1_ghg_standard = function_LCA_plot_standard(long_beach_1[[3]], long_beach_1[[11]])
          long_beach_1_co_standard = function_LCA_plot_standard(long_beach_1[[4]], long_beach_1[[11]])
          long_beach_1_nox_standard = function_LCA_plot_standard(long_beach_1[[5]], long_beach_1[[11]])
          long_beach_1_sox_standard = function_LCA_plot_standard(long_beach_1[[6]], long_beach_1[[11]])
          long_beach_1_pm25_standard = function_LCA_plot_standard(long_beach_1[[7]], long_beach_1[[11]])
          long_beach_1_voc_standard = function_LCA_plot_standard(long_beach_1[[8]], long_beach_1[[11]])
          
          long_beach_1_ghg_waterfall = function_LCA_plot_waterfall(long_beach_1[[3]], long_beach_1[[11]], 0, "Long Beach Generating Station - Unit 1", "GWP", batt_damages_raw, "Long Beach 1")
          long_beach_1_co_waterfall = function_LCA_plot_waterfall(long_beach_1[[4]], long_beach_1[[11]], 0, "Long Beach Generating Station - Unit 1", "GWP", batt_damages_raw, "Long Beach 1")
          long_beach_1_nox_waterfall = function_LCA_plot_waterfall(long_beach_1[[5]], long_beach_1[[11]], 0, "Long Beach Generating Station - Unit 1", "GWP", batt_damages_raw, "Long Beach 1")
          long_beach_1_sox_waterfall = function_LCA_plot_waterfall(long_beach_1[[6]], long_beach_1[[11]], 0, "Long Beach Generating Station - Unit 1", "GWP", batt_damages_raw, "Long Beach 1")
          long_beach_1_pm25_waterfall = function_LCA_plot_waterfall(long_beach_1[[7]], long_beach_1[[11]], 0, "Long Beach Generating Station - Unit 1", "GWP", batt_damages_raw, "Long Beach 1")
          long_beach_1_voc_waterfall = function_LCA_plot_waterfall(long_beach_1[[8]], long_beach_1[[11]], 0, "Long Beach Generating Station - Unit 1", "GWP", batt_damages_raw, "Long Beach 1")
          
          long_beach_1_ghg_percent = function_LCA_plot_percent(long_beach_1[[3]], long_beach_1[[11]])
          long_beach_1_co_percent = function_LCA_plot_percent(long_beach_1[[4]], long_beach_1[[11]])
          long_beach_1_nox_percent = function_LCA_plot_percent(long_beach_1[[5]], long_beach_1[[11]])
          long_beach_1_sox_percent = function_LCA_plot_percent(long_beach_1[[6]], long_beach_1[[11]])
          long_beach_1_pm25_percent = function_LCA_plot_percent(long_beach_1[[7]], long_beach_1[[11]])
          long_beach_1_voc_percent = function_LCA_plot_percent(long_beach_1[[8]], long_beach_1[[11]])
          
          long_beach_1_npv = function_npv_plot_waterfall(long_beach_1[[10]], long_beach_1[[12]],
                                                         batt_damages_raw, discount_series,
                                                         "Long Beach Generating Station - Unit 1",
                                                         "Long Beach 1",
                                                         plant_profits, elec_prices,
                                                         "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(long_beach_1_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Long Beach Generating Station Unit 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = long_beach_1_cost$YPos_Ind + 2* long_beach_1_cost$STDev + 14, label = paste(long_beach_1_cost$Mean, '+/-', 2* long_beach_1_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_1_cost_breakdown", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(long_beach_1_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Long Beach Generating Station Unit 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = long_beach_1_cost$`Duration Hr`[1], 
                     y = sum(long_beach_1_cost$YPos_Ind) + 2*sum(long_beach_1_cost$STDev^2)^0.5 + 15, label = paste(sum(long_beach_1_cost$Mean), '+/-', round(2*sum(long_beach_1_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_1_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Long Beach Generating Station Unit 1 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = long_beach_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                   xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                   ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = long_beach_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                               last(group.id),
                                                                               group.id+0.25), 
                                                                      xend=ifelse(group.id == last(group.id),
                                                                                  last(group.id),
                                                                                  group.id+0.75), 
                                                                      y=ifelse(end.id == 1,
                                                                               end.bar,
                                                                               # these will be removed once we set the y limits
                                                                               max(end.bar)*2*99999999999), 
                                                                      yend=ifelse(end.id == 1,
                                                                                  end.bar,
                                                                                  # these will be removed once we set the y limits
                                                                                  max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = long_beach_1_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(long_beach_1_ghg_waterfall[[10]]$Mean) - sum(long_beach_1_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(long_beach_1_ghg_waterfall[[10]]$Mean) + sum(long_beach_1_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = long_beach_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_1_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Long Beach Generating Station Unit 1 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = long_beach_1_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                        xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                        ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = long_beach_1_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                    last(group.id),
                                                                    group.id+0.25), 
                                                           xend=ifelse(group.id == last(group.id),
                                                                       last(group.id),
                                                                       group.id+0.75), 
                                                           y=ifelse(end.id == 1,
                                                                    end.bar,
                                                                    # these will be removed once we set the y limits
                                                                    max(end.bar)*2*99999999999), 
                                                           yend=ifelse(end.id == 1,
                                                                       end.bar,
                                                                       # these will be removed once we set the y limits
                                                                       max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = long_beach_1_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_1_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          #------------------------------------------------------------------------------
          # Long Beach 2 # 
          #------------------------------------------------------------------------------
          
          long_beach_2 = function_monte_carlo_plot("Average",
                                                   "National",
                                                   109,
                                                   4,
                                                   2020,
                                                   Lifespan,
                                                   chem_var, # "LFP Graphite SS",
                                                   2001,
                                                   24, # possibly change this to be a distribution of cycles
                                                   0.95,
                                                   fin_runs,
                                                   "Yes",
                                                   66,
                                                   "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                   "electricity.NG.kWh", # "electricity.NG.kWh"
                                                   "r410a.kg", # "r410a.kg", "r32.kg"
                                                   "Long Beach Generating Station - Unit 2") 
          
          
          long_beach_2_cost = long_beach_2[[1]]
          
          long_beach_2_ghg_standard = function_LCA_plot_standard(long_beach_2[[3]], long_beach_2[[11]])
          long_beach_2_co_standard = function_LCA_plot_standard(long_beach_2[[4]], long_beach_2[[11]])
          long_beach_2_nox_standard = function_LCA_plot_standard(long_beach_2[[5]], long_beach_2[[11]])
          long_beach_2_sox_standard = function_LCA_plot_standard(long_beach_2[[6]], long_beach_2[[11]])
          long_beach_2_pm25_standard = function_LCA_plot_standard(long_beach_2[[7]], long_beach_2[[11]])
          long_beach_2_voc_standard = function_LCA_plot_standard(long_beach_2[[8]], long_beach_2[[11]])
          
          long_beach_2_ghg_waterfall = function_LCA_plot_waterfall(long_beach_2[[3]], long_beach_2[[11]], 0, "Long Beach Generating Station - Unit 2", "GWP", batt_damages_raw, "Long Beach 2")
          long_beach_2_co_waterfall = function_LCA_plot_waterfall(long_beach_2[[4]], long_beach_2[[11]], 0, "Long Beach Generating Station - Unit 2", "GWP", batt_damages_raw, "Long Beach 2")
          long_beach_2_nox_waterfall = function_LCA_plot_waterfall(long_beach_2[[5]], long_beach_2[[11]], 0, "Long Beach Generating Station - Unit 2", "GWP", batt_damages_raw, "Long Beach 2")
          long_beach_2_sox_waterfall = function_LCA_plot_waterfall(long_beach_2[[6]], long_beach_2[[11]], 0, "Long Beach Generating Station - Unit 2", "GWP", batt_damages_raw, "Long Beach 2")
          long_beach_2_pm25_waterfall = function_LCA_plot_waterfall(long_beach_2[[7]], long_beach_2[[11]], 0, "Long Beach Generating Station - Unit 2", "GWP", batt_damages_raw, "Long Beach 2")
          long_beach_2_voc_waterfall = function_LCA_plot_waterfall(long_beach_2[[8]], long_beach_2[[11]], 0, "Long Beach Generating Station - Unit 2", "GWP", batt_damages_raw, "Long Beach 2")
          
          long_beach_2_ghg_percent = function_LCA_plot_percent(long_beach_2[[3]], long_beach_2[[11]])
          long_beach_2_co_percent = function_LCA_plot_percent(long_beach_2[[4]], long_beach_2[[11]])
          long_beach_2_nox_percent = function_LCA_plot_percent(long_beach_2[[5]], long_beach_2[[11]])
          long_beach_2_sox_percent = function_LCA_plot_percent(long_beach_2[[6]], long_beach_2[[11]])
          long_beach_2_pm25_percent = function_LCA_plot_percent(long_beach_2[[7]], long_beach_2[[11]])
          long_beach_2_voc_percent = function_LCA_plot_percent(long_beach_2[[8]], long_beach_2[[11]])
          
          long_beach_2_npv = function_npv_plot_waterfall(long_beach_2[[10]], long_beach_2[[12]],
                                                         batt_damages_raw, discount_series,
                                                         "Long Beach Generating Station - Unit 2",
                                                         "Long Beach 2",
                                                         plant_profits, elec_prices,
                                                         "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(long_beach_2_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Long Beach Generating Station Unit 2 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = long_beach_2_cost$YPos_Ind + 2* long_beach_2_cost$STDev + 14, label = paste(long_beach_2_cost$Mean, '+/-', 2* long_beach_2_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_2_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(long_beach_2_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Long Beach Generating Station Unit 2 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = long_beach_2_cost$`Duration Hr`[1], 
                     y = sum(long_beach_2_cost$YPos_Ind) + 2*sum(long_beach_2_cost$STDev^2)^0.5 + 15, label = paste(sum(long_beach_2_cost$Mean), '+/-', round(2*sum(long_beach_2_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_2_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Long Beach Generating Station Unit 2 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = long_beach_2_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                   xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                   ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = long_beach_2_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                               last(group.id),
                                                                               group.id+0.25), 
                                                                      xend=ifelse(group.id == last(group.id),
                                                                                  last(group.id),
                                                                                  group.id+0.75), 
                                                                      y=ifelse(end.id == 1,
                                                                               end.bar,
                                                                               # these will be removed once we set the y limits
                                                                               max(end.bar)*2*99999999999), 
                                                                      yend=ifelse(end.id == 1,
                                                                                  end.bar,
                                                                                  # these will be removed once we set the y limits
                                                                                  max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = long_beach_2_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(long_beach_2_ghg_waterfall[[10]]$Mean) - sum(long_beach_2_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(long_beach_2_ghg_waterfall[[10]]$Mean) + sum(long_beach_2_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = long_beach_2_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_2_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Long Beach Generating Station Unit 2 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = long_beach_2_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                        xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                        ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = long_beach_2_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                    last(group.id),
                                                                    group.id+0.25), 
                                                           xend=ifelse(group.id == last(group.id),
                                                                       last(group.id),
                                                                       group.id+0.75), 
                                                           y=ifelse(end.id == 1,
                                                                    end.bar,
                                                                    # these will be removed once we set the y limits
                                                                    max(end.bar)*2*99999999999), 
                                                           yend=ifelse(end.id == 1,
                                                                       end.bar,
                                                                       # these will be removed once we set the y limits
                                                                       max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = long_beach_2_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_2_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          #------------------------------------------------------------------------------
          # Long Beach 3 # 
          #------------------------------------------------------------------------------
          
          long_beach_3 = function_monte_carlo_plot("Average",
                                                   "National",
                                                   109, # size
                                                   4,
                                                   2020,
                                                   Lifespan,
                                                   chem_var, # "LFP Graphite SS",
                                                   2001,
                                                   24, # possibly change this to be a distribution of cycles
                                                   0.95,
                                                   fin_runs,
                                                   "Yes",
                                                   66,
                                                   "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                   "electricity.NG.kWh", # "electricity.NG.kWh"
                                                   "r410a.kg", # "r410a.kg", "r32.kg"
                                                   "Long Beach Generating Station - Unit 3") 
          
          
          long_beach_3_cost = long_beach_3[[1]]
          
          long_beach_3_ghg_standard = function_LCA_plot_standard(long_beach_3[[3]], long_beach_3[[11]])
          long_beach_3_co_standard = function_LCA_plot_standard(long_beach_3[[4]], long_beach_3[[11]])
          long_beach_3_nox_standard = function_LCA_plot_standard(long_beach_3[[5]], long_beach_3[[11]])
          long_beach_3_sox_standard = function_LCA_plot_standard(long_beach_3[[6]], long_beach_3[[11]])
          long_beach_3_pm25_standard = function_LCA_plot_standard(long_beach_3[[7]], long_beach_3[[11]])
          long_beach_3_voc_standard = function_LCA_plot_standard(long_beach_3[[8]], long_beach_3[[11]])
          
          long_beach_3_ghg_waterfall = function_LCA_plot_waterfall(long_beach_3[[3]], long_beach_3[[11]], 0, "Long Beach Generating Station - Unit 3", "GWP", batt_damages_raw, "Long Beach 3")
          long_beach_3_co_waterfall = function_LCA_plot_waterfall(long_beach_3[[4]], long_beach_3[[11]], 0, "Long Beach Generating Station - Unit 3", "GWP", batt_damages_raw, "Long Beach 3")
          long_beach_3_nox_waterfall = function_LCA_plot_waterfall(long_beach_3[[5]], long_beach_3[[11]], 0, "Long Beach Generating Station - Unit 3", "GWP", batt_damages_raw, "Long Beach 3")
          long_beach_3_sox_waterfall = function_LCA_plot_waterfall(long_beach_3[[6]], long_beach_3[[11]], 0, "Long Beach Generating Station - Unit 3", "GWP", batt_damages_raw, "Long Beach 3")
          long_beach_3_pm25_waterfall = function_LCA_plot_waterfall(long_beach_3[[7]], long_beach_3[[11]], 0, "Long Beach Generating Station - Unit 3", "GWP", batt_damages_raw, "Long Beach 3")
          long_beach_3_voc_waterfall = function_LCA_plot_waterfall(long_beach_3[[8]], long_beach_3[[11]], 0, "Long Beach Generating Station - Unit 3", "GWP", batt_damages_raw, "Long Beach 3")
          
          long_beach_3_ghg_percent = function_LCA_plot_percent(long_beach_3[[3]], long_beach_3[[11]])
          long_beach_3_co_percent = function_LCA_plot_percent(long_beach_3[[4]], long_beach_3[[11]])
          long_beach_3_nox_percent = function_LCA_plot_percent(long_beach_3[[5]], long_beach_3[[11]])
          long_beach_3_sox_percent = function_LCA_plot_percent(long_beach_3[[6]], long_beach_3[[11]])
          long_beach_3_pm25_percent = function_LCA_plot_percent(long_beach_3[[7]], long_beach_3[[11]])
          long_beach_3_voc_percent = function_LCA_plot_percent(long_beach_3[[8]], long_beach_3[[11]])
          
          long_beach_3_npv = function_npv_plot_waterfall(long_beach_3[[10]], long_beach_3[[12]],
                                                         batt_damages_raw, discount_series,
                                                         "Long Beach Generating Station - Unit 3",
                                                         "Long Beach 3",
                                                         plant_profits, elec_prices,
                                                         "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(long_beach_3_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Long Beach Generating Station Unit 3 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = long_beach_3_cost$YPos_Ind + 2* long_beach_3_cost$STDev + 14, label = paste(long_beach_3_cost$Mean, '+/-', 2* long_beach_3_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_3_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(long_beach_3_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Long Beach Generating Station Unit 3 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = long_beach_3_cost$`Duration Hr`[1], 
                     y = sum(long_beach_3_cost$YPos_Ind) + 2*sum(long_beach_3_cost$STDev^2)^0.5 + 15, label = paste(sum(long_beach_3_cost$Mean), '+/-', round(2*sum(long_beach_3_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_3_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Long Beach Generating Station Unit 3 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = long_beach_3_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                   xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                   ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = long_beach_3_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                               last(group.id),
                                                                               group.id+0.25), 
                                                                      xend=ifelse(group.id == last(group.id),
                                                                                  last(group.id),
                                                                                  group.id+0.75), 
                                                                      y=ifelse(end.id == 1,
                                                                               end.bar,
                                                                               # these will be removed once we set the y limits
                                                                               max(end.bar)*2*99999999999), 
                                                                      yend=ifelse(end.id == 1,
                                                                                  end.bar,
                                                                                  # these will be removed once we set the y limits
                                                                                  max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = long_beach_3_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(long_beach_3_ghg_waterfall[[10]]$Mean) - sum(long_beach_3_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(long_beach_3_ghg_waterfall[[10]]$Mean) + sum(long_beach_3_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = long_beach_3_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_3_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Long Beach Generating Station Unit 3 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = long_beach_3_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                        xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                        ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = long_beach_3_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                    last(group.id),
                                                                    group.id+0.25), 
                                                           xend=ifelse(group.id == last(group.id),
                                                                       last(group.id),
                                                                       group.id+0.75), 
                                                           y=ifelse(end.id == 1,
                                                                    end.bar,
                                                                    # these will be removed once we set the y limits
                                                                    max(end.bar)*2*99999999999), 
                                                           yend=ifelse(end.id == 1,
                                                                       end.bar,
                                                                       # these will be removed once we set the y limits
                                                                       max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = long_beach_3_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_2_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          #------------------------------------------------------------------------------
          # Long Beach 4 # 
          #------------------------------------------------------------------------------
          
          long_beach_4 = function_monte_carlo_plot("Average",
                                                   "National",
                                                   109, # size
                                                   4,
                                                   2020,
                                                   Lifespan,
                                                   chem_var, # "LFP Graphite SS",
                                                   2001,
                                                   24, # possibly change this to be a distribution of cycles
                                                   0.95,
                                                   fin_runs,
                                                   "Yes",
                                                   66,
                                                   "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                   "electricity.NG.kWh", # "electricity.NG.kWh"
                                                   "r410a.kg", # "r410a.kg", "r32.kg"
                                                   "Long Beach Generating Station - Unit 4") 
          
          
          long_beach_4_cost = long_beach_4[[1]]
          
          long_beach_4_ghg_standard = function_LCA_plot_standard(long_beach_4[[3]], long_beach_4[[11]])
          long_beach_4_co_standard = function_LCA_plot_standard(long_beach_4[[4]], long_beach_4[[11]])
          long_beach_4_nox_standard = function_LCA_plot_standard(long_beach_4[[5]], long_beach_4[[11]])
          long_beach_4_sox_standard = function_LCA_plot_standard(long_beach_4[[6]], long_beach_4[[11]])
          long_beach_4_pm25_standard = function_LCA_plot_standard(long_beach_4[[7]], long_beach_4[[11]])
          long_beach_4_voc_standard = function_LCA_plot_standard(long_beach_4[[8]], long_beach_4[[11]])
          
          long_beach_4_ghg_waterfall = function_LCA_plot_waterfall(long_beach_4[[3]], long_beach_4[[11]], 0, "Long Beach Generating Station - Unit 4", "GWP", batt_damages_raw, "Long Beach 4")
          long_beach_4_co_waterfall = function_LCA_plot_waterfall(long_beach_4[[4]], long_beach_4[[11]], 0, "Long Beach Generating Station - Unit 4", "GWP", batt_damages_raw, "Long Beach 4")
          long_beach_4_nox_waterfall = function_LCA_plot_waterfall(long_beach_4[[5]], long_beach_4[[11]], 0, "Long Beach Generating Station - Unit 4", "GWP", batt_damages_raw, "Long Beach 4")
          long_beach_4_sox_waterfall = function_LCA_plot_waterfall(long_beach_4[[6]], long_beach_4[[11]], 0, "Long Beach Generating Station - Unit 4", "GWP", batt_damages_raw, "Long Beach 4")
          long_beach_4_pm25_waterfall = function_LCA_plot_waterfall(long_beach_4[[7]], long_beach_4[[11]], 0, "Long Beach Generating Station - Unit 4", "GWP", batt_damages_raw, "Long Beach 4")
          long_beach_4_voc_waterfall = function_LCA_plot_waterfall(long_beach_4[[8]], long_beach_4[[11]], 0, "Long Beach Generating Station - Unit 4", "GWP", batt_damages_raw, "Long Beach 4")
          
          long_beach_4_ghg_percent = function_LCA_plot_percent(long_beach_4[[3]], long_beach_4[[11]])
          long_beach_4_co_percent = function_LCA_plot_percent(long_beach_4[[4]], long_beach_4[[11]])
          long_beach_4_nox_percent = function_LCA_plot_percent(long_beach_4[[5]], long_beach_4[[11]])
          long_beach_4_sox_percent = function_LCA_plot_percent(long_beach_4[[6]], long_beach_4[[11]])
          long_beach_4_pm25_percent = function_LCA_plot_percent(long_beach_4[[7]], long_beach_4[[11]])
          long_beach_4_voc_percent = function_LCA_plot_percent(long_beach_4[[8]], long_beach_4[[11]])
          
          long_beach_4_npv = function_npv_plot_waterfall(long_beach_4[[10]], long_beach_4[[12]],
                                                         batt_damages_raw, discount_series,
                                                         "Long Beach Generating Station - Unit 4",
                                                         "Long Beach 4", 
                                                         plant_profits, elec_prices,
                                                         "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(long_beach_4_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Long Beach Generating Station Unit 4 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = long_beach_4_cost$YPos_Ind + 2* long_beach_4_cost$STDev + 14, label = paste(long_beach_4_cost$Mean, '+/-', 2* long_beach_4_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_4_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(long_beach_4_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Long Beach Generating Station Unit 4 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = long_beach_4_cost$`Duration Hr`[1], 
                     y = sum(long_beach_4_cost$YPos_Ind) + 2*sum(long_beach_4_cost$STDev^2)^0.5 + 15, label = paste(sum(long_beach_4_cost$Mean), '+/-', round(2*sum(long_beach_4_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_4_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Long Beach Generating Station Unit 4 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = long_beach_4_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                   xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                   ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = long_beach_4_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                               last(group.id),
                                                                               group.id+0.25), 
                                                                      xend=ifelse(group.id == last(group.id),
                                                                                  last(group.id),
                                                                                  group.id+0.75), 
                                                                      y=ifelse(end.id == 1,
                                                                               end.bar,
                                                                               # these will be removed once we set the y limits
                                                                               max(end.bar)*2*99999999999), 
                                                                      yend=ifelse(end.id == 1,
                                                                                  end.bar,
                                                                                  # these will be removed once we set the y limits
                                                                                  max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = long_beach_4_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(long_beach_4_ghg_waterfall[[10]]$Mean) - sum(long_beach_4_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(long_beach_4_ghg_waterfall[[10]]$Mean) + sum(long_beach_4_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = long_beach_4_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_4_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Long Beach Generating Station Unit 4 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = long_beach_4_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                        xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                        ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = long_beach_4_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                    last(group.id),
                                                                    group.id+0.25), 
                                                           xend=ifelse(group.id == last(group.id),
                                                                       last(group.id),
                                                                       group.id+0.75), 
                                                           y=ifelse(end.id == 1,
                                                                    end.bar,
                                                                    # these will be removed once we set the y limits
                                                                    max(end.bar)*2*99999999999), 
                                                           yend=ifelse(end.id == 1,
                                                                       end.bar,
                                                                       # these will be removed once we set the y limits
                                                                       max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = long_beach_4_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/long_beach_4_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          #------------------------------------------------------------------------------
          # Harbor Gen 10 # 
          #------------------------------------------------------------------------------
          
          harbor_gen_10 = function_monte_carlo_plot("Average",
                                                    "National",
                                                    143, # size
                                                    4,
                                                    2020,
                                                    Lifespan,
                                                    chem_var, # "LFP Graphite SS",
                                                    2001,
                                                    18, # possibly change this to be a distribution of cycles
                                                    0.95,
                                                    fin_runs,
                                                    "Yes",
                                                    47,
                                                    "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                    "electricity.NG.kWh", # "electricity.NG.kWh"
                                                    "r410a.kg", # "r410a.kg", "r32.kg"
                                                    "Harbor Generating Station - Unit 10") 
          
          
          harbor_gen_10_cost = harbor_gen_10[[1]]
          
          harbor_gen_10_ghg_standard = function_LCA_plot_standard(harbor_gen_10[[3]], harbor_gen_10[[11]])
          harbor_gen_10_co_standard = function_LCA_plot_standard(harbor_gen_10[[4]], harbor_gen_10[[11]])
          harbor_gen_10_nox_standard = function_LCA_plot_standard(harbor_gen_10[[5]], harbor_gen_10[[11]])
          harbor_gen_10_sox_standard = function_LCA_plot_standard(harbor_gen_10[[6]], harbor_gen_10[[11]])
          harbor_gen_10_pm25_standard = function_LCA_plot_standard(harbor_gen_10[[7]], harbor_gen_10[[11]])
          harbor_gen_10_voc_standard = function_LCA_plot_standard(harbor_gen_10[[8]], harbor_gen_10[[11]])
          
          harbor_gen_10_ghg_waterfall = function_LCA_plot_waterfall(harbor_gen_10[[3]], harbor_gen_10[[11]], 0, "Harbor Generating Station - Unit 10", "GWP", batt_damages_raw, "Harbor 10")
          harbor_gen_10_co_waterfall = function_LCA_plot_waterfall(harbor_gen_10[[4]], harbor_gen_10[[11]], 0, "Harbor Generating Station - Unit 10", "GWP", batt_damages_raw, "Harbor 10")
          harbor_gen_10_nox_waterfall = function_LCA_plot_waterfall(harbor_gen_10[[5]], harbor_gen_10[[11]], 0, "Harbor Generating Station - Unit 10", "GWP", batt_damages_raw, "Harbor 10")
          harbor_gen_10_sox_waterfall = function_LCA_plot_waterfall(harbor_gen_10[[6]], harbor_gen_10[[11]], 0, "Harbor Generating Station - Unit 10", "GWP", batt_damages_raw, "Harbor 10")
          harbor_gen_10_pm25_waterfall = function_LCA_plot_waterfall(harbor_gen_10[[7]], harbor_gen_10[[11]], 0, "Harbor Generating Station - Unit 10", "GWP", batt_damages_raw, "Harbor 10")
          harbor_gen_10_voc_waterfall = function_LCA_plot_waterfall(harbor_gen_10[[8]], harbor_gen_10[[11]], 0, "Harbor Generating Station - Unit 10", "GWP", batt_damages_raw, "Harbor 10")
          
          harbor_gen_10_ghg_percent = function_LCA_plot_percent(harbor_gen_10[[3]], harbor_gen_10[[11]])
          harbor_gen_10_co_percent = function_LCA_plot_percent(harbor_gen_10[[4]], harbor_gen_10[[11]])
          harbor_gen_10_nox_percent = function_LCA_plot_percent(harbor_gen_10[[5]], harbor_gen_10[[11]])
          harbor_gen_10_sox_percent = function_LCA_plot_percent(harbor_gen_10[[6]], harbor_gen_10[[11]])
          harbor_gen_10_pm25_percent = function_LCA_plot_percent(harbor_gen_10[[7]], harbor_gen_10[[11]])
          harbor_gen_10_voc_percent = function_LCA_plot_percent(harbor_gen_10[[8]], harbor_gen_10[[11]])
          
          harbor_gen_10_npv = function_npv_plot_waterfall(harbor_gen_10[[10]], harbor_gen_10[[12]],
                                                          batt_damages_raw, discount_series,
                                                          "Harbor Generating Station - Unit 10",
                                                          "Harbor 10",
                                                          plant_profits, elec_prices,
                                                          "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(harbor_gen_10_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Harbor Generating Station Unit 10 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = harbor_gen_10_cost$YPos_Ind + 2* harbor_gen_10_cost$STDev + 14, label = paste(harbor_gen_10_cost$Mean, '+/-', 2* harbor_gen_10_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/harbor_10_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(harbor_gen_10_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Harbor Generating Station Unit 10 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = harbor_gen_10_cost$`Duration Hr`[1], 
                     y = sum(harbor_gen_10_cost$YPos_Ind) + 2*sum(harbor_gen_10_cost$STDev^2)^0.5 + 15, label = paste(sum(harbor_gen_10_cost$Mean), '+/-', round(2*sum(harbor_gen_10_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/harbor_10_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Harbor Generating Station Unit 10 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = harbor_gen_10_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                    xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                    ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = harbor_gen_10_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                                last(group.id),
                                                                                group.id+0.25), 
                                                                       xend=ifelse(group.id == last(group.id),
                                                                                   last(group.id),
                                                                                   group.id+0.75), 
                                                                       y=ifelse(end.id == 1,
                                                                                end.bar,
                                                                                # these will be removed once we set the y limits
                                                                                max(end.bar)*2*99999999999), 
                                                                       yend=ifelse(end.id == 1,
                                                                                   end.bar,
                                                                                   # these will be removed once we set the y limits
                                                                                   max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = harbor_gen_10_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(harbor_gen_10_ghg_waterfall[[10]]$Mean) - sum(harbor_gen_10_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(harbor_gen_10_ghg_waterfall[[10]]$Mean) + sum(harbor_gen_10_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = harbor_gen_10_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/harbor_10_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Harbor Generating Station Unit 10 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = harbor_gen_10_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                         xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                         ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = harbor_gen_10_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.25), 
                                                            xend=ifelse(group.id == last(group.id),
                                                                        last(group.id),
                                                                        group.id+0.75), 
                                                            y=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999), 
                                                            yend=ifelse(end.id == 1,
                                                                        end.bar,
                                                                        # these will be removed once we set the y limits
                                                                        max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = harbor_gen_10_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/harbor_10_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          #------------------------------------------------------------------------------
          # Harbor Gen 13 # 
          #------------------------------------------------------------------------------
          
          harbor_gen_13 = function_monte_carlo_plot("Average",
                                                    "National",
                                                    119, # size
                                                    4,
                                                    2020,
                                                    Lifespan,
                                                    chem_var, # "LFP Graphite SS",
                                                    2001,
                                                    20, # possibly change this to be a distribution of cycles
                                                    0.95,
                                                    fin_runs,
                                                    "Yes",
                                                    47,
                                                    "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                    "electricity.NG.kWh", # "electricity.NG.kWh"
                                                    "r410a.kg", # "r410a.kg", "r32.kg"
                                                    "Harbor Generating Station - Unit 13") 
          
          
          harbor_gen_13_cost = harbor_gen_13[[1]]
          
          harbor_gen_13_ghg_standard = function_LCA_plot_standard(harbor_gen_13[[3]], harbor_gen_13[[11]])
          harbor_gen_13_co_standard = function_LCA_plot_standard(harbor_gen_13[[4]], harbor_gen_13[[11]])
          harbor_gen_13_nox_standard = function_LCA_plot_standard(harbor_gen_13[[5]], harbor_gen_13[[11]])
          harbor_gen_13_sox_standard = function_LCA_plot_standard(harbor_gen_13[[6]], harbor_gen_13[[11]])
          harbor_gen_13_pm25_standard = function_LCA_plot_standard(harbor_gen_13[[7]], harbor_gen_13[[11]])
          harbor_gen_13_voc_standard = function_LCA_plot_standard(harbor_gen_13[[8]], harbor_gen_13[[11]])
          
          harbor_gen_13_ghg_waterfall = function_LCA_plot_waterfall(harbor_gen_13[[3]], harbor_gen_13[[11]], 0, "Harbor Generating Station - Unit 13", "GWP", batt_damages_raw, "Harbor 13")
          harbor_gen_13_co_waterfall = function_LCA_plot_waterfall(harbor_gen_13[[4]], harbor_gen_13[[11]], 0, "Harbor Generating Station - Unit 13", "GWP", batt_damages_raw, "Harbor 13")
          harbor_gen_13_nox_waterfall = function_LCA_plot_waterfall(harbor_gen_13[[5]], harbor_gen_13[[11]], 0, "Harbor Generating Station - Unit 13", "GWP", batt_damages_raw, "Harbor 13")
          harbor_gen_13_sox_waterfall = function_LCA_plot_waterfall(harbor_gen_13[[6]], harbor_gen_13[[11]], 0, "Harbor Generating Station - Unit 13", "GWP", batt_damages_raw, "Harbor 13")
          harbor_gen_13_pm25_waterfall = function_LCA_plot_waterfall(harbor_gen_13[[7]], harbor_gen_13[[11]], 0, "Harbor Generating Station - Unit 13", "GWP", batt_damages_raw, "Harbor 13")
          harbor_gen_13_voc_waterfall = function_LCA_plot_waterfall(harbor_gen_13[[8]], harbor_gen_13[[11]], 0, "Harbor Generating Station - Unit 13", "GWP", batt_damages_raw, "Harbor 13")
          
          harbor_gen_13_ghg_percent = function_LCA_plot_percent(harbor_gen_13[[3]], harbor_gen_13[[11]])
          harbor_gen_13_co_percent = function_LCA_plot_percent(harbor_gen_13[[4]], harbor_gen_13[[11]])
          harbor_gen_13_nox_percent = function_LCA_plot_percent(harbor_gen_13[[5]], harbor_gen_13[[11]])
          harbor_gen_13_sox_percent = function_LCA_plot_percent(harbor_gen_13[[6]], harbor_gen_13[[11]])
          harbor_gen_13_pm25_percent = function_LCA_plot_percent(harbor_gen_13[[7]], harbor_gen_13[[11]])
          harbor_gen_13_voc_percent = function_LCA_plot_percent(harbor_gen_13[[8]], harbor_gen_13[[11]])
          
          harbor_gen_13_npv = function_npv_plot_waterfall(harbor_gen_13[[10]], harbor_gen_13[[12]],
                                                          batt_damages_raw, discount_series,
                                                          "Harbor Generating Station - Unit 13",
                                                          "Harbor 13", 
                                                          plant_profits, elec_prices,
                                                          "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(harbor_gen_13_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Harbor Generating Station Unit 13 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = harbor_gen_13_cost$YPos_Ind + 2* harbor_gen_13_cost$STDev + 14, label = paste(harbor_gen_13_cost$Mean, '+/-', 2* harbor_gen_13_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/harbor_13_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(harbor_gen_13_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Harbor Generating Station Unit 13 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = harbor_gen_13_cost$`Duration Hr`[1], 
                     y = sum(harbor_gen_13_cost$YPos_Ind) + 2*sum(harbor_gen_13_cost$STDev^2)^0.5 + 15, label = paste(sum(harbor_gen_13_cost$Mean), '+/-', round(2*sum(harbor_gen_13_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/harbor_13_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Harbor Generating Station Unit 13 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = harbor_gen_13_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                    xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                    ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = harbor_gen_13_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                                last(group.id),
                                                                                group.id+0.25), 
                                                                       xend=ifelse(group.id == last(group.id),
                                                                                   last(group.id),
                                                                                   group.id+0.75), 
                                                                       y=ifelse(end.id == 1,
                                                                                end.bar,
                                                                                # these will be removed once we set the y limits
                                                                                max(end.bar)*2*99999999999), 
                                                                       yend=ifelse(end.id == 1,
                                                                                   end.bar,
                                                                                   # these will be removed once we set the y limits
                                                                                   max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = harbor_gen_13_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(harbor_gen_13_ghg_waterfall[[10]]$Mean) - sum(harbor_gen_13_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(harbor_gen_13_ghg_waterfall[[10]]$Mean) + sum(harbor_gen_13_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = harbor_gen_13_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/harbor_13_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Harbor Generating Station Unit 13 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = harbor_gen_13_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                         xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                         ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = harbor_gen_13_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.25), 
                                                            xend=ifelse(group.id == last(group.id),
                                                                        last(group.id),
                                                                        group.id+0.75), 
                                                            y=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999), 
                                                            yend=ifelse(end.id == 1,
                                                                        end.bar,
                                                                        # these will be removed once we set the y limits
                                                                        max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = harbor_gen_13_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/harbor_13_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # Harbor Gen 14 # 
          #------------------------------------------------------------------------------
          
          harbor_gen_14 = function_monte_carlo_plot("Average",
                                                    "National",
                                                    119, # size
                                                    4,
                                                    2020,
                                                    Lifespan,
                                                    chem_var, # "LFP Graphite SS",
                                                    2001,
                                                    20, # possibly change this to be a distribution of cycles
                                                    0.95,
                                                    fin_runs,
                                                    "Yes",
                                                    47,
                                                    "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                    "electricity.NG.kWh", # "electricity.NG.kWh"
                                                    "r410a.kg", # "r410a.kg", "r32.kg"
                                                    "Harbor Generating Station - Unit 14") 
          
          
          harbor_gen_14_cost = harbor_gen_14[[1]]
          
          harbor_gen_14_ghg_standard = function_LCA_plot_standard(harbor_gen_14[[3]], harbor_gen_14[[11]])
          harbor_gen_14_co_standard = function_LCA_plot_standard(harbor_gen_14[[4]], harbor_gen_14[[11]])
          harbor_gen_14_nox_standard = function_LCA_plot_standard(harbor_gen_14[[5]], harbor_gen_14[[11]])
          harbor_gen_14_sox_standard = function_LCA_plot_standard(harbor_gen_14[[6]], harbor_gen_14[[11]])
          harbor_gen_14_pm25_standard = function_LCA_plot_standard(harbor_gen_14[[7]], harbor_gen_14[[11]])
          harbor_gen_14_voc_standard = function_LCA_plot_standard(harbor_gen_14[[8]], harbor_gen_14[[11]])
          
          harbor_gen_14_ghg_waterfall = function_LCA_plot_waterfall(harbor_gen_14[[3]], harbor_gen_14[[11]], 0, "Harbor Generating Station - Unit 14", "GWP", batt_damages_raw, "Harbor 14")
          harbor_gen_14_co_waterfall = function_LCA_plot_waterfall(harbor_gen_14[[4]], harbor_gen_14[[11]], 0, "Harbor Generating Station - Unit 14", "GWP", batt_damages_raw, "Harbor 14")
          harbor_gen_14_nox_waterfall = function_LCA_plot_waterfall(harbor_gen_14[[5]], harbor_gen_14[[11]], 0, "Harbor Generating Station - Unit 14", "GWP", batt_damages_raw, "Harbor 14")
          harbor_gen_14_sox_waterfall = function_LCA_plot_waterfall(harbor_gen_14[[6]], harbor_gen_14[[11]], 0, "Harbor Generating Station - Unit 14", "GWP", batt_damages_raw, "Harbor 14")
          harbor_gen_14_pm25_waterfall = function_LCA_plot_waterfall(harbor_gen_14[[7]], harbor_gen_14[[11]], 0, "Harbor Generating Station - Unit 14", "GWP", batt_damages_raw, "Harbor 14")
          harbor_gen_14_voc_waterfall = function_LCA_plot_waterfall(harbor_gen_14[[8]], harbor_gen_14[[11]], 0, "Harbor Generating Station - Unit 14", "GWP", batt_damages_raw, "Harbor 14")
          
          harbor_gen_14_ghg_percent = function_LCA_plot_percent(harbor_gen_14[[3]], harbor_gen_14[[11]])
          harbor_gen_14_co_percent = function_LCA_plot_percent(harbor_gen_14[[4]], harbor_gen_14[[11]])
          harbor_gen_14_nox_percent = function_LCA_plot_percent(harbor_gen_14[[5]], harbor_gen_14[[11]])
          harbor_gen_14_sox_percent = function_LCA_plot_percent(harbor_gen_14[[6]], harbor_gen_14[[11]])
          harbor_gen_14_pm25_percent = function_LCA_plot_percent(harbor_gen_14[[7]], harbor_gen_14[[11]])
          harbor_gen_14_voc_percent = function_LCA_plot_percent(harbor_gen_14[[8]], harbor_gen_14[[11]])
          
          harbor_gen_14_npv = function_npv_plot_waterfall(harbor_gen_14[[10]], harbor_gen_14[[12]],
                                                          batt_damages_raw, discount_series,
                                                          "Harbor Generating Station - Unit 14",
                                                          "Harbor 14",
                                                          plant_profits, elec_prices,
                                                          "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(harbor_gen_14_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Harbor Generating Station Unit 14 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = harbor_gen_14_cost$YPos_Ind + 2* harbor_gen_14_cost$STDev + 14, label = paste(harbor_gen_14_cost$Mean, '+/-', 2* harbor_gen_14_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/harbor_14_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(harbor_gen_14_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Harbor Generating Station Unit 14 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = harbor_gen_14_cost$`Duration Hr`[1], 
                     y = sum(harbor_gen_14_cost$YPos_Ind) + 2*sum(harbor_gen_14_cost$STDev^2)^0.5 + 15, label = paste(sum(harbor_gen_14_cost$Mean), '+/-', round(2*sum(harbor_gen_14_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/harbor_14_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Harbor Generating Station Unit 14 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = harbor_gen_14_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                    xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                    ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = harbor_gen_14_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                                last(group.id),
                                                                                group.id+0.25), 
                                                                       xend=ifelse(group.id == last(group.id),
                                                                                   last(group.id),
                                                                                   group.id+0.75), 
                                                                       y=ifelse(end.id == 1,
                                                                                end.bar,
                                                                                # these will be removed once we set the y limits
                                                                                max(end.bar)*2*99999999999), 
                                                                       yend=ifelse(end.id == 1,
                                                                                   end.bar,
                                                                                   # these will be removed once we set the y limits
                                                                                   max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = harbor_gen_14_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(harbor_gen_14_ghg_waterfall[[10]]$Mean) - sum(harbor_gen_14_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(harbor_gen_14_ghg_waterfall[[10]]$Mean) + sum(harbor_gen_14_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = harbor_gen_14_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/harbor_14_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Harbor Generating Station Unit 14 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = harbor_gen_14_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                         xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                         ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = harbor_gen_14_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.25), 
                                                            xend=ifelse(group.id == last(group.id),
                                                                        last(group.id),
                                                                        group.id+0.75), 
                                                            y=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999), 
                                                            yend=ifelse(end.id == 1,
                                                                        end.bar,
                                                                        # these will be removed once we set the y limits
                                                                        max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = harbor_gen_14_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/harbor_14_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # Glenarm 4 # 
          #------------------------------------------------------------------------------
          
          glenarm_4 = function_monte_carlo_plot("Average",
                                                "National",
                                                58, # size
                                                4,
                                                2020,
                                                Lifespan,
                                                chem_var, # "LFP Graphite SS",
                                                2001,
                                                67, # possibly change this to be a distribution of cycles
                                                0.95,
                                                fin_runs,
                                                "Yes",
                                                47,
                                                "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                "electricity.NG.kWh", # "electricity.NG.kWh"
                                                "r410a.kg", # "r410a.kg", "r32.kg"
                                                "Glenarm - Gas Turbine 4") 
          
          
          glenarm_4_cost = glenarm_4[[1]]
          
          glenarm_4_ghg_standard = function_LCA_plot_standard(glenarm_4[[3]], glenarm_4[[11]])
          glenarm_4_co_standard = function_LCA_plot_standard(glenarm_4[[4]], glenarm_4[[11]])
          glenarm_4_nox_standard = function_LCA_plot_standard(glenarm_4[[5]], glenarm_4[[11]])
          glenarm_4_sox_standard = function_LCA_plot_standard(glenarm_4[[6]], glenarm_4[[11]])
          glenarm_4_pm25_standard = function_LCA_plot_standard(glenarm_4[[7]], glenarm_4[[11]])
          glenarm_4_voc_standard = function_LCA_plot_standard(glenarm_4[[8]], glenarm_4[[11]])
          
          glenarm_4_ghg_waterfall = function_LCA_plot_waterfall(glenarm_4[[3]], glenarm_4[[11]], 0, "Glenarm - Gas Turbine 4", "GWP", batt_damages_raw, "Glenarm 4")
          glenarm_4_co_waterfall = function_LCA_plot_waterfall(glenarm_4[[4]], glenarm_4[[11]], 0, "Glenarm - Gas Turbine 4", "GWP", batt_damages_raw, "Glenarm 4")
          glenarm_4_nox_waterfall = function_LCA_plot_waterfall(glenarm_4[[5]], glenarm_4[[11]], 0, "Glenarm - Gas Turbine 4", "GWP", batt_damages_raw, "Glenarm 4")
          glenarm_4_sox_waterfall = function_LCA_plot_waterfall(glenarm_4[[6]], glenarm_4[[11]], 0, "Glenarm - Gas Turbine 4", "GWP", batt_damages_raw, "Glenarm 4")
          glenarm_4_pm25_waterfall = function_LCA_plot_waterfall(glenarm_4[[7]], glenarm_4[[11]], 0, "Glenarm - Gas Turbine 4", "GWP", batt_damages_raw, "Glenarm 4")
          glenarm_4_voc_waterfall = function_LCA_plot_waterfall(glenarm_4[[8]], glenarm_4[[11]], 0, "Glenarm - Gas Turbine 4", "GWP", batt_damages_raw, "Glenarm 4")
          
          glenarm_4_ghg_percent = function_LCA_plot_percent(glenarm_4[[3]], glenarm_4[[11]])
          glenarm_4_co_percent = function_LCA_plot_percent(glenarm_4[[4]], glenarm_4[[11]])
          glenarm_4_nox_percent = function_LCA_plot_percent(glenarm_4[[5]], glenarm_4[[11]])
          glenarm_4_sox_percent = function_LCA_plot_percent(glenarm_4[[6]], glenarm_4[[11]])
          glenarm_4_pm25_percent = function_LCA_plot_percent(glenarm_4[[7]], glenarm_4[[11]])
          glenarm_4_voc_percent = function_LCA_plot_percent(glenarm_4[[8]], glenarm_4[[11]])
          
          glenarm_4_npv = function_npv_plot_waterfall(glenarm_4[[10]], glenarm_4[[12]],
                                                      batt_damages_raw, discount_series,
                                                      "Glenarm - Gas Turbine 4",
                                                      "Glenarm 4",
                                                      plant_profits, elec_prices,
                                                      "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(glenarm_4_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Glenarm Gas Turbine 4 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = glenarm_4_cost$YPos_Ind + 2* glenarm_4_cost$STDev + 14, label = paste(glenarm_4_cost$Mean, '+/-', 2* glenarm_4_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/glenarm_4_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(glenarm_4_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Glenarm Gas Turbine 4 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = glenarm_4_cost$`Duration Hr`[1], 
                     y = sum(glenarm_4_cost$YPos_Ind) + 2*sum(glenarm_4_cost$STDev^2)^0.5 + 15, label = paste(sum(glenarm_4_cost$Mean), '+/-', round(2*sum(glenarm_4_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/glenarm_4_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Glenarm Gas Turbine 4 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = glenarm_4_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = glenarm_4_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                            last(group.id),
                                                                            group.id+0.25), 
                                                                   xend=ifelse(group.id == last(group.id),
                                                                               last(group.id),
                                                                               group.id+0.75), 
                                                                   y=ifelse(end.id == 1,
                                                                            end.bar,
                                                                            # these will be removed once we set the y limits
                                                                            max(end.bar)*2*99999999999), 
                                                                   yend=ifelse(end.id == 1,
                                                                               end.bar,
                                                                               # these will be removed once we set the y limits
                                                                               max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = glenarm_4_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(glenarm_4_ghg_waterfall[[10]]$Mean) - sum(glenarm_4_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(glenarm_4_ghg_waterfall[[10]]$Mean) + sum(glenarm_4_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = glenarm_4_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/glenarm_4_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Glenarm Gas Turbine 4 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = glenarm_4_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                     xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                     ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = glenarm_4_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                 last(group.id),
                                                                 group.id+0.25), 
                                                        xend=ifelse(group.id == last(group.id),
                                                                    last(group.id),
                                                                    group.id+0.75), 
                                                        y=ifelse(end.id == 1,
                                                                 end.bar,
                                                                 # these will be removed once we set the y limits
                                                                 max(end.bar)*2*99999999999), 
                                                        yend=ifelse(end.id == 1,
                                                                    end.bar,
                                                                    # these will be removed once we set the y limits
                                                                    max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = glenarm_4_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/glenarm_4_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          #------------------------------------------------------------------------------
          # calpeak border 1 # 
          #------------------------------------------------------------------------------
          
          calpeak_border_1 = function_monte_carlo_plot("Average",
                                                       "National",
                                                       65, # size
                                                       4,
                                                       2020,
                                                       Lifespan,
                                                       chem_var, # "LFP Graphite SS",
                                                       2001,
                                                       56, # possibly change this to be a distribution of cycles
                                                       0.95,
                                                       fin_runs,
                                                       "Yes",
                                                       51,
                                                       "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                       "electricity.NG.kWh", # "electricity.NG.kWh"
                                                       "r410a.kg", # "r410a.kg", "r32.kg"
                                                       "CalPeak Power Border - Gas Turbine 1") 
          
          
          calpeak_border_1_cost = calpeak_border_1[[1]]
          
          calpeak_border_1_ghg_standard = function_LCA_plot_standard(calpeak_border_1[[3]], calpeak_border_1[[11]])
          calpeak_border_1_co_standard = function_LCA_plot_standard(calpeak_border_1[[4]], calpeak_border_1[[11]])
          calpeak_border_1_nox_standard = function_LCA_plot_standard(calpeak_border_1[[5]], calpeak_border_1[[11]])
          calpeak_border_1_sox_standard = function_LCA_plot_standard(calpeak_border_1[[6]], calpeak_border_1[[11]])
          calpeak_border_1_pm25_standard = function_LCA_plot_standard(calpeak_border_1[[7]], calpeak_border_1[[11]])
          calpeak_border_1_voc_standard = function_LCA_plot_standard(calpeak_border_1[[8]], calpeak_border_1[[11]])
          
          calpeak_border_1_ghg_waterfall = function_LCA_plot_waterfall(calpeak_border_1[[3]], calpeak_border_1[[11]], 0, "CalPeak Power Border - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Border 1")
          calpeak_border_1_co_waterfall = function_LCA_plot_waterfall(calpeak_border_1[[4]], calpeak_border_1[[11]], 0, "CalPeak Power Border - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Border 1")
          calpeak_border_1_nox_waterfall = function_LCA_plot_waterfall(calpeak_border_1[[5]], calpeak_border_1[[11]], 0, "CalPeak Power Border - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Border 1")
          calpeak_border_1_sox_waterfall = function_LCA_plot_waterfall(calpeak_border_1[[6]], calpeak_border_1[[11]], 0, "CalPeak Power Border - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Border 1")
          calpeak_border_1_pm25_waterfall = function_LCA_plot_waterfall(calpeak_border_1[[7]], calpeak_border_1[[11]], 0, "CalPeak Power Border - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Border 1")
          calpeak_border_1_voc_waterfall = function_LCA_plot_waterfall(calpeak_border_1[[8]], calpeak_border_1[[11]], 0, "CalPeak Power Border - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Border 1")
          
          calpeak_border_1_ghg_percent = function_LCA_plot_percent(calpeak_border_1[[3]], calpeak_border_1[[11]])
          calpeak_border_1_co_percent = function_LCA_plot_percent(calpeak_border_1[[4]], calpeak_border_1[[11]])
          calpeak_border_1_nox_percent = function_LCA_plot_percent(calpeak_border_1[[5]], calpeak_border_1[[11]])
          calpeak_border_1_sox_percent = function_LCA_plot_percent(calpeak_border_1[[6]], calpeak_border_1[[11]])
          calpeak_border_1_pm25_percent = function_LCA_plot_percent(calpeak_border_1[[7]], calpeak_border_1[[11]])
          calpeak_border_1_voc_percent = function_LCA_plot_percent(calpeak_border_1[[8]], calpeak_border_1[[11]])
          
          calpeak_border_1_npv = function_npv_plot_waterfall(calpeak_border_1[[10]], calpeak_border_1[[12]],
                                                             batt_damages_raw, discount_series,
                                                             "CalPeak Power Border - Gas Turbine 1",
                                                             "CalPeak Border 1",
                                                             plant_profits, elec_prices,
                                                             "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(calpeak_border_1_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("CalPeak Power Border Gas Turbine 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = calpeak_border_1_cost$YPos_Ind + 2* calpeak_border_1_cost$STDev + 14, label = paste(calpeak_border_1_cost$Mean, '+/-', 2* calpeak_border_1_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/calpeak_border_1_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(calpeak_border_1_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("CalPeak Power Border Gas Turbine 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = calpeak_border_1_cost$`Duration Hr`[1], 
                     y = sum(calpeak_border_1_cost$YPos_Ind) + 2*sum(calpeak_border_1_cost$STDev^2)^0.5 + 15, label = paste(sum(calpeak_border_1_cost$Mean), '+/-', round(2*sum(calpeak_border_1_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/calpeak_border_1_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("CalPeak Power Border Gas Turbine 1 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = calpeak_border_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                       xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                       ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = calpeak_border_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                                   last(group.id),
                                                                                   group.id+0.25), 
                                                                          xend=ifelse(group.id == last(group.id),
                                                                                      last(group.id),
                                                                                      group.id+0.75), 
                                                                          y=ifelse(end.id == 1,
                                                                                   end.bar,
                                                                                   # these will be removed once we set the y limits
                                                                                   max(end.bar)*2*99999999999), 
                                                                          yend=ifelse(end.id == 1,
                                                                                      end.bar,
                                                                                      # these will be removed once we set the y limits
                                                                                      max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = calpeak_border_1_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(calpeak_border_1_ghg_waterfall[[10]]$Mean) - sum(calpeak_border_1_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(calpeak_border_1_ghg_waterfall[[10]]$Mean) + sum(calpeak_border_1_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = calpeak_border_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/calpeak_border_1_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("CalPeak Power Border Gas Turbine 1 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = calpeak_border_1_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                            xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                            ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = calpeak_border_1_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                        last(group.id),
                                                                        group.id+0.25), 
                                                               xend=ifelse(group.id == last(group.id),
                                                                           last(group.id),
                                                                           group.id+0.75), 
                                                               y=ifelse(end.id == 1,
                                                                        end.bar,
                                                                        # these will be removed once we set the y limits
                                                                        max(end.bar)*2*99999999999), 
                                                               yend=ifelse(end.id == 1,
                                                                           end.bar,
                                                                           # these will be removed once we set the y limits
                                                                           max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = calpeak_border_1_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/calpeak_border_1_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # cuyamaca peak 1 # 
          #------------------------------------------------------------------------------
          
          cuyamaca_peak_1 = function_monte_carlo_plot("Average",
                                                      "National",
                                                      113, # size
                                                      4,
                                                      2020,
                                                      Lifespan,
                                                      chem_var, # "LFP Graphite SS",
                                                      2001,
                                                      29, # possibly change this to be a distribution of cycles
                                                      0.95,
                                                      fin_runs,
                                                      "Yes",
                                                      45,
                                                      "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                      "electricity.NG.kWh", # "electricity.NG.kWh"
                                                      "r410a.kg", # "r410a.kg", "r32.kg"
                                                      "Cuyamaca Peak Energy - Gas Turbine 1") 
          
          
          cuyamaca_peak_1_cost = cuyamaca_peak_1[[1]]
          
          cuyamaca_peak_1_ghg_standard = function_LCA_plot_standard(cuyamaca_peak_1[[3]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_co_standard = function_LCA_plot_standard(cuyamaca_peak_1[[4]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_nox_standard = function_LCA_plot_standard(cuyamaca_peak_1[[5]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_sox_standard = function_LCA_plot_standard(cuyamaca_peak_1[[6]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_pm25_standard = function_LCA_plot_standard(cuyamaca_peak_1[[7]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_voc_standard = function_LCA_plot_standard(cuyamaca_peak_1[[8]], cuyamaca_peak_1[[11]])
          
          cuyamaca_peak_1_ghg_waterfall = function_LCA_plot_waterfall(cuyamaca_peak_1[[3]], cuyamaca_peak_1[[11]], 0, "Cuyamaca Peak Energy - Gas Turbine 1", "GWP", batt_damages_raw, "Cuyamaca 1")
          cuyamaca_peak_1_co_waterfall = function_LCA_plot_waterfall(cuyamaca_peak_1[[4]], cuyamaca_peak_1[[11]], 0, "Cuyamaca Peak Energy - Gas Turbine 1", "GWP", batt_damages_raw, "Cuyamaca 1")
          cuyamaca_peak_1_nox_waterfall = function_LCA_plot_waterfall(cuyamaca_peak_1[[5]], cuyamaca_peak_1[[11]], 0, "Cuyamaca Peak Energy - Gas Turbine 1", "GWP", batt_damages_raw, "Cuyamaca 1")
          cuyamaca_peak_1_sox_waterfall = function_LCA_plot_waterfall(cuyamaca_peak_1[[6]], cuyamaca_peak_1[[11]], 0, "Cuyamaca Peak Energy - Gas Turbine 1", "GWP", batt_damages_raw, "Cuyamaca 1")
          cuyamaca_peak_1_pm25_waterfall = function_LCA_plot_waterfall(cuyamaca_peak_1[[7]], cuyamaca_peak_1[[11]], 0, "Cuyamaca Peak Energy - Gas Turbine 1", "GWP", batt_damages_raw, "Cuyamaca 1")
          cuyamaca_peak_1_voc_waterfall = function_LCA_plot_waterfall(cuyamaca_peak_1[[8]], cuyamaca_peak_1[[11]], 0, "Cuyamaca Peak Energy - Gas Turbine 1", "GWP", batt_damages_raw, "Cuyamaca 1")
          
          cuyamaca_peak_1_ghg_percent = function_LCA_plot_percent(cuyamaca_peak_1[[3]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_co_percent = function_LCA_plot_percent(cuyamaca_peak_1[[4]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_nox_percent = function_LCA_plot_percent(cuyamaca_peak_1[[5]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_sox_percent = function_LCA_plot_percent(cuyamaca_peak_1[[6]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_pm25_percent = function_LCA_plot_percent(cuyamaca_peak_1[[7]], cuyamaca_peak_1[[11]])
          cuyamaca_peak_1_voc_percent = function_LCA_plot_percent(cuyamaca_peak_1[[8]], cuyamaca_peak_1[[11]])
          
          cuyamaca_peak_1_npv = function_npv_plot_waterfall(cuyamaca_peak_1[[10]], cuyamaca_peak_1[[12]],
                                                            batt_damages_raw, discount_series,
                                                            "Cuyamaca Peak Energy - Gas Turbine 1",
                                                            "Cuyamaca 1",
                                                            plant_profits, elec_prices,
                                                            "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(cuyamaca_peak_1_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Cuyamaca Peak Energy Gas Turbine 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = cuyamaca_peak_1_cost$YPos_Ind + 2* cuyamaca_peak_1_cost$STDev + 14, label = paste(cuyamaca_peak_1_cost$Mean, '+/-', 2* cuyamaca_peak_1_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/cuyamaca_peak_1_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(cuyamaca_peak_1_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Cuyamaca Peak Energy Gas Turbine 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = cuyamaca_peak_1_cost$`Duration Hr`[1], 
                     y = sum(cuyamaca_peak_1_cost$YPos_Ind) + 2*sum(cuyamaca_peak_1_cost$STDev^2)^0.5 + 15, label = paste(sum(cuyamaca_peak_1_cost$Mean), '+/-', round(2*sum(cuyamaca_peak_1_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/cuyamaca_peak_1_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Cuyamaca Peak Energy Gas Turbine 1 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = cuyamaca_peak_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                      xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                      ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = cuyamaca_peak_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                                  last(group.id),
                                                                                  group.id+0.25), 
                                                                         xend=ifelse(group.id == last(group.id),
                                                                                     last(group.id),
                                                                                     group.id+0.75), 
                                                                         y=ifelse(end.id == 1,
                                                                                  end.bar,
                                                                                  # these will be removed once we set the y limits
                                                                                  max(end.bar)*2*99999999999), 
                                                                         yend=ifelse(end.id == 1,
                                                                                     end.bar,
                                                                                     # these will be removed once we set the y limits
                                                                                     max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = cuyamaca_peak_1_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(cuyamaca_peak_1_ghg_waterfall[[10]]$Mean) - sum(cuyamaca_peak_1_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(cuyamaca_peak_1_ghg_waterfall[[10]]$Mean) + sum(cuyamaca_peak_1_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = cuyamaca_peak_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/cuyamaca_peak_1_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Cuyamaca Peak Energy Gas Turbine 1 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = cuyamaca_peak_1_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                           xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                           ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = cuyamaca_peak_1_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                       last(group.id),
                                                                       group.id+0.25), 
                                                              xend=ifelse(group.id == last(group.id),
                                                                          last(group.id),
                                                                          group.id+0.75), 
                                                              y=ifelse(end.id == 1,
                                                                       end.bar,
                                                                       # these will be removed once we set the y limits
                                                                       max(end.bar)*2*99999999999), 
                                                              yend=ifelse(end.id == 1,
                                                                          end.bar,
                                                                          # these will be removed once we set the y limits
                                                                          max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = cuyamaca_peak_1_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/cuyamaca_peak_1_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # calpeak enterprise 1 # 
          #------------------------------------------------------------------------------
          
          calpeak_enterprise_1 = function_monte_carlo_plot("Average",
                                                           "National",
                                                           65, # size
                                                           4,
                                                           2020,
                                                           Lifespan,
                                                           chem_var, # "LFP Graphite SS",
                                                           2001,
                                                           52, # possibly change this to be a distribution of cycles
                                                           0.95,
                                                           fin_runs,
                                                           "Yes",
                                                           51,
                                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                                           "r410a.kg", # "r410a.kg", "r32.kg"
                                                           "CalPeak Power Enterprise - Gas Turbine 1") 
          
          
          calpeak_enterprise_1_cost = calpeak_enterprise_1[[1]]
          
          calpeak_enterprise_1_ghg_standard = function_LCA_plot_standard(calpeak_enterprise_1[[3]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_co_standard = function_LCA_plot_standard(calpeak_enterprise_1[[4]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_nox_standard = function_LCA_plot_standard(calpeak_enterprise_1[[5]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_sox_standard = function_LCA_plot_standard(calpeak_enterprise_1[[6]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_pm25_standard = function_LCA_plot_standard(calpeak_enterprise_1[[7]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_voc_standard = function_LCA_plot_standard(calpeak_enterprise_1[[8]], calpeak_enterprise_1[[11]])
          
          calpeak_enterprise_1_ghg_waterfall = function_LCA_plot_waterfall(calpeak_enterprise_1[[3]], calpeak_enterprise_1[[11]], 0, "CalPeak Power Enterprise - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Enterprise 1")
          calpeak_enterprise_1_co_waterfall = function_LCA_plot_waterfall(calpeak_enterprise_1[[4]], calpeak_enterprise_1[[11]], 0, "CalPeak Power Enterprise - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Enterprise 1")
          calpeak_enterprise_1_nox_waterfall = function_LCA_plot_waterfall(calpeak_enterprise_1[[5]], calpeak_enterprise_1[[11]], 0, "CalPeak Power Enterprise - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Enterprise 1")
          calpeak_enterprise_1_sox_waterfall = function_LCA_plot_waterfall(calpeak_enterprise_1[[6]], calpeak_enterprise_1[[11]], 0, "CalPeak Power Enterprise - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Enterprise 1")
          calpeak_enterprise_1_pm25_waterfall = function_LCA_plot_waterfall(calpeak_enterprise_1[[7]], calpeak_enterprise_1[[11]], 0, "CalPeak Power Enterprise - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Enterprise 1")
          calpeak_enterprise_1_voc_waterfall = function_LCA_plot_waterfall(calpeak_enterprise_1[[8]], calpeak_enterprise_1[[11]], 0, "CalPeak Power Enterprise - Gas Turbine 1", "GWP", batt_damages_raw, "CalPeak Enterprise 1")
          
          calpeak_enterprise_1_ghg_percent = function_LCA_plot_percent(calpeak_enterprise_1[[3]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_co_percent = function_LCA_plot_percent(calpeak_enterprise_1[[4]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_nox_percent = function_LCA_plot_percent(calpeak_enterprise_1[[5]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_sox_percent = function_LCA_plot_percent(calpeak_enterprise_1[[6]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_pm25_percent = function_LCA_plot_percent(calpeak_enterprise_1[[7]], calpeak_enterprise_1[[11]])
          calpeak_enterprise_1_voc_percent = function_LCA_plot_percent(calpeak_enterprise_1[[8]], calpeak_enterprise_1[[11]])
          
          calpeak_enterprise_1_npv = function_npv_plot_waterfall(calpeak_enterprise_1[[10]], calpeak_enterprise_1[[12]],
                                                                 batt_damages_raw, discount_series,
                                                                 "CalPeak Power Enterprise - Gas Turbine 1",
                                                                 "CalPeak Enterprise 1",
                                                                 plant_profits, elec_prices,
                                                                 "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(calpeak_enterprise_1_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("CalPeak Power Enterprise Gas Turbine 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = calpeak_enterprise_1_cost$YPos_Ind + 2* calpeak_enterprise_1_cost$STDev + 14, label = paste(calpeak_enterprise_1_cost$Mean, '+/-', 2* calpeak_enterprise_1_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/calpeak_enterprise_1_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(calpeak_enterprise_1_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("CalPeak Power Enterprise Gas Turbine 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = calpeak_enterprise_1_cost$`Duration Hr`[1], 
                     y = sum(calpeak_enterprise_1_cost$YPos_Ind) + 2*sum(calpeak_enterprise_1_cost$STDev^2)^0.5 + 15, label = paste(sum(calpeak_enterprise_1_cost$Mean), '+/-', round(2*sum(calpeak_enterprise_1_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/calpeak_enterprise_1_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("CalPeak Power Enterprise Gas Turbine 1 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = calpeak_enterprise_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                           xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                           ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = calpeak_enterprise_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                                       last(group.id),
                                                                                       group.id+0.25), 
                                                                              xend=ifelse(group.id == last(group.id),
                                                                                          last(group.id),
                                                                                          group.id+0.75), 
                                                                              y=ifelse(end.id == 1,
                                                                                       end.bar,
                                                                                       # these will be removed once we set the y limits
                                                                                       max(end.bar)*2*99999999999), 
                                                                              yend=ifelse(end.id == 1,
                                                                                          end.bar,
                                                                                          # these will be removed once we set the y limits
                                                                                          max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = calpeak_enterprise_1_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(calpeak_enterprise_1_ghg_waterfall[[10]]$Mean) - sum(calpeak_enterprise_1_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(calpeak_enterprise_1_ghg_waterfall[[10]]$Mean) + sum(calpeak_enterprise_1_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = calpeak_enterprise_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/calpeak_enterprise_1_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("CalPeak Power Enterprise Gas Turbine 1 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = calpeak_enterprise_1_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                                xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = calpeak_enterprise_1_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                            last(group.id),
                                                                            group.id+0.25), 
                                                                   xend=ifelse(group.id == last(group.id),
                                                                               last(group.id),
                                                                               group.id+0.75), 
                                                                   y=ifelse(end.id == 1,
                                                                            end.bar,
                                                                            # these will be removed once we set the y limits
                                                                            max(end.bar)*2*99999999999), 
                                                                   yend=ifelse(end.id == 1,
                                                                               end.bar,
                                                                               # these will be removed once we set the y limits
                                                                               max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = calpeak_enterprise_1_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/calpeak_enterprise_1_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # Chula Vista 1A # 
          #------------------------------------------------------------------------------
          
          chula_vista_1a = function_monte_carlo_plot("Average",
                                                     "National",
                                                     39, # size
                                                     4,
                                                     2020,
                                                     Lifespan,
                                                     chem_var, # "LFP Graphite SS",
                                                     2001,
                                                     21, # possibly change this to be a distribution of cycles
                                                     0.95,
                                                     fin_runs,
                                                     "Yes",
                                                     18, # max load
                                                     "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                     "electricity.NG.kWh", # "electricity.NG.kWh"
                                                     "r410a.kg", # "r410a.kg", "r32.kg"
                                                     "Chula Vista Energy Center - Unit 1A") 
          
          
          chula_vista_1a_cost = chula_vista_1a[[1]]
          
          chula_vista_1a_ghg_standard = function_LCA_plot_standard(chula_vista_1a[[3]], chula_vista_1a[[11]])
          chula_vista_1a_co_standard = function_LCA_plot_standard(chula_vista_1a[[4]], chula_vista_1a[[11]])
          chula_vista_1a_nox_standard = function_LCA_plot_standard(chula_vista_1a[[5]], chula_vista_1a[[11]])
          chula_vista_1a_sox_standard = function_LCA_plot_standard(chula_vista_1a[[6]], chula_vista_1a[[11]])
          chula_vista_1a_pm25_standard = function_LCA_plot_standard(chula_vista_1a[[7]], chula_vista_1a[[11]])
          chula_vista_1a_voc_standard = function_LCA_plot_standard(chula_vista_1a[[8]], chula_vista_1a[[11]])
          
          chula_vista_1a_ghg_waterfall = function_LCA_plot_waterfall(chula_vista_1a[[3]], chula_vista_1a[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP", batt_damages_raw, "Chula Vista 1A")
          chula_vista_1a_co_waterfall = function_LCA_plot_waterfall(chula_vista_1a[[4]], chula_vista_1a[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP", batt_damages_raw, "Chula Vista 1A")
          chula_vista_1a_nox_waterfall = function_LCA_plot_waterfall(chula_vista_1a[[5]], chula_vista_1a[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP", batt_damages_raw, "Chula Vista 1A")
          chula_vista_1a_sox_waterfall = function_LCA_plot_waterfall(chula_vista_1a[[6]], chula_vista_1a[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP", batt_damages_raw, "Chula Vista 1A")
          chula_vista_1a_pm25_waterfall = function_LCA_plot_waterfall(chula_vista_1a[[7]], chula_vista_1a[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP", batt_damages_raw, "Chula Vista 1A")
          chula_vista_1a_voc_waterfall = function_LCA_plot_waterfall(chula_vista_1a[[8]], chula_vista_1a[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP", batt_damages_raw, "Chula Vista 1A")
          
          chula_vista_1a_ghg_percent = function_LCA_plot_percent(chula_vista_1a[[3]], chula_vista_1a[[11]])
          chula_vista_1a_co_percent = function_LCA_plot_percent(chula_vista_1a[[4]], chula_vista_1a[[11]])
          chula_vista_1a_nox_percent = function_LCA_plot_percent(chula_vista_1a[[5]], chula_vista_1a[[11]])
          chula_vista_1a_sox_percent = function_LCA_plot_percent(chula_vista_1a[[6]], chula_vista_1a[[11]])
          chula_vista_1a_pm25_percent = function_LCA_plot_percent(chula_vista_1a[[7]], chula_vista_1a[[11]])
          chula_vista_1a_voc_percent = function_LCA_plot_percent(chula_vista_1a[[8]], chula_vista_1a[[11]])
          
          chula_vista_1a_npv = function_npv_plot_waterfall(chula_vista_1a[[10]], chula_vista_1a[[12]],
                                                           batt_damages_raw, discount_series,
                                                           "Chula Vista Energy Center - Unit 1A",
                                                           "Chula Vista 1A",
                                                           plant_profits, elec_prices,
                                                           "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(chula_vista_1a_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Chula Vista energy Center Unit 1A - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = chula_vista_1a_cost$YPos_Ind + 2* chula_vista_1a_cost$STDev + 14, label = paste(chula_vista_1a_cost$Mean, '+/-', 2* chula_vista_1a_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/chula_vista_1a_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(chula_vista_1a_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Chula Vista energy Center Unit 1A - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = chula_vista_1a_cost$`Duration Hr`[1], 
                     y = sum(chula_vista_1a_cost$YPos_Ind) + 2*sum(chula_vista_1a_cost$STDev^2)^0.5 + 15, label = paste(sum(chula_vista_1a_cost$Mean), '+/-', round(2*sum(chula_vista_1a_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/chula_vista_1a_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Chula Vista energy Center Unit 1A - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = chula_vista_1a_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                     xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                     ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = chula_vista_1a_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                                 last(group.id),
                                                                                 group.id+0.25), 
                                                                        xend=ifelse(group.id == last(group.id),
                                                                                    last(group.id),
                                                                                    group.id+0.75), 
                                                                        y=ifelse(end.id == 1,
                                                                                 end.bar,
                                                                                 # these will be removed once we set the y limits
                                                                                 max(end.bar)*2*99999999999), 
                                                                        yend=ifelse(end.id == 1,
                                                                                    end.bar,
                                                                                    # these will be removed once we set the y limits
                                                                                    max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = chula_vista_1a_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(chula_vista_1a_ghg_waterfall[[10]]$Mean) - sum(chula_vista_1a_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(chula_vista_1a_ghg_waterfall[[10]]$Mean) + sum(chula_vista_1a_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = chula_vista_1a_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/chula_vista_1a_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Chula Vista energy Center Unit 1A - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = chula_vista_1a_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                          xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                          ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = chula_vista_1a_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                      last(group.id),
                                                                      group.id+0.25), 
                                                             xend=ifelse(group.id == last(group.id),
                                                                         last(group.id),
                                                                         group.id+0.75), 
                                                             y=ifelse(end.id == 1,
                                                                      end.bar,
                                                                      # these will be removed once we set the y limits
                                                                      max(end.bar)*2*99999999999), 
                                                             yend=ifelse(end.id == 1,
                                                                         end.bar,
                                                                         # these will be removed once we set the y limits
                                                                         max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = chula_vista_1a_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/chula_vista_1a_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # Chula Vista 1B # 
          #------------------------------------------------------------------------------
          
          chula_vista_1b = function_monte_carlo_plot("Average",
                                                     "National",
                                                     43, # size
                                                     4,
                                                     2020,
                                                     Lifespan,
                                                     chem_var, # "LFP Graphite SS",
                                                     2001,
                                                     20, # possibly change this to be a distribution of cycles
                                                     0.95,
                                                     fin_runs,
                                                     "Yes",
                                                     18, # max load
                                                     "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                     "electricity.NG.kWh", # "electricity.NG.kWh"
                                                     "r410a.kg", # "r410a.kg", "r32.kg"
                                                     "Chula Vista Energy Center - Unit 1B") 
          
          
          chula_vista_1b_cost = chula_vista_1b[[1]]
          
          chula_vista_1b_ghg_standard = function_LCA_plot_standard(chula_vista_1b[[3]], chula_vista_1b[[11]])
          chula_vista_1b_co_standard = function_LCA_plot_standard(chula_vista_1b[[4]], chula_vista_1b[[11]])
          chula_vista_1b_nox_standard = function_LCA_plot_standard(chula_vista_1b[[5]], chula_vista_1b[[11]])
          chula_vista_1b_sox_standard = function_LCA_plot_standard(chula_vista_1b[[6]], chula_vista_1b[[11]])
          chula_vista_1b_pm25_standard = function_LCA_plot_standard(chula_vista_1b[[7]], chula_vista_1b[[11]])
          chula_vista_1b_voc_standard = function_LCA_plot_standard(chula_vista_1b[[8]], chula_vista_1b[[11]])
          
          chula_vista_1b_ghg_waterfall = function_LCA_plot_waterfall(chula_vista_1b[[3]], chula_vista_1b[[11]], 0, "Chula Vista Energy Center - Unit 1B", "GWP", batt_damages_raw, "Chula Vista 1B")
          chula_vista_1b_co_waterfall = function_LCA_plot_waterfall(chula_vista_1b[[4]], chula_vista_1b[[11]], 0, "Chula Vista Energy Center - Unit 1B", "GWP", batt_damages_raw, "Chula Vista 1B")
          chula_vista_1b_nox_waterfall = function_LCA_plot_waterfall(chula_vista_1b[[5]], chula_vista_1b[[11]], 0, "Chula Vista Energy Center - Unit 1B", "GWP", batt_damages_raw, "Chula Vista 1B")
          chula_vista_1b_sox_waterfall = function_LCA_plot_waterfall(chula_vista_1b[[6]], chula_vista_1b[[11]], 0, "Chula Vista Energy Center - Unit 1B", "GWP", batt_damages_raw, "Chula Vista 1B")
          chula_vista_1b_pm25_waterfall = function_LCA_plot_waterfall(chula_vista_1b[[7]], chula_vista_1b[[11]], 0, "Chula Vista Energy Center - Unit 1B", "GWP", batt_damages_raw, "Chula Vista 1B")
          chula_vista_1b_voc_waterfall = function_LCA_plot_waterfall(chula_vista_1b[[8]], chula_vista_1b[[11]], 0, "Chula Vista Energy Center - Unit 1B", "GWP", batt_damages_raw, "Chula Vista 1B")
          
          chula_vista_1b_ghg_percent = function_LCA_plot_percent(chula_vista_1b[[3]], chula_vista_1b[[11]])
          chula_vista_1b_co_percent = function_LCA_plot_percent(chula_vista_1b[[4]], chula_vista_1b[[11]])
          chula_vista_1b_nox_percent = function_LCA_plot_percent(chula_vista_1b[[5]], chula_vista_1b[[11]])
          chula_vista_1b_sox_percent = function_LCA_plot_percent(chula_vista_1b[[6]], chula_vista_1b[[11]])
          chula_vista_1b_pm25_percent = function_LCA_plot_percent(chula_vista_1b[[7]], chula_vista_1b[[11]])
          chula_vista_1b_voc_percent = function_LCA_plot_percent(chula_vista_1b[[8]], chula_vista_1b[[11]])
          
          chula_vista_1b_npv = function_npv_plot_waterfall(chula_vista_1b[[10]], chula_vista_1b[[12]],
                                                           batt_damages_raw, discount_series,
                                                           "Chula Vista Energy Center - Unit 1B",
                                                           "Chula Vista 1B",
                                                           plant_profits, elec_prices,
                                                           "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(chula_vista_1b_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Chula Vista Energy Center Unit 1B - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = chula_vista_1b_cost$YPos_Ind + 2* chula_vista_1b_cost$STDev + 14, label = paste(chula_vista_1b_cost$Mean, '+/-', 2* chula_vista_1b_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/chula_vista_1b_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(chula_vista_1b_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Chula Vista Energy Center Unit 1B - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = chula_vista_1b_cost$`Duration Hr`[1], 
                     y = sum(chula_vista_1b_cost$YPos_Ind) + 2*sum(chula_vista_1b_cost$STDev^2)^0.5 + 15, label = paste(sum(chula_vista_1b_cost$Mean), '+/-', round(2*sum(chula_vista_1b_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/chula_vista_1b_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Chula Vista Energy Center Unit 1B - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = chula_vista_1b_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                     xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                     ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = chula_vista_1b_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                                 last(group.id),
                                                                                 group.id+0.25), 
                                                                        xend=ifelse(group.id == last(group.id),
                                                                                    last(group.id),
                                                                                    group.id+0.75), 
                                                                        y=ifelse(end.id == 1,
                                                                                 end.bar,
                                                                                 # these will be removed once we set the y limits
                                                                                 max(end.bar)*2*99999999999), 
                                                                        yend=ifelse(end.id == 1,
                                                                                    end.bar,
                                                                                    # these will be removed once we set the y limits
                                                                                    max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = chula_vista_1b_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(chula_vista_1b_ghg_waterfall[[10]]$Mean) - sum(chula_vista_1b_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(chula_vista_1b_ghg_waterfall[[10]]$Mean) + sum(chula_vista_1b_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = chula_vista_1b_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/chula_vista_1b_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Chula Vista Energy Center Unit 1B - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = chula_vista_1b_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                          xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                          ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = chula_vista_1b_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                      last(group.id),
                                                                      group.id+0.25), 
                                                             xend=ifelse(group.id == last(group.id),
                                                                         last(group.id),
                                                                         group.id+0.75), 
                                                             y=ifelse(end.id == 1,
                                                                      end.bar,
                                                                      # these will be removed once we set the y limits
                                                                      max(end.bar)*2*99999999999), 
                                                             yend=ifelse(end.id == 1,
                                                                         end.bar,
                                                                         # these will be removed once we set the y limits
                                                                         max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = chula_vista_1b_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/chula_vista_1b_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # larkspur 1 # 
          #------------------------------------------------------------------------------
          
          larkspur_1 = function_monte_carlo_plot("Average",
                                                 "National",
                                                 151, # size
                                                 4,
                                                 2020,
                                                 Lifespan,
                                                 chem_var, # "LFP Graphite SS",
                                                 2001,
                                                 43, # possibly change this to be a distribution of cycles
                                                 0.95,
                                                 fin_runs,
                                                 "Yes",
                                                 49, # max load
                                                 "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                 "electricity.NG.kWh", # "electricity.NG.kWh"
                                                 "r410a.kg", # "r410a.kg", "r32.kg"
                                                 "Larkspur Energy Facility - Unit 1") 
          
          
          larkspur_1_cost = larkspur_1[[1]]
          
          larkspur_1_ghg_standard = function_LCA_plot_standard(larkspur_1[[3]], larkspur_1[[11]])
          larkspur_1_co_standard = function_LCA_plot_standard(larkspur_1[[4]], larkspur_1[[11]])
          larkspur_1_nox_standard = function_LCA_plot_standard(larkspur_1[[5]], larkspur_1[[11]])
          larkspur_1_sox_standard = function_LCA_plot_standard(larkspur_1[[6]], larkspur_1[[11]])
          larkspur_1_pm25_standard = function_LCA_plot_standard(larkspur_1[[7]], larkspur_1[[11]])
          larkspur_1_voc_standard = function_LCA_plot_standard(larkspur_1[[8]], larkspur_1[[11]])
          
          larkspur_1_ghg_waterfall = function_LCA_plot_waterfall(larkspur_1[[3]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP", batt_damages_raw, "Larkspur 1")
          larkspur_1_co_waterfall = function_LCA_plot_waterfall(larkspur_1[[4]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP", batt_damages_raw, "Larkspur 1")
          larkspur_1_nox_waterfall = function_LCA_plot_waterfall(larkspur_1[[5]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP", batt_damages_raw, "Larkspur 1")
          larkspur_1_sox_waterfall = function_LCA_plot_waterfall(larkspur_1[[6]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP", batt_damages_raw, "Larkspur 1")
          larkspur_1_pm25_waterfall = function_LCA_plot_waterfall(larkspur_1[[7]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP", batt_damages_raw, "Larkspur 1")
          larkspur_1_voc_waterfall = function_LCA_plot_waterfall(larkspur_1[[8]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP", batt_damages_raw, "Larkspur 1")
          
          larkspur_1_ghg_percent = function_LCA_plot_percent(larkspur_1[[3]], larkspur_1[[11]])
          larkspur_1_co_percent = function_LCA_plot_percent(larkspur_1[[4]], larkspur_1[[11]])
          larkspur_1_nox_percent = function_LCA_plot_percent(larkspur_1[[5]], larkspur_1[[11]])
          larkspur_1_sox_percent = function_LCA_plot_percent(larkspur_1[[6]], larkspur_1[[11]])
          larkspur_1_pm25_percent = function_LCA_plot_percent(larkspur_1[[7]], larkspur_1[[11]])
          larkspur_1_voc_percent = function_LCA_plot_percent(larkspur_1[[8]], larkspur_1[[11]])
          
          larkspur_1_npv = function_npv_plot_waterfall(larkspur_1[[10]], larkspur_1[[12]],
                                                       batt_damages_raw, discount_series,
                                                       "Larkspur Energy Facility - Unit 1",
                                                       "Larkspur 1",
                                                       plant_profits, elec_prices,
                                                       "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(larkspur_1_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Larkspur Energy Facility Unit 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = larkspur_1_cost$YPos_Ind + 2* larkspur_1_cost$STDev + 14, label = paste(larkspur_1_cost$Mean, '+/-', 2* larkspur_1_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/larkspur_1_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(larkspur_1_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Larkspur Energy Facility Unit 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = larkspur_1_cost$`Duration Hr`[1], 
                     y = sum(larkspur_1_cost$YPos_Ind) + 2*sum(larkspur_1_cost$STDev^2)^0.5 + 15, label = paste(sum(larkspur_1_cost$Mean), '+/-', round(2*sum(larkspur_1_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/larkspur_1_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Larkspur Energy Facility Unit 1 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = larkspur_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                 xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                 ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = larkspur_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                             last(group.id),
                                                                             group.id+0.25), 
                                                                    xend=ifelse(group.id == last(group.id),
                                                                                last(group.id),
                                                                                group.id+0.75), 
                                                                    y=ifelse(end.id == 1,
                                                                             end.bar,
                                                                             # these will be removed once we set the y limits
                                                                             max(end.bar)*2*99999999999), 
                                                                    yend=ifelse(end.id == 1,
                                                                                end.bar,
                                                                                # these will be removed once we set the y limits
                                                                                max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = larkspur_1_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(larkspur_1_ghg_waterfall[[10]]$Mean) - sum(larkspur_1_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(larkspur_1_ghg_waterfall[[10]]$Mean) + sum(larkspur_1_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = larkspur_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/larkspur_1_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Larkspur Energy Facility Unit 1 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = larkspur_1_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                      xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                      ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = larkspur_1_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                  last(group.id),
                                                                  group.id+0.25), 
                                                         xend=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.75), 
                                                         y=ifelse(end.id == 1,
                                                                  end.bar,
                                                                  # these will be removed once we set the y limits
                                                                  max(end.bar)*2*99999999999), 
                                                         yend=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = larkspur_1_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/larkspur_1_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # larkspur 2 # 
          #------------------------------------------------------------------------------
          
          larkspur_2 = function_monte_carlo_plot("Average",
                                                 "National",
                                                 85, # size
                                                 4,
                                                 2020,
                                                 Lifespan,
                                                 chem_var, # "LFP Graphite SS",
                                                 2001,
                                                 70, # possibly change this to be a distribution of cycles
                                                 0.95,
                                                 fin_runs,
                                                 "Yes",
                                                 49, # max load
                                                 "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                 "electricity.NG.kWh", # "electricity.NG.kWh"
                                                 "r410a.kg", # "r410a.kg", "r32.kg"
                                                 "Larkspur Energy Facility - Unit 2") 
          
          
          larkspur_2_cost = larkspur_2[[1]]
          
          larkspur_2_ghg_standard = function_LCA_plot_standard(larkspur_2[[3]], larkspur_2[[11]])
          larkspur_2_co_standard = function_LCA_plot_standard(larkspur_2[[4]], larkspur_2[[11]])
          larkspur_2_nox_standard = function_LCA_plot_standard(larkspur_2[[5]], larkspur_2[[11]])
          larkspur_2_sox_standard = function_LCA_plot_standard(larkspur_2[[6]], larkspur_2[[11]])
          larkspur_2_pm25_standard = function_LCA_plot_standard(larkspur_2[[7]], larkspur_2[[11]])
          larkspur_2_voc_standard = function_LCA_plot_standard(larkspur_2[[8]], larkspur_2[[11]])
          
          larkspur_2_ghg_waterfall = function_LCA_plot_waterfall(larkspur_2[[3]], larkspur_2[[11]], 0, "Larkspur Energy Facility - Unit 2", "GWP", batt_damages_raw, "Larkspur 2")
          larkspur_2_co_waterfall = function_LCA_plot_waterfall(larkspur_2[[4]], larkspur_2[[11]], 0, "Larkspur Energy Facility - Unit 2", "GWP", batt_damages_raw, "Larkspur 2")
          larkspur_2_nox_waterfall = function_LCA_plot_waterfall(larkspur_2[[5]], larkspur_2[[11]], 0, "Larkspur Energy Facility - Unit 2", "GWP", batt_damages_raw, "Larkspur 2")
          larkspur_2_sox_waterfall = function_LCA_plot_waterfall(larkspur_2[[6]], larkspur_2[[11]], 0, "Larkspur Energy Facility - Unit 2", "GWP", batt_damages_raw, "Larkspur 2")
          larkspur_2_pm25_waterfall = function_LCA_plot_waterfall(larkspur_2[[7]], larkspur_2[[11]], 0, "Larkspur Energy Facility - Unit 2", "GWP", batt_damages_raw, "Larkspur 2")
          larkspur_2_voc_waterfall = function_LCA_plot_waterfall(larkspur_2[[8]], larkspur_2[[11]], 0, "Larkspur Energy Facility - Unit 2", "GWP", batt_damages_raw, "Larkspur 2")
          
          larkspur_2_ghg_percent = function_LCA_plot_percent(larkspur_2[[3]], larkspur_2[[11]])
          larkspur_2_co_percent = function_LCA_plot_percent(larkspur_2[[4]], larkspur_2[[11]])
          larkspur_2_nox_percent = function_LCA_plot_percent(larkspur_2[[5]], larkspur_2[[11]])
          larkspur_2_sox_percent = function_LCA_plot_percent(larkspur_2[[6]], larkspur_2[[11]])
          larkspur_2_pm25_percent = function_LCA_plot_percent(larkspur_2[[7]], larkspur_2[[11]])
          larkspur_2_voc_percent = function_LCA_plot_percent(larkspur_2[[8]], larkspur_2[[11]])
          
          larkspur_2_npv = function_npv_plot_waterfall(larkspur_2[[10]], larkspur_2[[12]],
                                                       batt_damages_raw, discount_series,
                                                       "Larkspur Energy Facility - Unit 2",
                                                       "Larkspur 2",
                                                       plant_profits, elec_prices,
                                                       "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(larkspur_2_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Larkspur Energy Facility Unit 2 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = larkspur_2_cost$YPos_Ind + 2* larkspur_2_cost$STDev + 14, label = paste(larkspur_2_cost$Mean, '+/-', 2* larkspur_2_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/larkspur_2_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(larkspur_2_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Larkspur Energy Facility Unit 2 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = larkspur_2_cost$`Duration Hr`[1], 
                     y = sum(larkspur_2_cost$YPos_Ind) + 2*sum(larkspur_2_cost$STDev^2)^0.5 + 15, label = paste(sum(larkspur_2_cost$Mean), '+/-', round(2*sum(larkspur_2_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/larkspur_2_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Larkspur Energy Facility Unit 2 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = larkspur_2_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                 xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                 ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = larkspur_2_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                             last(group.id),
                                                                             group.id+0.25), 
                                                                    xend=ifelse(group.id == last(group.id),
                                                                                last(group.id),
                                                                                group.id+0.75), 
                                                                    y=ifelse(end.id == 1,
                                                                             end.bar,
                                                                             # these will be removed once we set the y limits
                                                                             max(end.bar)*2*99999999999), 
                                                                    yend=ifelse(end.id == 1,
                                                                                end.bar,
                                                                                # these will be removed once we set the y limits
                                                                                max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = larkspur_2_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(larkspur_2_ghg_waterfall[[10]]$Mean) - sum(larkspur_2_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(larkspur_2_ghg_waterfall[[10]]$Mean) + sum(larkspur_2_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = larkspur_2_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/larkspur_2_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Larkspur Energy Facility Unit 2 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = larkspur_2_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                      xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                      ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = larkspur_2_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                  last(group.id),
                                                                  group.id+0.25), 
                                                         xend=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.75), 
                                                         y=ifelse(end.id == 1,
                                                                  end.bar,
                                                                  # these will be removed once we set the y limits
                                                                  max(end.bar)*2*99999999999), 
                                                         yend=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = larkspur_2_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/larkspur_2_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          
          
          #------------------------------------------------------------------------------
          # Hanford 2 # 
          #------------------------------------------------------------------------------
          
          hanford_2 = function_monte_carlo_plot("Average",
                                                "National",
                                                47, # size
                                                4,
                                                2020,
                                                Lifespan,
                                                chem_var, # "LFP Graphite SS",
                                                2001,
                                                41, # possibly change this to be a distribution of cycles
                                                0.95,
                                                fin_runs,
                                                "Yes",
                                                47, # max load
                                                "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                "electricity.NG.kWh", # "electricity.NG.kWh"
                                                "r410a.kg", # "r410a.kg", "r32.kg"
                                                "Hanford Energy Park Peaker - Unit 2") 
          
          
          hanford_2_cost = hanford_2[[1]]
          
          hanford_2_ghg_standard = function_LCA_plot_standard(hanford_2[[3]], hanford_2[[11]])
          hanford_2_co_standard = function_LCA_plot_standard(hanford_2[[4]], hanford_2[[11]])
          hanford_2_nox_standard = function_LCA_plot_standard(hanford_2[[5]], hanford_2[[11]])
          hanford_2_sox_standard = function_LCA_plot_standard(hanford_2[[6]], hanford_2[[11]])
          hanford_2_pm25_standard = function_LCA_plot_standard(hanford_2[[7]], hanford_2[[11]])
          hanford_2_voc_standard = function_LCA_plot_standard(hanford_2[[8]], hanford_2[[11]])
          
          hanford_2_ghg_waterfall = function_LCA_plot_waterfall(hanford_2[[3]], hanford_2[[11]], 0, "Hanford Energy Park Peaker - Unit 2", "GWP", batt_damages_raw, "Hanford 2")
          hanford_2_co_waterfall = function_LCA_plot_waterfall(hanford_2[[4]], hanford_2[[11]], 0, "Hanford Energy Park Peaker - Unit 2", "GWP", batt_damages_raw, "Hanford 2")
          hanford_2_nox_waterfall = function_LCA_plot_waterfall(hanford_2[[5]], hanford_2[[11]], 0, "Hanford Energy Park Peaker - Unit 2", "GWP", batt_damages_raw, "Hanford 2")
          hanford_2_sox_waterfall = function_LCA_plot_waterfall(hanford_2[[6]], hanford_2[[11]], 0, "Hanford Energy Park Peaker - Unit 2", "GWP", batt_damages_raw, "Hanford 2")
          hanford_2_pm25_waterfall = function_LCA_plot_waterfall(hanford_2[[7]], hanford_2[[11]], 0, "Hanford Energy Park Peaker - Unit 2", "GWP", batt_damages_raw, "Hanford 2")
          hanford_2_voc_waterfall = function_LCA_plot_waterfall(hanford_2[[8]], hanford_2[[11]], 0, "Hanford Energy Park Peaker - Unit 2", "GWP", batt_damages_raw, "Hanford 2")
          
          hanford_2_ghg_percent = function_LCA_plot_percent(hanford_2[[3]], hanford_2[[11]])
          hanford_2_co_percent = function_LCA_plot_percent(hanford_2[[4]], hanford_2[[11]])
          hanford_2_nox_percent = function_LCA_plot_percent(hanford_2[[5]], hanford_2[[11]])
          hanford_2_sox_percent = function_LCA_plot_percent(hanford_2[[6]], hanford_2[[11]])
          hanford_2_pm25_percent = function_LCA_plot_percent(hanford_2[[7]], hanford_2[[11]])
          hanford_2_voc_percent = function_LCA_plot_percent(hanford_2[[8]], hanford_2[[11]])
          
          hanford_2_npv = function_npv_plot_waterfall(hanford_2[[10]], hanford_2[[12]],
                                                      batt_damages_raw, discount_series,
                                                      "Hanford Energy Park Peaker - Unit 2",
                                                      "Hanford 2",
                                                      plant_profits, elec_prices,
                                                      "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(hanford_2_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Hanford Energy Park Peaker Unit 2 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = hanford_2_cost$YPos_Ind + 2* hanford_2_cost$STDev + 14, label = paste(hanford_2_cost$Mean, '+/-', 2* hanford_2_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/hanford_2_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(hanford_2_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Hanford Energy Park Peaker Unit 2 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = hanford_2_cost$`Duration Hr`[1], 
                     y = sum(hanford_2_cost$YPos_Ind) + 2*sum(hanford_2_cost$STDev^2)^0.5 + 15, label = paste(sum(hanford_2_cost$Mean), '+/-', round(2*sum(hanford_2_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/hanford_2_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Hanford Energy Park Peaker Unit 2 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = hanford_2_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = hanford_2_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                            last(group.id),
                                                                            group.id+0.25), 
                                                                   xend=ifelse(group.id == last(group.id),
                                                                               last(group.id),
                                                                               group.id+0.75), 
                                                                   y=ifelse(end.id == 1,
                                                                            end.bar,
                                                                            # these will be removed once we set the y limits
                                                                            max(end.bar)*2*99999999999), 
                                                                   yend=ifelse(end.id == 1,
                                                                               end.bar,
                                                                               # these will be removed once we set the y limits
                                                                               max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = hanford_2_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(hanford_2_ghg_waterfall[[10]]$Mean) - sum(hanford_2_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(hanford_2_ghg_waterfall[[10]]$Mean) + sum(hanford_2_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = hanford_2_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/hanford_2_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Hanford Energy Park Peaker Unit 2 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = hanford_2_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                     xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                     ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = hanford_2_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                 last(group.id),
                                                                 group.id+0.25), 
                                                        xend=ifelse(group.id == last(group.id),
                                                                    last(group.id),
                                                                    group.id+0.75), 
                                                        y=ifelse(end.id == 1,
                                                                 end.bar,
                                                                 # these will be removed once we set the y limits
                                                                 max(end.bar)*2*99999999999), 
                                                        yend=ifelse(end.id == 1,
                                                                    end.bar,
                                                                    # these will be removed once we set the y limits
                                                                    max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = hanford_2_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.75*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/hanford_2_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # Wolfskill 1 # 
          #------------------------------------------------------------------------------
          
          wolfskill_1 = function_monte_carlo_plot("Average",
                                                  "National",
                                                  70, # size
                                                  4,
                                                  2020,
                                                  Lifespan,
                                                  chem_var, # "LFP Graphite SS",
                                                  2001,
                                                  34, # possibly change this to be a distribution of cycles
                                                  0.95,
                                                  fin_runs,
                                                  "Yes",
                                                  48, # max load
                                                  "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                  "electricity.NG.kWh", # "electricity.NG.kWh"
                                                  "r410a.kg", # "r410a.kg", "r32.kg"
                                                  "Wolfskill Energy Center - Unit 1") 
          
          
          wolfskill_1_cost = wolfskill_1[[1]]
          
          wolfskill_1_ghg_standard = function_LCA_plot_standard(wolfskill_1[[3]], wolfskill_1[[11]])
          wolfskill_1_co_standard = function_LCA_plot_standard(wolfskill_1[[4]], wolfskill_1[[11]])
          wolfskill_1_nox_standard = function_LCA_plot_standard(wolfskill_1[[5]], wolfskill_1[[11]])
          wolfskill_1_sox_standard = function_LCA_plot_standard(wolfskill_1[[6]], wolfskill_1[[11]])
          wolfskill_1_pm25_standard = function_LCA_plot_standard(wolfskill_1[[7]], wolfskill_1[[11]])
          wolfskill_1_voc_standard = function_LCA_plot_standard(wolfskill_1[[8]], wolfskill_1[[11]])
          
          wolfskill_1_ghg_waterfall = function_LCA_plot_waterfall(wolfskill_1[[3]], wolfskill_1[[11]], 0, "Wolfskill Energy Center - Unit 1", "GWP", batt_damages_raw, "Wolfskill 1")
          wolfskill_1_co_waterfall = function_LCA_plot_waterfall(wolfskill_1[[4]], wolfskill_1[[11]], 0, "Wolfskill Energy Center - Unit 1", "GWP", batt_damages_raw, "Wolfskill 1")
          wolfskill_1_nox_waterfall = function_LCA_plot_waterfall(wolfskill_1[[5]], wolfskill_1[[11]], 0, "Wolfskill Energy Center - Unit 1", "GWP", batt_damages_raw, "Wolfskill 1")
          wolfskill_1_sox_waterfall = function_LCA_plot_waterfall(wolfskill_1[[6]], wolfskill_1[[11]], 0, "Wolfskill Energy Center - Unit 1", "GWP", batt_damages_raw, "Wolfskill 1")
          wolfskill_1_pm25_waterfall = function_LCA_plot_waterfall(wolfskill_1[[7]], wolfskill_1[[11]], 0, "Wolfskill Energy Center - Unit 1", "GWP", batt_damages_raw, "Wolfskill 1")
          wolfskill_1_voc_waterfall = function_LCA_plot_waterfall(wolfskill_1[[8]], wolfskill_1[[11]], 0, "Wolfskill Energy Center - Unit 1", "GWP", batt_damages_raw, "Wolfskill 1")
          
          wolfskill_1_ghg_percent = function_LCA_plot_percent(wolfskill_1[[3]], wolfskill_1[[11]])
          wolfskill_1_co_percent = function_LCA_plot_percent(wolfskill_1[[4]], wolfskill_1[[11]])
          wolfskill_1_nox_percent = function_LCA_plot_percent(wolfskill_1[[5]], wolfskill_1[[11]])
          wolfskill_1_sox_percent = function_LCA_plot_percent(wolfskill_1[[6]], wolfskill_1[[11]])
          wolfskill_1_pm25_percent = function_LCA_plot_percent(wolfskill_1[[7]], wolfskill_1[[11]])
          wolfskill_1_voc_percent = function_LCA_plot_percent(wolfskill_1[[8]], wolfskill_1[[11]])
          
          wolfskill_1_npv = function_npv_plot_waterfall(wolfskill_1[[10]], wolfskill_1[[12]],
                                                        batt_damages_raw, discount_series,
                                                        "Wolfskill Energy Center - Unit 1",
                                                        "Wolfskill 1",
                                                        plant_profits, elec_prices,
                                                        "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(wolfskill_1_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Wolfskill Energy Center Unit 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = wolfskill_1_cost$YPos_Ind + 2* wolfskill_1_cost$STDev + 14, label = paste(wolfskill_1_cost$Mean, '+/-', 2* wolfskill_1_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/wolfskill_1_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(wolfskill_1_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Wolfskill Energy Center Unit 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = wolfskill_1_cost$`Duration Hr`[1], 
                     y = sum(wolfskill_1_cost$YPos_Ind) + 2*sum(wolfskill_1_cost$STDev^2)^0.5 + 15, label = paste(sum(wolfskill_1_cost$Mean), '+/-', round(2*sum(wolfskill_1_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/wolfskill_1_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Wolfskill Energy Center Unit 1 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = wolfskill_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                  xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                  ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = wolfskill_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                              last(group.id),
                                                                              group.id+0.25), 
                                                                     xend=ifelse(group.id == last(group.id),
                                                                                 last(group.id),
                                                                                 group.id+0.75), 
                                                                     y=ifelse(end.id == 1,
                                                                              end.bar,
                                                                              # these will be removed once we set the y limits
                                                                              max(end.bar)*2*99999999999), 
                                                                     yend=ifelse(end.id == 1,
                                                                                 end.bar,
                                                                                 # these will be removed once we set the y limits
                                                                                 max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = wolfskill_1_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(wolfskill_1_ghg_waterfall[[10]]$Mean) - sum(wolfskill_1_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(wolfskill_1_ghg_waterfall[[10]]$Mean) + sum(wolfskill_1_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = wolfskill_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/wolfskill_1_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Wolfskill Energy Center Unit 1 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = wolfskill_1_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                       xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                       ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = wolfskill_1_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                   last(group.id),
                                                                   group.id+0.25), 
                                                          xend=ifelse(group.id == last(group.id),
                                                                      last(group.id),
                                                                      group.id+0.75), 
                                                          y=ifelse(end.id == 1,
                                                                   end.bar,
                                                                   # these will be removed once we set the y limits
                                                                   max(end.bar)*2*99999999999), 
                                                          yend=ifelse(end.id == 1,
                                                                      end.bar,
                                                                      # these will be removed once we set the y limits
                                                                      max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = wolfskill_1_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/wolfskill_1_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          #------------------------------------------------------------------------------
          # Riverside 4 # 
          #------------------------------------------------------------------------------
          
          riverside_4 = function_monte_carlo_plot("Average",
                                                  "National",
                                                  88, # size
                                                  4,
                                                  2020,
                                                  Lifespan,
                                                  chem_var, # "LFP Graphite SS",
                                                  2001,
                                                  58, # possibly change this to be a distribution of cycles
                                                  0.95,
                                                  fin_runs,
                                                  "Yes",
                                                  51, # max load
                                                  "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                  "electricity.NG.kWh", # "electricity.NG.kWh"
                                                  "r410a.kg", # "r410a.kg", "r32.kg"
                                                  "Riverside Energy Resource Center - Unit 4") 
          
          
          riverside_4_cost = riverside_4[[1]]
          
          riverside_4_ghg_standard = function_LCA_plot_standard(riverside_4[[3]], riverside_4[[11]])
          riverside_4_co_standard = function_LCA_plot_standard(riverside_4[[4]], riverside_4[[11]])
          riverside_4_nox_standard = function_LCA_plot_standard(riverside_4[[5]], riverside_4[[11]])
          riverside_4_sox_standard = function_LCA_plot_standard(riverside_4[[6]], riverside_4[[11]])
          riverside_4_pm25_standard = function_LCA_plot_standard(riverside_4[[7]], riverside_4[[11]])
          riverside_4_voc_standard = function_LCA_plot_standard(riverside_4[[8]], riverside_4[[11]])
          
          riverside_4_ghg_waterfall = function_LCA_plot_waterfall(riverside_4[[3]], riverside_4[[11]], 0, "Riverside Energy Resource Center - Unit 4", "GWP", batt_damages_raw, "Riverside 4")
          riverside_4_co_waterfall = function_LCA_plot_waterfall(riverside_4[[4]], riverside_4[[11]], 0, "Riverside Energy Resource Center - Unit 4", "GWP", batt_damages_raw, "Riverside 4")
          riverside_4_nox_waterfall = function_LCA_plot_waterfall(riverside_4[[5]], riverside_4[[11]], 0, "Riverside Energy Resource Center - Unit 4", "GWP", batt_damages_raw, "Riverside 4")
          riverside_4_sox_waterfall = function_LCA_plot_waterfall(riverside_4[[6]], riverside_4[[11]], 0, "Riverside Energy Resource Center - Unit 4", "GWP", batt_damages_raw, "Riverside 4")
          riverside_4_pm25_waterfall = function_LCA_plot_waterfall(riverside_4[[7]], riverside_4[[11]], 0, "Riverside Energy Resource Center - Unit 4", "GWP", batt_damages_raw, "Riverside 4")
          riverside_4_voc_waterfall = function_LCA_plot_waterfall(riverside_4[[8]], riverside_4[[11]], 0, "Riverside Energy Resource Center - Unit 4", "GWP", batt_damages_raw, "Riverside 4")
          
          riverside_4_ghg_percent = function_LCA_plot_percent(riverside_4[[3]], riverside_4[[11]])
          riverside_4_co_percent = function_LCA_plot_percent(riverside_4[[4]], riverside_4[[11]])
          riverside_4_nox_percent = function_LCA_plot_percent(riverside_4[[5]], riverside_4[[11]])
          riverside_4_sox_percent = function_LCA_plot_percent(riverside_4[[6]], riverside_4[[11]])
          riverside_4_pm25_percent = function_LCA_plot_percent(riverside_4[[7]], riverside_4[[11]])
          riverside_4_voc_percent = function_LCA_plot_percent(riverside_4[[8]], riverside_4[[11]])
          
          riverside_4_npv = function_npv_plot_waterfall(riverside_4[[10]], riverside_4[[12]],
                                                        batt_damages_raw, discount_series,
                                                        "Riverside Energy Resource Center - Unit 4",
                                                        "Riverside 4", 
                                                        plant_profits, elec_prices,
                                                        "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(riverside_4_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Riverside Energy Resource Center Unit 4 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = riverside_4_cost$YPos_Ind + 2* riverside_4_cost$STDev + 14, label = paste(riverside_4_cost$Mean, '+/-', 2* riverside_4_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/riverside_4_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(riverside_4_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Riverside Energy Resource Center Unit 4 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = riverside_4_cost$`Duration Hr`[1], 
                     y = sum(riverside_4_cost$YPos_Ind) + 2*sum(riverside_4_cost$STDev^2)^0.5 + 15, label = paste(sum(riverside_4_cost$Mean), '+/-', round(2*sum(riverside_4_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/riverside_4_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Riverside Energy Resource Center Unit 4 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = riverside_4_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                                  xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                  ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = riverside_4_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                              last(group.id),
                                                                              group.id+0.25), 
                                                                     xend=ifelse(group.id == last(group.id),
                                                                                 last(group.id),
                                                                                 group.id+0.75), 
                                                                     y=ifelse(end.id == 1,
                                                                              end.bar,
                                                                              # these will be removed once we set the y limits
                                                                              max(end.bar)*2*99999999999), 
                                                                     yend=ifelse(end.id == 1,
                                                                                 end.bar,
                                                                                 # these will be removed once we set the y limits
                                                                                 max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = riverside_4_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(riverside_4_ghg_waterfall[[10]]$Mean) - sum(riverside_4_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(riverside_4_ghg_waterfall[[10]]$Mean) + sum(riverside_4_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = riverside_4_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/riverside_4_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Riverside Energy Resource Center Unit 4 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = riverside_4_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                       xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                       ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = riverside_4_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                   last(group.id),
                                                                   group.id+0.25), 
                                                          xend=ifelse(group.id == last(group.id),
                                                                      last(group.id),
                                                                      group.id+0.75), 
                                                          y=ifelse(end.id == 1,
                                                                   end.bar,
                                                                   # these will be removed once we set the y limits
                                                                   max(end.bar)*2*99999999999), 
                                                          yend=ifelse(end.id == 1,
                                                                      end.bar,
                                                                      # these will be removed once we set the y limits
                                                                      max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = riverside_4_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/riverside_4_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          
          
          #------------------------------------------------------------------------------
          # center 1 # 
          #------------------------------------------------------------------------------
          
          center_1 = function_monte_carlo_plot("Average",
                                               "National",
                                               140, # size
                                               4,
                                               2020,
                                               Lifespan,
                                               chem_var, # "LFP Graphite SS",
                                               2001,
                                               34, # possibly change this to be a distribution of cycles
                                               0.95,
                                               fin_runs,
                                               "Yes",
                                               48, # max load
                                               "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                               "electricity.NG.kWh", # "electricity.NG.kWh"
                                               "r410a.kg", # "r410a.kg", "r32.kg"
                                               "Center Generating Station - Combined Turbine 1") 
          
          
          center_1_cost = center_1[[1]]
          
          center_1_ghg_standard = function_LCA_plot_standard(center_1[[3]], center_1[[11]])
          center_1_co_standard = function_LCA_plot_standard(center_1[[4]], center_1[[11]])
          center_1_nox_standard = function_LCA_plot_standard(center_1[[5]], center_1[[11]])
          center_1_sox_standard = function_LCA_plot_standard(center_1[[6]], center_1[[11]])
          center_1_pm25_standard = function_LCA_plot_standard(center_1[[7]], center_1[[11]])
          center_1_voc_standard = function_LCA_plot_standard(center_1[[8]], center_1[[11]])
          
          center_1_ghg_waterfall = function_LCA_plot_waterfall(center_1[[3]], center_1[[11]], 0, "Center Generating Station - Combined Turbine 1", "GWP", batt_damages_raw, "Center 1")
          center_1_co_waterfall = function_LCA_plot_waterfall(center_1[[4]], center_1[[11]], 0, "Center Generating Station - Combined Turbine 1", "GWP", batt_damages_raw, "Center 1")
          center_1_nox_waterfall = function_LCA_plot_waterfall(center_1[[5]], center_1[[11]], 0, "Center Generating Station - Combined Turbine 1", "GWP", batt_damages_raw, "Center 1")
          center_1_sox_waterfall = function_LCA_plot_waterfall(center_1[[6]], center_1[[11]], 0, "Center Generating Station - Combined Turbine 1", "GWP", batt_damages_raw, "Center 1")
          center_1_pm25_waterfall = function_LCA_plot_waterfall(center_1[[7]], center_1[[11]], 0, "Center Generating Station - Combined Turbine 1", "GWP", batt_damages_raw, "Center 1")
          center_1_voc_waterfall = function_LCA_plot_waterfall(center_1[[8]], center_1[[11]], 0, "Center Generating Station - Combined Turbine 1", "GWP", batt_damages_raw, "Center 1")
          
          center_1_ghg_percent = function_LCA_plot_percent(center_1[[3]], center_1[[11]])
          center_1_co_percent = function_LCA_plot_percent(center_1[[4]], center_1[[11]])
          center_1_nox_percent = function_LCA_plot_percent(center_1[[5]], center_1[[11]])
          center_1_sox_percent = function_LCA_plot_percent(center_1[[6]], center_1[[11]])
          center_1_pm25_percent = function_LCA_plot_percent(center_1[[7]], center_1[[11]])
          center_1_voc_percent = function_LCA_plot_percent(center_1[[8]], center_1[[11]])
          
          center_1_npv = function_npv_plot_waterfall(center_1[[10]], center_1[[12]],
                                                     batt_damages_raw, discount_series,
                                                     "Center Generating Station - Combined Turbine 1",
                                                     "Center 1",
                                                     plant_profits, elec_prices,
                                                     "RTE85", "LFP")
          
          ### cost plotting ###
          
          ggplot(center_1_cost, aes(x = Component, y = Mean, fill = Component)) +
            ggtitle("Center Generating Station Combined Turbine 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.5) +
            geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
            annotate("text", x = graph_order,
                     y = center_1_cost$YPos_Ind + 2* center_1_cost$STDev + 14, label = paste(center_1_cost$Mean, '+/-', 2* center_1_cost$STDev), size = 5.5) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
            ylab("2020 USD per kWh") +
            xlab("") + # xlab("Cost Category") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/center_1_cost_breakdown.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          ggplot(center_1_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
            ggtitle("Center Generating Station Combined Turbine 1 - Li-ion BESS Upfront Cost") +
            geom_bar(stat="identity", width = 0.25) +
            geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
            geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
            annotate("text", x = center_1_cost$`Duration Hr`[1], 
                     y = sum(center_1_cost$YPos_Ind) + 2*sum(center_1_cost$STDev^2)^0.5 + 15, label = paste(sum(center_1_cost$Mean), '+/-', round(2*sum(center_1_cost$STDev^2)^0.5,2))) +
            theme_minimal() +
            # scale_fill_brewer(palette = "Spectral") +
            scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
            labs(title = "BESS 200 MWh / 50 MW") +
            ylab("2020 USD per kWh")+
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 32.5),
                  axis.title = element_text(size = 30),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  legend.title = element_text(size = 30),
                  legend.text = element_text(size = 30)) # 1500 x 600
          
          ggsave(paste("scenario_figures_09_02_22/center_1_cost_stack.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 20, units = "cm")
          
          ### ghg plotting ###
          
          ggplot() +
            ggtitle("Center Generating Station Combined Turbine 1 - Li-ion BESS Life-cycle Global Warming Potential") +
            geom_hline(yintercept=0) + 
            geom_rect(data = center_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                               xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                               ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = center_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                           last(group.id),
                                                                           group.id+0.25), 
                                                                  xend=ifelse(group.id == last(group.id),
                                                                              last(group.id),
                                                                              group.id+0.75), 
                                                                  y=ifelse(end.id == 1,
                                                                           end.bar,
                                                                           # these will be removed once we set the y limits
                                                                           max(end.bar)*2*99999999999), 
                                                                  yend=ifelse(end.id == 1,
                                                                              end.bar,
                                                                              # these will be removed once we set the y limits
                                                                              max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "white", "black")) +
            geom_errorbar(data = center_1_ghg_waterfall[[10]], 
                          aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                          width = 0.25) +
            # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(center_1_ghg_waterfall[[10]]$Mean) - sum(center_1_ghg_waterfall[[10]]$STDev^2)^0.5,
            #                   ymax = sum(center_1_ghg_waterfall[[10]]$Mean) + sum(center_1_ghg_waterfall[[10]]$STDev^2)^0.5),
            #               width=0.6, size=1.25, color="darkred") + 
            # geom_point(aes(x = "Offset Electricity", y = center_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
            theme_minimal() +
            scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
            labs(fill = "Emissions Category") +
            xlab("") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(# axis.text.y = element_blank(),
              # axis.title.y = element_blank(),
              # axis.text.y = element_text(size = 12.5),
              plot.title = element_text(size = 22.5),
              axis.title = element_text(size = 22.5),
              axis.text.x = element_text(size = 14),
              text = element_text(size=17.5),
              # legend.position = "none",
              legend.title = element_text(size = 20),
              legend.text = element_text(size = 15))
          
          ggsave(paste("scenario_figures_09_02_22/center_1_ghg_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          
          ### NPV plot ###
          
          
          ggplot() +
            ggtitle("Center Generating Station Combined Turbine 1 - Li-ion BESS Net Present Value") +
            geom_hline(yintercept=0) + 
            geom_rect(data = center_1_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                                    xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                    ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_segment(data = center_1_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                                last(group.id),
                                                                group.id+0.25), 
                                                       xend=ifelse(group.id == last(group.id),
                                                                   last(group.id),
                                                                   group.id+0.75), 
                                                       y=ifelse(end.id == 1,
                                                                end.bar,
                                                                # these will be removed once we set the y limits
                                                                max(end.bar)*2*99999999999), 
                                                       yend=ifelse(end.id == 1,
                                                                   end.bar,
                                                                   # these will be removed once we set the y limits
                                                                   max(end.bar)*2*99999999999)), 
                         colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "white", "black")) +
            geom_errorbar(data = center_1_npv[[2]], 
                          aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 12.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 12.5),
                  text = element_text(size=17.5),
                  # legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            ylim(-3.5*10^2, 0.5*10^2)
          
          ggsave(paste("scenario_figures_09_02_22/center_1_npv_water.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 40, height = 20, units = "cm")
          
          #------------------------------------------------------------------------------
          # cumulative figures cleaning - npv # 
          #------------------------------------------------------------------------------
          
          plant_list = c("long_beach_1_npv", "long_beach_2_npv", "long_beach_3_npv", "long_beach_4_npv",
                         "harbor_gen_10_npv", "harbor_gen_13_npv", "harbor_gen_14_npv", "glenarm_4_npv",
                         "calpeak_border_1_npv", "cuyamaca_peak_1_npv", "calpeak_enterprise_1_npv", "chula_vista_1a_npv", 
                         "chula_vista_1b_npv", "larkspur_1_npv", "larkspur_2_npv", "hanford_2_npv", 
                         "wolfskill_1_npv", "riverside_4_npv", "center_1_npv")
          
          
          all_plants_df = long_beach_1_npv[[3]]
          all_plants_df_std = long_beach_1_npv[[2]]
          
          for (i in 2:length(plant_list)) {
            
            all_plants_df = rbind(all_plants_df, get(plant_list[i])[[3]])
            all_plants_df_std = rbind(all_plants_df_std, get(plant_list[i])[[2]])
            
          }
          
          tot_plants_df_std = all_plants_df_std[all_plants_df_std$`NPV Category`=="Total NPV",]
          
          for (i in 1:length(plant_list)) {
            
            tot_plants_df_std$Mean[i] = get(plant_list[i])[[1]]$Mean[length(get(plant_list[i])[[1]]$Mean)]
            
          }
          
          
          all_plants_df$`Peaker Plant` = factor(all_plants_df$`Peaker Plant`,
                                                levels = tot_plants_df_std$`Peaker Plant`[order(tot_plants_df_std$Mean)])
          
          
          plant.id = rep(0,dim(all_plants_df)[1])
          plant.id.std = rep(0,length(dim(all_plants_df_std)[1]))
          
          all_plants_df = cbind(all_plants_df, plant.id)
          all_plants_df_std = cbind(all_plants_df_std, plant.id.std)
          
          cnt = 1
          
          for (j in tot_plants_df_std$`Peaker Plant`[order(tot_plants_df_std$Mean)]) {
            
            all_plants_df$`plant.id`[all_plants_df$`Peaker Plant`==j] = cnt
            all_plants_df_std$`plant.id`[all_plants_df_std$`Peaker Plant`==j] = cnt
            
            cnt = cnt + 1
            
          }
          
          
          # need to fix new labels before applying
          
          new_labels = unique(as.character(all_plants_df$`Peaker Plant`[order(all_plants_df$plant.id)]))
          new_labels_save = new_labels
          
          
          # new_labels = c("Harbor 10",
          #                "Larkspur 1",
          #                "Center 1",
          #                "Cuyamaca 1",
          #                "Harbor 13",
          #                "Harbor 14",
          #                "Long \n Beach 4",
          #                "Long \n Beach 1",
          #                "Larkspur 2",
          #                "Riverside 4",
          #                "Long \n Beach 3",
          #                "Chula \n Vista 1B",
          #                "Chula \n Vista 1A",
          #                "Long \n Beach 2",
          #                "CalPeak \n Border 1",
          #                "Glenarm 4",
          #                "Wolfskill 1",
          #                "CalPeak \n Enterprise 1",
          #                "Hanford 2"
          # )
          
          drop_idx = 0
          cnt = 1
          
          for ( i in 1:dim(all_plants_df)[1]) {
            
            if (all_plants_df[i,"Cost Type"]=="Emissions" & all_plants_df[i,"Mean"]==0) {
              
              drop_idx[cnt] = i
              cnt = cnt + 1
              
            }
            
          }
          
          all_plants_df = all_plants_df[-drop_idx,]
          
          drop_idx = 0
          cnt = 1
          
          
          for (i in 2:dim(all_plants_df)[1]) {
            
            if (all_plants_df[i,"Cost Type"]=="Emissions") {
              
              all_plants_df$end.bar[i-1] = all_plants_df$end.bar[i]
              drop_idx[cnt] = i
              cnt = cnt + 1
            }
            
          }
          
          all_plants_df = all_plants_df[-drop_idx,]
          
          all_plants_df_npv = all_plants_df
          
          
          #------------------------------------------------------------------------------
          # stacked bars all plants - npv # 
          #------------------------------------------------------------------------------
          
          
          
          ggplot() +
            ggtitle("") +
            geom_hline(yintercept=0) + 
            geom_rect(data = all_plants_df, aes(x = `Peaker Plant`, fill = `NPV Category`,#  pattern = `Cost Type`,
                                                xmin = plant.id - 0.25, xmax = plant.id + 0.25,
                                                ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_point(data = tot_plants_df_std, aes(x = `Peaker Plant`, y = Mean, size = `NPV Category`)) + 
            geom_errorbar(data = tot_plants_df_std, 
                          aes(x = `Peaker Plant`, ymin = Mean - STDev_Down, ymax = Mean + STDev_Up),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_size_discrete(name = " ") + 
            scale_x_discrete(labels = new_labels) + 
            # scale_pattern_manual(values = c(Emissions = "stripe", Monetary = "none")) +
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Cost Category") +
            xlab("Peaker Plant Replaced") +
            ylab("Million 2020 USD") +
            theme(axis.text.y = element_text(size = 17.5), # 12.5
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 17.5), # 9
                  text = element_text(size=17.5),
                  legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) +
            # ylim(-5*10^2, 3.0*10^2) + 
            coord_flip()
          
          ggsave(paste("scenario_figures_09_02_22/all_plants_npv.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 25, units = "cm")
          
          
          
          
          #------------------------------------------------------------------------------
          # cumulative figures cleaning - ghg # 
          #------------------------------------------------------------------------------
          
          plant_list = c("long_beach_1_ghg_waterfall", "long_beach_2_ghg_waterfall", "long_beach_3_ghg_waterfall", "long_beach_4_ghg_waterfall",
                         "harbor_gen_10_ghg_waterfall", "harbor_gen_13_ghg_waterfall", "harbor_gen_14_ghg_waterfall", "glenarm_4_ghg_waterfall",
                         "calpeak_border_1_ghg_waterfall", "cuyamaca_peak_1_ghg_waterfall", "calpeak_enterprise_1_ghg_waterfall", "chula_vista_1a_ghg_waterfall",
                         "chula_vista_1b_ghg_waterfall", "larkspur_1_ghg_waterfall", "larkspur_2_ghg_waterfall", "hanford_2_ghg_waterfall",
                         "wolfskill_1_ghg_waterfall", "riverside_4_ghg_waterfall", "center_1_ghg_waterfall")

          
          all_plants_df = long_beach_1_ghg_waterfall[[11]]
          all_plants_df_std = long_beach_1_ghg_waterfall[[10]]
          
          for (i in 2:length(plant_list)) {
            
            all_plants_df = rbind(all_plants_df, get(plant_list[i])[[11]])
            all_plants_df_std = rbind(all_plants_df_std, get(plant_list[i])[[10]])
            
          }
          
          tot_plants_df_std = all_plants_df_std[all_plants_df_std$`Category`=="Net Emissions",]
          
          # for (i in 1:length(plant_list)) {
          #   
          #   tot_plants_df_std$Mean[i] = get(plant_list[i])[[1]]$Mean[length(get(plant_list[i])[[1]]$Mean)]
          #   
          # }
          
          
          all_plants_df$`Peaker Plant` = factor(all_plants_df$`Peaker Plant`,
                                                levels = unique(as.character(all_plants_df_npv$`Peaker Plant`[order(all_plants_df_npv$plant.id)])))
          
          # all_plants_df$`Peaker Plant` = factor(all_plants_df$`Peaker Plant`,
          #                                       levels = tot_plants_df_std$`Peaker Plant`[order(-tot_plants_df_std$Mean)])
          
          
          plant.id = rep(0,dim(all_plants_df)[1])
          plant.id.std = rep(0,length(dim(all_plants_df_std)[1]))
          
          all_plants_df = cbind(all_plants_df, plant.id)
          all_plants_df_std = cbind(all_plants_df_std, plant.id.std)
          
          cnt = 1
          
          for (j in unique(as.character(all_plants_df_npv$`Peaker Plant`[order(all_plants_df_npv$plant.id)]))) {# tot_plants_df_std$`Peaker Plant`[order(-tot_plants_df_std$Mean)]) {
            
            all_plants_df$`plant.id`[all_plants_df$`Peaker Plant`==j] = cnt
            all_plants_df_std$`plant.id`[all_plants_df_std$`Peaker Plant`==j] = cnt
            
            cnt = cnt + 1
            
          }
          
          # need to fix new labels before applying
          
          new_labels = new_labels_save
          
          # new_labels = c("Larkspur 1",
          #                "Cuyamaca 1",
          #                "Larkspur 2",
          #                "Harbor 10",
          #                "Riverside 4",
          #                "Harbor 14",
          #                "Harbor 13",
          #                "Center 1",
          #                "Long \n Beach 2",
          #                "Long \n Beach 4",
          #                "Wolfskill 1",
          #                "CalPeak \n Border 1",
          #                "Long \n Beach 3",
          #                "Long \n Beach 1",
          #                "CalPeak \n Enterprise 1",
          #                "Glenarm 4",
          #                "Hanford 2",
          #                "Chula \n Vista 1B",
          #                "Chula \n Vista 1A"
          # )
          
          
          #------------------------------------------------------------------------------
          # stacked bars all plants - ghg  # 
          #------------------------------------------------------------------------------
          
          ggplot() +
            ggtitle("") +
            geom_hline(yintercept=0) + 
            geom_rect(data = all_plants_df, aes(x = `Peaker Plant`, fill = `Category`,#  pattern = `Cost Type`,
                                                xmin = plant.id - 0.25, xmax = plant.id + 0.25,
                                                ymin = end.bar, ymax = start.bar),
                      color = "black", alpha = 0.95) + 
            geom_point(data = tot_plants_df_std, aes(x = `Peaker Plant`, y = Mean, size = Category)) + 
            geom_errorbar(data = tot_plants_df_std, 
                          aes(x = `Peaker Plant`, ymin = Mean - 2*STDev, ymax = Mean + 2*STDev),
                          width = 0.25) +
            theme_minimal() +
            scale_fill_manual(values=c("#88CCEE", "#CC6677", "#DDCC77", "#117733")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            scale_size_discrete(name = " ") + 
            scale_x_discrete(labels = new_labels) + 
            # scale_pattern_manual(values = c(Emissions = "stripe", Monetary = "none")) +
            # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
            # scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
            labs(fill = "Emissions Category") +
            xlab("Peaker Plant Replaced") +
            ylab(bquote("kt CO"["2eq"])) +
            theme(axis.text.y = element_text(size = 17.5),
                  plot.title = element_text(size = 22.5),
                  axis.title = element_text(size = 20),
                  axis.text.x = element_text(size = 17.5),
                  text = element_text(size=17.5),
                  legend.position = "none",
                  legend.title = element_text(size = 20),
                  legend.text = element_text(size = 15)) + 
            guides(fill = guide_legend(order = 1),          
                   size = guide_legend(order = 2)) +
            coord_flip()
          
          
          ggsave(paste("scenario_figures_09_02_22/all_plants_ghg.png", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".png", sep = "_"), width = 20, height = 25, units = "cm")
  
          
          
          
          # save.image(file='myEnvironment.RData')
          save.image(paste("scenario_figures_09_02_22/environment", chem_var, substr(irr_var, 4,4), Lifetime_var, substr(Lifespan_var,1,1), substr(scc_var,3,5),".RData", sep = "_"))
          
        }
        
      }
      
    }
    
  
  
}


































#------------------------------------------------------------------------------
# Chula Vista 1 # Min electricity offset
#------------------------------------------------------------------------------

chula_vista_1 = function_monte_carlo_plot("Average",
                                         "National",
                                         39,
                                         4,
                                         2020,
                                         7.5,
                                         "LFP Graphite SS", # "LFP Graphite SS",
                                         2001,
                                         22,
                                         0.95,
                                         10,
                                         "Yes",
                                         18,
                                         "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                         "electricity.NG.kWh", # "electricity.NG.kWh"
                                         "r410a.kg", # "r410a.kg", "r32.kg"
                                         "Chula Vista Energy Center - Unit 1A") 



chula_vista_1_cost = chula_vista_1[[1]]

chula_vista_1_ghg_standard = function_LCA_plot_standard(chula_vista_1[[3]], chula_vista_1[[11]])
chula_vista_1_co_standard = function_LCA_plot_standard(chula_vista_1[[4]], chula_vista_1[[11]])
chula_vista_1_nox_standard = function_LCA_plot_standard(chula_vista_1[[5]], chula_vista_1[[11]])
chula_vista_1_sox_standard = function_LCA_plot_standard(chula_vista_1[[6]], chula_vista_1[[11]])
chula_vista_1_pm25_standard = function_LCA_plot_standard(chula_vista_1[[7]], chula_vista_1[[11]])
chula_vista_1_voc_standard = function_LCA_plot_standard(chula_vista_1[[8]], chula_vista_1[[11]])

chula_vista_1_ghg_waterfall = function_LCA_plot_waterfall(chula_vista_1[[3]], chula_vista_1[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP")
chula_vista_1_co_waterfall = function_LCA_plot_waterfall(chula_vista_1[[4]], chula_vista_1[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP")
chula_vista_1_nox_waterfall = function_LCA_plot_waterfall(chula_vista_1[[5]], chula_vista_1[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP")
chula_vista_1_sox_waterfall = function_LCA_plot_waterfall(chula_vista_1[[6]], chula_vista_1[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP")
chula_vista_1_pm25_waterfall = function_LCA_plot_waterfall(chula_vista_1[[7]], chula_vista_1[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP")
chula_vista_1_voc_waterfall = function_LCA_plot_waterfall(chula_vista_1[[8]], chula_vista_1[[11]], 0, "Chula Vista Energy Center - Unit 1A", "GWP")

chula_vista_1_ghg_percent = function_LCA_plot_percent(chula_vista_1[[3]], chula_vista_1[[11]])
chula_vista_1_co_percent = function_LCA_plot_percent(chula_vista_1[[4]], chula_vista_1[[11]])
chula_vista_1_nox_percent = function_LCA_plot_percent(chula_vista_1[[5]], chula_vista_1[[11]])
chula_vista_1_sox_percent = function_LCA_plot_percent(chula_vista_1[[6]], chula_vista_1[[11]])
chula_vista_1_pm25_percent = function_LCA_plot_percent(chula_vista_1[[7]], chula_vista_1[[11]])
chula_vista_1_voc_percent = function_LCA_plot_percent(chula_vista_1[[8]], chula_vista_1[[11]])

chula_vista_1_npv = function_npv_plot_waterfall(chula_vista_1[[10]], chula_vista_1[[12]],
                                               batt_damages_raw, discount_series,
                                               "Chula Vista Energy Center - Unit 1A",
                                               plant_profits, elec_prices,
                                               "RTE85", "LFP")

### cost plotting ###

ggplot(chula_vista_1_cost, aes(x = Component, y = Mean, fill = Component)) +
  geom_bar(stat="identity", width = 0.5) +
  geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
  annotate("text", x = graph_order,
           y = chula_vista_1_cost$YPos_Ind + 2* chula_vista_1_cost$STDev + 14, label = paste(chula_vista_1_cost$Mean, '+/-', 2* chula_vista_1_cost$STDev), size = 5.5) +
  theme_minimal() +
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
  ylab("2020-USD per kWh") +
  xlab("") + # xlab("Cost Category") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600

ggplot(chula_vista_1_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
  geom_bar(stat="identity", width = 0.25) +
  geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
  geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
  annotate("text", x = chula_vista_1_cost$`Duration Hr`[1], 
           y = sum(chula_vista_1_cost$YPos_Ind) + 2*sum(chula_vista_1_cost$STDev^2)^0.5 + 15, label = paste(sum(chula_vista_1_cost$Mean), '+/-', round(2*sum(chula_vista_1_cost$STDev^2)^0.5,2))) +
  theme_minimal() +
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  labs(title = "BESS 200 MWh / 50 MW") +
  ylab("Cost 2020 USD / kWh")+
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600


### ghg plotting ###



### NPV plot


ggplot() +
  ggtitle("Chula Vista Energy Center - Unit 1A - Li-ion BESS Net Present Value") +
  geom_hline(yintercept=0) + 
  geom_rect(data = chula_vista_1_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                              xmin = group.id - 0.25, xmax = group.id + 0.25,
                                              ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = chula_vista_1_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                          last(group.id),
                                                          group.id+0.25), 
                                                 xend=ifelse(group.id == last(group.id),
                                                             last(group.id),
                                                             group.id+0.75), 
                                                 y=ifelse(end.id == 1,
                                                          end.bar,
                                                          # these will be removed once we set the y limits
                                                          max(end.bar)*2*99999999999), 
                                                 yend=ifelse(end.id == 1,
                                                             end.bar,
                                                             # these will be removed once we set the y limits
                                                             max(end.bar)*2*99999999999)), 
               colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "black", "black", "white", "black")) +
  geom_errorbar(data = chula_vista_1_npv[[2]], 
                aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Cost Category") +
  xlab("") +
  ylab("Million USD-2020") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        # legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) +
  ylim(-0.75*10^2, 0*10^2)
# ylim(0-1*10^4, 0) # max(long_beach_1_NPV_df$end.bar) + max(2*long_beach_1_NPV_std$STDev))# sum(abs(long_beach_1_NPV_df$Mean)))











#------------------------------------------------------------------------------
# Larkspur 1 # Max electricity offset
#------------------------------------------------------------------------------

larkspur_1 = function_monte_carlo_plot("Average",
                                          "National",
                                          150,
                                          4,
                                          2020,
                                          7.5,
                                          "LFP Graphite SS", # "LFP Graphite SS",
                                          2001,
                                          44,
                                          0.95,
                                          10,
                                          "Yes",
                                          49,
                                          "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                          "electricity.NG.kWh", # "electricity.NG.kWh"
                                          "r410a.kg", # "r410a.kg", "r32.kg"
                                          "Larkspur Energy Facility - Unit 1") 

# 
# test_mcp_NCA = function_monte_carlo_plot("Average",
#                                          "National",
#                                          145,
#                                          4,
#                                          2020,
#                                          7.5,
#                                          "NCA Graphite",
#                                          2001,
#                                          30,
#                                          0.95,
#                                          10,
#                                          "Yes",
#                                          51)
# 
# test_mcp_NMC = function_monte_carlo_plot("Average",
#                                          "National",
#                                          64,
#                                          4,
#                                          2020,
#                                          7.5,
#                                          "NMC Graphite",
#                                          2001,
#                                          181, # 181,
#                                          0.95,
#                                          10,
#                                          "Yes",
#                                          51,
#                                          "electricity.Solar.kWh", # "electricity.Solar.kWh"
#                                          "electricity.NG.kWh", # "electricity.NG.kWh"
#                                          "r32.kg") # "r410a.kg", "r32.kg"


larkspur_1_cost = larkspur_1[[1]]

larkspur_1_ghg_standard = function_LCA_plot_standard(larkspur_1[[3]], larkspur_1[[11]])
larkspur_1_co_standard = function_LCA_plot_standard(larkspur_1[[4]], larkspur_1[[11]])
larkspur_1_nox_standard = function_LCA_plot_standard(larkspur_1[[5]], larkspur_1[[11]])
larkspur_1_sox_standard = function_LCA_plot_standard(larkspur_1[[6]], larkspur_1[[11]])
larkspur_1_pm25_standard = function_LCA_plot_standard(larkspur_1[[7]], larkspur_1[[11]])
larkspur_1_voc_standard = function_LCA_plot_standard(larkspur_1[[8]], larkspur_1[[11]])

larkspur_1_ghg_waterfall = function_LCA_plot_waterfall(larkspur_1[[3]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP")
larkspur_1_co_waterfall = function_LCA_plot_waterfall(larkspur_1[[4]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP")
larkspur_1_nox_waterfall = function_LCA_plot_waterfall(larkspur_1[[5]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP")
larkspur_1_sox_waterfall = function_LCA_plot_waterfall(larkspur_1[[6]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP")
larkspur_1_pm25_waterfall = function_LCA_plot_waterfall(larkspur_1[[7]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP")
larkspur_1_voc_waterfall = function_LCA_plot_waterfall(larkspur_1[[8]], larkspur_1[[11]], 0, "Larkspur Energy Facility - Unit 1", "GWP")

larkspur_1_ghg_percent = function_LCA_plot_percent(larkspur_1[[3]], larkspur_1[[11]])
larkspur_1_co_percent = function_LCA_plot_percent(larkspur_1[[4]], larkspur_1[[11]])
larkspur_1_nox_percent = function_LCA_plot_percent(larkspur_1[[5]], larkspur_1[[11]])
larkspur_1_sox_percent = function_LCA_plot_percent(larkspur_1[[6]], larkspur_1[[11]])
larkspur_1_pm25_percent = function_LCA_plot_percent(larkspur_1[[7]], larkspur_1[[11]])
larkspur_1_voc_percent = function_LCA_plot_percent(larkspur_1[[8]], larkspur_1[[11]])


larkspur_1_npv = function_npv_plot_waterfall(larkspur_1[[10]], larkspur_1[[12]],
                                                batt_damages_raw, discount_series,
                                                "Larkspur Energy Facility - Unit 1",
                                                plant_profits, elec_prices,
                                                "RTE85", "LFP")




### cost plotting ###

ggplot(larkspur_1_cost, aes(x = Component, y = Mean, fill = Component)) +
  geom_bar(stat="identity", width = 0.5) +
  geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
  annotate("text", x = graph_order,
           y = larkspur_1_cost$YPos_Ind + 2* larkspur_1_cost$STDev + 14, label = paste(larkspur_1_cost$Mean, '+/-', 2* larkspur_1_cost$STDev), size = 5.5) +
  theme_minimal() +
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  labs(fill = "Cost Category") + # labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
  ylab("2020-USD per kWh") +
  xlab("") + # xlab("Cost Category") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600

ggplot(larkspur_1_cost, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
  geom_bar(stat="identity", width = 0.25) +
  geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev^2)^0.5, ymax = sum(Mean) + 2*sum(STDev^2)^0.5), width = 0.25) +
  geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
  annotate("text", x = larkspur_1_cost$`Duration Hr`[1], 
           y = sum(larkspur_1_cost$YPos_Ind) + 2*sum(larkspur_1_cost$STDev^2)^0.5 + 15, label = paste(sum(larkspur_1_cost$Mean), '+/-', round(2*sum(larkspur_1_cost$STDev^2)^0.5,2))) +
  theme_minimal() +
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  labs(title = "BESS 200 MWh / 50 MW") +
  ylab("Cost 2020 USD / kWh")+
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600


### ghg plotting ###


### NPV plot


ggplot() +
  ggtitle("Larkspur Energy Facility - Unit 1 - Li-ion BESS Net Present Value") +
  geom_hline(yintercept=0) + 
  geom_rect(data = larkspur_1_npv[[1]], aes(x = `NPV Category`, fill = `Cost Type`,
                                               xmin = group.id - 0.25, xmax = group.id + 0.25,
                                               ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = larkspur_1_npv[[1]], aes(x=ifelse(group.id == last(group.id),
                                                           last(group.id),
                                                           group.id+0.25), 
                                                  xend=ifelse(group.id == last(group.id),
                                                              last(group.id),
                                                              group.id+0.75), 
                                                  y=ifelse(end.id == 1,
                                                           end.bar,
                                                           # these will be removed once we set the y limits
                                                           max(end.bar)*2*99999999999), 
                                                  yend=ifelse(end.id == 1,
                                                              end.bar,
                                                              # these will be removed once we set the y limits
                                                              max(end.bar)*2*99999999999)), 
               colour=c("black", "black", "black", "black", "black","black","black","black","black","black", "black", "black", "black", "black", "black", "white", "black")) +
  geom_errorbar(data = larkspur_1_npv[[2]], 
                aes(x = `NPV Category`, ymin = end.bar - STDev_Down, ymax = end.bar + STDev_Up),
                width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values=c("#88CCEE","#CC6677", "#DDCC77")) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Cost Category") +
  xlab("") +
  ylab("Million USD-2020") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        # legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) +
  ylim(-3*10^2, 0*10^2)
# ylim(0-1*10^4, 0) # max(long_beach_1_NPV_df$end.bar) + max(2*long_beach_1_NPV_std$STDev))# sum(abs(long_beach_1_NPV_df$Mean)))








#------------------------------------------------------------------------------
# grid arrange # standard - many bars
#------------------------------------------------------------------------------


long_beach_1_ghg = ggplot() +
  ggtitle("Long Beach Generating Station \n Unit 1") + # Long Beach Generating Station - Unit 1
  geom_bar(data = long_beach_1_ghg_standard[[7]], aes(x = Category, y = Mean, fill = Component), position = "stack", stat = "identity", width = 0.5) + 
  geom_errorbar(data = long_beach_1_ghg_standard[[8]], aes(x = Category, ymin = Mean - 2*STDev, ymax = Mean + 2*STDev), width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) # 1500 x 600

chula_vista_1_ghg = ggplot() +
  ggtitle("Chula Vista Energy Center \n Unit 1A") + # Chula Vista Energy Center - Unit 1A
  geom_bar(data = chula_vista_1_ghg_standard[[7]], aes(x = Category, y = Mean, fill = Component), position = "stack", stat = "identity", width = 0.5) + 
  geom_errorbar(data = chula_vista_1_ghg_standard[[8]], aes(x = Category, ymin = Mean - 2*STDev, ymax = Mean + 2*STDev), width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") +  # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) + 
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_blank(),
        axis.title.y = element_blank(),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) # 1500 x 600


larkspur_1_ghg = ggplot() +
  ggtitle("Larkspur Energy Facility \n Unit 1") + # Larkspur Energy Facility - Unit 1
  geom_bar(data = larkspur_1_ghg_standard[[7]], aes(x = Category, y = Mean, fill = Component), position = "stack", stat = "identity", width = 0.5) + 
  geom_errorbar(data = larkspur_1_ghg_standard[[8]], aes(x = Category, ymin = Mean - 2*STDev, ymax = Mean + 2*STDev), width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") +  # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) + 
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_blank(),
        axis.title.y = element_blank(),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) # 1500 x 600


# determine ylim

y_height = max(c(max(long_beach_1_ghg_standard[[8]]$Mean) + 
  2* long_beach_1_ghg_standard[[8]]$STDev[long_beach_1_ghg_standard[[8]]$Category==long_beach_1_ghg_standard[[8]]$Category[long_beach_1_ghg_standard[[8]]$Mean==max(long_beach_1_ghg_standard[[8]]$Mean)]],
  max(chula_vista_1_ghg_standard[[8]]$Mean) + 
    2* chula_vista_1_ghg_standard[[8]]$STDev[chula_vista_1_ghg_standard[[8]]$Category==chula_vista_1_ghg_standard[[8]]$Category[chula_vista_1_ghg_standard[[8]]$Mean==max(chula_vista_1_ghg_standard[[8]]$Mean)]],
  max(larkspur_1_ghg_standard[[8]]$Mean) + 
    2* larkspur_1_ghg_standard[[8]]$STDev[larkspur_1_ghg_standard[[8]]$Category==larkspur_1_ghg_standard[[8]]$Category[larkspur_1_ghg_standard[[8]]$Mean==max(larkspur_1_ghg_standard[[8]]$Mean)]]
)) + 1000

long_beach_1_ghg = long_beach_1_ghg +
  scale_y_continuous(breaks = c(2.5*10^8, 5*10^8, 7.5*10^8, 10^9, 1.25*10^9),
                    labels = c("2.5x10^8", "5x10^8", "7.5x10^8", "1x10^9", "1.25x10^9"),
                    limits=c(0, y_height))
chula_vista_1_ghg = chula_vista_1_ghg +
  scale_y_continuous(breaks = c(2.5*10^8, 5*10^8, 7.5*10^8, 10^9, 1.25*10^9),
                     labels = c("2.5x10^8", "5x10^8", "7.5x10^8", "1x10^9", "1.25x10^9"),
                     limits=c(0, y_height))
larkspur_1_ghg = larkspur_1_ghg +
  scale_y_continuous(breaks = c(2.5*10^8, 5*10^8, 7.5*10^8, 10^9, 1.25*10^9),
                     labels = c("2.5x10^8", "5x10^8", "7.5x10^8", "1x10^9", "1.25x10^9"),
                     limits=c(0, y_height))


grid_arrange_shared_legend(long_beach_1_ghg, chula_vista_1_ghg, larkspur_1_ghg,
                           widths=c(1.2,1,1), ncol = 3)

#------------------------------------------------------------------------------
# grid arrange # standard - few bars
#------------------------------------------------------------------------------


long_beach_1_ghg_few = ggplot() +
  ggtitle("Long Beach Generating Station \n Unit 1") + # Long Beach Generating Station - Unit 1
  geom_bar(data = long_beach_1_ghg_standard[[7]], aes(x = Category, y = Mean, fill = Category), position = "stack", stat = "identity", width = 0.5) + 
  geom_errorbar(data = long_beach_1_ghg_standard[[8]], aes(x = Category, ymin = Mean - 2*STDev, ymax = Mean + 2*STDev), width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values = cbpalette4) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) # 1500 x 600

chula_vista_1_ghg_few = ggplot() +
  ggtitle("Chula Vista Energy Center \n Unit 1A") + # Chula Vista Energy Center - Unit 1A
  geom_bar(data = chula_vista_1_ghg_standard[[7]], aes(x = Category, y = Mean, fill = Category), position = "stack", stat = "identity", width = 0.5) + 
  geom_errorbar(data = chula_vista_1_ghg_standard[[8]], aes(x = Category, ymin = Mean - 2*STDev, ymax = Mean + 2*STDev), width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values = cbpalette4) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") +  # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) + 
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_blank(),
        axis.title.y = element_blank(),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) # 1500 x 600


larkspur_1_ghg_few = ggplot() +
  ggtitle("Larkspur Energy Facility \n Unit 1") + # Larkspur Energy Facility - Unit 1
  geom_bar(data = larkspur_1_ghg_standard[[7]], aes(x = Category, y = Mean, fill = Category), position = "stack", stat = "identity", width = 0.5) + 
  geom_errorbar(data = larkspur_1_ghg_standard[[8]], aes(x = Category, ymin = Mean - 2*STDev, ymax = Mean + 2*STDev), width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values = cbpalette4) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") +  # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) + 
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_blank(),
        axis.title.y = element_blank(),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) # 1500 x 600




# determine ylim

y_height = max(c(max(long_beach_1_ghg_standard[[8]]$Mean) + 
                   2* long_beach_1_ghg_standard[[8]]$STDev[long_beach_1_ghg_standard[[8]]$Category==long_beach_1_ghg_standard[[8]]$Category[long_beach_1_ghg_standard[[8]]$Mean==max(long_beach_1_ghg_standard[[8]]$Mean)]],
                 max(chula_vista_1_ghg_standard[[8]]$Mean) + 
                   2* chula_vista_1_ghg_standard[[8]]$STDev[chula_vista_1_ghg_standard[[8]]$Category==chula_vista_1_ghg_standard[[8]]$Category[chula_vista_1_ghg_standard[[8]]$Mean==max(chula_vista_1_ghg_standard[[8]]$Mean)]],
                 max(larkspur_1_ghg_standard[[8]]$Mean) + 
                   2* larkspur_1_ghg_standard[[8]]$STDev[larkspur_1_ghg_standard[[8]]$Category==larkspur_1_ghg_standard[[8]]$Category[larkspur_1_ghg_standard[[8]]$Mean==max(larkspur_1_ghg_standard[[8]]$Mean)]]
)) + 1000

long_beach_1_ghg_few = long_beach_1_ghg_few +
  scale_y_continuous(breaks = c(2.5*10^8, 5*10^8, 7.5*10^8, 10^9, 1.25*10^9),
                     labels = c("2.5x10^8", "5x10^8", "7.5x10^8", "1x10^9", "1.25x10^9"),
                     limits=c(0, y_height))
chula_vista_1_ghg_few = chula_vista_1_ghg_few +
  scale_y_continuous(breaks = c(2.5*10^8, 5*10^8, 7.5*10^8, 10^9, 1.25*10^9),
                     labels = c("2.5x10^8", "5x10^8", "7.5x10^8", "1x10^9", "1.25x10^9"),
                     limits=c(0, y_height))
larkspur_1_ghg_few = larkspur_1_ghg_few +
  scale_y_continuous(breaks = c(2.5*10^8, 5*10^8, 7.5*10^8, 10^9, 1.25*10^9),
                     labels = c("2.5x10^8", "5x10^8", "7.5x10^8", "1x10^9", "1.25x10^9"),
                     limits=c(0, y_height))





grid_arrange_shared_legend(long_beach_1_ghg_few, chula_vista_1_ghg_few, larkspur_1_ghg_few,
                           widths=c(1.2,1,1), ncol = 3)



#------------------------------------------------------------------------------
# grid arrange # waterfalls
#------------------------------------------------------------------------------

long_beach_1_ghg_wf = ggplot() +
  ggtitle("Long Beach Generating Station \n Unit 1") +
  geom_hline(yintercept=0) + 
  geom_rect(data = long_beach_1_ghg_waterfall[[9]], aes(x = Category, fill = Component,
                              xmin = group.id - 0.25, xmax = group.id + 0.25,
                              ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = long_beach_1_ghg_waterfall[[9]], aes(x=ifelse(group.id == last(group.id),
                                          last(group.id),
                                          group.id+0.25), 
                                 xend=ifelse(group.id == last(group.id),
                                             last(group.id),
                                             group.id+0.75), 
                                 y=ifelse(end.id == 1,
                                          end.bar,
                                          # these will be removed once we set the y limits
                                          max(end.bar)*2*99999999999), 
                                 yend=ifelse(end.id == 1,
                                             end.bar,
                                             # these will be removed once we set the y limits
                                             max(end.bar)*2*99999999999)), 
               colour="black") +
  geom_errorbar(data = long_beach_1_ghg_waterfall[[10]], 
                aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15))


chula_vista_1_ghg_wf = ggplot() +
  ggtitle("Chula Vista Energy Center \n Unit 1A") + # Chula Vista Energy Center - Unit 1A
  geom_hline(yintercept=0) + 
  geom_rect(data = chula_vista_1_ghg_waterfall[[9]], aes(x = Category, fill = Component,
                                                        xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                        ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = chula_vista_1_ghg_waterfall[[9]], aes(x=ifelse(group.id == last(group.id),
                                                                    last(group.id),
                                                                    group.id+0.25), 
                                                           xend=ifelse(group.id == last(group.id),
                                                                       last(group.id),
                                                                       group.id+0.75), 
                                                           y=ifelse(end.id == 1,
                                                                    end.bar,
                                                                    # these will be removed once we set the y limits
                                                                    max(end.bar)*2*99999999999), 
                                                           yend=ifelse(end.id == 1,
                                                                       end.bar,
                                                                       # these will be removed once we set the y limits
                                                                       max(end.bar)*2*99999999999)), 
               colour="black") +
  geom_errorbar(data = chula_vista_1_ghg_waterfall[[10]], 
                aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                width = 0.25)  +
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") +  # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) + 
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_blank(),
        axis.title.y = element_blank(),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) 


larkspur_1_ghg_wf = ggplot() +
  ggtitle("Larkspur Energy Facility \n Unit 1") + # Larkspur Energy Facility - Unit 1
  geom_hline(yintercept=0) + 
  geom_rect(data = larkspur_1_ghg_waterfall[[9]], aes(x = Category, fill = Component,
                                                         xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                         ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = larkspur_1_ghg_waterfall[[9]], aes(x=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.25), 
                                                            xend=ifelse(group.id == last(group.id),
                                                                        last(group.id),
                                                                        group.id+0.75), 
                                                            y=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999), 
                                                            yend=ifelse(end.id == 1,
                                                                        end.bar,
                                                                        # these will be removed once we set the y limits
                                                                        max(end.bar)*2*99999999999)), 
               colour="black") +
  geom_errorbar(data = larkspur_1_ghg_waterfall[[10]], 
                aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                width = 0.25)  +
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") +  # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) + 
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_blank(),
        axis.title.y = element_blank(),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) 


# determine ylim

ymax_wf = max(c(max(long_beach_1_ghg_waterfall[[10]]$Pos) + 
                   2* long_beach_1_ghg_waterfall[[10]]$STDev[long_beach_1_ghg_waterfall[[10]]$Category==long_beach_1_ghg_waterfall[[10]]$Category[long_beach_1_ghg_waterfall[[10]]$Pos==max(long_beach_1_ghg_waterfall[[10]]$Pos)]],
                 max(chula_vista_1_ghg_waterfall[[10]]$Pos) + 
                   2* chula_vista_1_ghg_waterfall[[10]]$STDev[chula_vista_1_ghg_waterfall[[10]]$Category==chula_vista_1_ghg_waterfall[[10]]$Category[chula_vista_1_ghg_waterfall[[10]]$Pos==max(chula_vista_1_ghg_waterfall[[10]]$Pos)]],
                 max(larkspur_1_ghg_waterfall[[10]]$Pos) + 
                   2* larkspur_1_ghg_waterfall[[10]]$STDev[larkspur_1_ghg_waterfall[[10]]$Category==larkspur_1_ghg_waterfall[[10]]$Category[larkspur_1_ghg_waterfall[[10]]$Pos==max(larkspur_1_ghg_waterfall[[10]]$Pos)]]
)) + 1000


ymin_wf = min(c(min(long_beach_1_ghg_waterfall[[10]]$Pos) - 
                  2* long_beach_1_ghg_waterfall[[10]]$STDev[long_beach_1_ghg_waterfall[[10]]$Category==long_beach_1_ghg_waterfall[[10]]$Category[long_beach_1_ghg_waterfall[[10]]$Pos==min(long_beach_1_ghg_waterfall[[10]]$Pos)]],
                min(chula_vista_1_ghg_waterfall[[10]]$Pos) - 
                  2* chula_vista_1_ghg_waterfall[[10]]$STDev[chula_vista_1_ghg_waterfall[[10]]$Category==chula_vista_1_ghg_waterfall[[10]]$Category[chula_vista_1_ghg_waterfall[[10]]$Pos==min(chula_vista_1_ghg_waterfall[[10]]$Pos)]],
                min(larkspur_1_ghg_waterfall[[10]]$Pos) - 
                  2* larkspur_1_ghg_waterfall[[10]]$STDev[larkspur_1_ghg_waterfall[[10]]$Category==larkspur_1_ghg_waterfall[[10]]$Category[larkspur_1_ghg_waterfall[[10]]$Pos==min(larkspur_1_ghg_waterfall[[10]]$Pos)]]
)) - 1000


long_beach_1_ghg_wf = long_beach_1_ghg_wf +
  scale_y_continuous(breaks = c(-1*10^9, -5*10^8, 0, 5*10^8),
                     labels = c("-1x10^9", "-5x10^8", "0", "5x10^8"),
                     limits=c(ymin_wf, ymax_wf))
chula_vista_1_ghg_wf = chula_vista_1_ghg_wf +
  scale_y_continuous(breaks = c(-1*10^9, -5*10^8, 0, 5*10^8),
                     labels = c("-1x10^9", "-5x10^8", "0", "5x10^8"),
                     limits=c(ymin_wf, ymax_wf))
larkspur_1_ghg_wf = larkspur_1_ghg_wf +
  scale_y_continuous(breaks = c(-1*10^9, -5*10^8, 0, 5*10^8),
                     labels = c("-1x10^9", "-5x10^8", "0", "5x10^8"),
                     limits=c(ymin_wf, ymax_wf))

grid_arrange_shared_legend(long_beach_1_ghg_wf, chula_vista_1_ghg_wf, larkspur_1_ghg_wf,
                           widths=c(1.2,1,1), ncol = 3)


#------------------------------------------------------------------------------
# grid arrange # waterfalls - few bars
#------------------------------------------------------------------------------

long_beach_1_ghg_wf_few = ggplot() +
  ggtitle("Long Beach Generating Station \n Unit 1") +
  geom_hline(yintercept=0) + 
  geom_rect(data = long_beach_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                        xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                        ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = long_beach_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                    last(group.id),
                                                                    group.id+0.25), 
                                                           xend=ifelse(group.id == last(group.id),
                                                                       last(group.id),
                                                                       group.id+0.75), 
                                                           y=ifelse(end.id == 1,
                                                                    end.bar,
                                                                    # these will be removed once we set the y limits
                                                                    max(end.bar)*2*99999999999), 
                                                           yend=ifelse(end.id == 1,
                                                                       end.bar,
                                                                       # these will be removed once we set the y limits
                                                                       max(end.bar)*2*99999999999)), 
               colour=c("black", "black", "black", "white", "black")) +
  geom_errorbar(data = long_beach_1_ghg_waterfall[[10]], 
                aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                width = 0.25) +
  # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(long_beach_1_ghg_waterfall[[10]]$Mean) - sum(long_beach_1_ghg_waterfall[[10]]$STDev^2)^0.5,
  #                   ymax = sum(long_beach_1_ghg_waterfall[[10]]$Mean) + sum(long_beach_1_ghg_waterfall[[10]]$STDev^2)^0.5),
  #               width=0.6, size=1.25, color="darkred") + 
  # geom_point(aes(x = "Offset Electricity", y = long_beach_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_blank(),
        axis.title.y = element_blank(),
        # axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 22.5),
        axis.text.x = element_text(size = 14),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15))


ggplot() +
  ggtitle("Long Beach Generating Station Unit 1 - Li-ion BESS Life-cycle Global Warming Potential") +
  geom_hline(yintercept=0) + 
  geom_rect(data = long_beach_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                         xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                         ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = long_beach_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.25), 
                                                            xend=ifelse(group.id == last(group.id),
                                                                        last(group.id),
                                                                        group.id+0.75), 
                                                            y=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999), 
                                                            yend=ifelse(end.id == 1,
                                                                        end.bar,
                                                                        # these will be removed once we set the y limits
                                                                        max(end.bar)*2*99999999999)), 
               colour=c("black", "black", "black", "white", "black")) +
  geom_errorbar(data = long_beach_1_ghg_waterfall[[10]], 
                aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                width = 0.25) +
  # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(long_beach_1_ghg_waterfall[[10]]$Mean) - sum(long_beach_1_ghg_waterfall[[10]]$STDev^2)^0.5,
  #                   ymax = sum(long_beach_1_ghg_waterfall[[10]]$Mean) + sum(long_beach_1_ghg_waterfall[[10]]$STDev^2)^0.5),
  #               width=0.6, size=1.25, color="darkred") + 
  # geom_point(aes(x = "Offset Electricity", y = long_beach_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) +
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kt CO2eq") +
  theme(# axis.text.y = element_blank(),
        # axis.title.y = element_blank(),
        # axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 22.5),
        axis.text.x = element_text(size = 14),
        text = element_text(size=17.5),
        # legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15))



chula_vista_1_ghg_wf_few = ggplot() +
  ggtitle("Chula Vista Energy Center \n Unit 1A") + # Chula Vista Energy Center - Unit 1A
  geom_hline(yintercept=0) + 
  geom_rect(data = chula_vista_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                         xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                         ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = chula_vista_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.25), 
                                                            xend=ifelse(group.id == last(group.id),
                                                                        last(group.id),
                                                                        group.id+0.75), 
                                                            y=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999), 
                                                            yend=ifelse(end.id == 1,
                                                                        end.bar,
                                                                        # these will be removed once we set the y limits
                                                                        max(end.bar)*2*99999999999)), 
               colour=c("black", "black", "black", "white", "black")) +
  geom_errorbar(data = chula_vista_1_ghg_waterfall[[10]], 
                aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                width = 0.25)  +
  # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(chula_vista_1_ghg_waterfall[[10]]$Mean) - sum(chula_vista_1_ghg_waterfall[[10]]$STDev^2)^0.5,
  #                   ymax = sum(chula_vista_1_ghg_waterfall[[10]]$Mean) + sum(chula_vista_1_ghg_waterfall[[10]]$STDev^2)^0.5),
  #               width=0.6, size=1.25, color="darkred") + 
  # geom_point(aes(x = "Offset Electricity", y = chula_vista_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") +  # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) + 
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab(expression(kt~CO[2]~eq)) + #  # "kg CO2eq" expression(Anthropogenic~SO[4]^{"2-"}~(ngm^-3))
  theme(# axis.text.y = element_blank(),
        # axis.title.y = element_blank(),
        axis.text.y = element_text(size = 14),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 22.5),
        axis.text.x = element_text(size = 14),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) 


larkspur_1_ghg_wf_few = ggplot() +
  ggtitle("Larkspur Energy Facility \n Unit 1") + # Larkspur Energy Facility - Unit 1
  geom_hline(yintercept=0) + 
  geom_rect(data = larkspur_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                      xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                      ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = larkspur_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                  last(group.id),
                                                                  group.id+0.25), 
                                                         xend=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.75), 
                                                         y=ifelse(end.id == 1,
                                                                  end.bar,
                                                                  # these will be removed once we set the y limits
                                                                  max(end.bar)*2*99999999999), 
                                                         yend=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999)), 
               colour=c("black", "black", "black", "white", "black")) +
  geom_errorbar(data = larkspur_1_ghg_waterfall[[10]], 
                aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                width = 0.25)  +
  # geom_errorbar(aes(x = "Offset Electricity", ymin = sum(larkspur_1_ghg_waterfall[[10]]$Mean) - sum(larkspur_1_ghg_waterfall[[10]]$STDev^2)^0.5,
  #                   ymax = sum(larkspur_1_ghg_waterfall[[10]]$Mean) + sum(larkspur_1_ghg_waterfall[[10]]$STDev^2)^0.5),
  #               width=0.6, size=1.25, color="darkred") + 
  # geom_point(aes(x = "Offset Electricity", y = larkspur_1_ghg_waterfall[[10]][4,"end.bar"]), shape=23, stroke=1.25, fill="black", color="darkred", size=3) + 
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") +  # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 10)) + 
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_blank(),
        axis.title.y = element_blank(),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 22.5),
        axis.text.x = element_text(size = 14),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) 


# determine ylim

ymax_wf = max(c(max(long_beach_1_ghg_waterfall[[10]]$Pos) + 
                  2* long_beach_1_ghg_waterfall[[10]]$STDev[long_beach_1_ghg_waterfall[[10]]$Category==long_beach_1_ghg_waterfall[[10]]$Category[long_beach_1_ghg_waterfall[[10]]$Pos==max(long_beach_1_ghg_waterfall[[10]]$Pos)]],
                max(chula_vista_1_ghg_waterfall[[10]]$Pos) + 
                  2* chula_vista_1_ghg_waterfall[[10]]$STDev[chula_vista_1_ghg_waterfall[[10]]$Category==chula_vista_1_ghg_waterfall[[10]]$Category[chula_vista_1_ghg_waterfall[[10]]$Pos==max(chula_vista_1_ghg_waterfall[[10]]$Pos)]],
                max(larkspur_1_ghg_waterfall[[10]]$Pos) + 
                  2* larkspur_1_ghg_waterfall[[10]]$STDev[larkspur_1_ghg_waterfall[[10]]$Category==larkspur_1_ghg_waterfall[[10]]$Category[larkspur_1_ghg_waterfall[[10]]$Pos==max(larkspur_1_ghg_waterfall[[10]]$Pos)]]
)) # + 1000


ymin_wf = min(c(min(long_beach_1_ghg_waterfall[[10]]$Pos) - 
                  2* long_beach_1_ghg_waterfall[[10]]$STDev[long_beach_1_ghg_waterfall[[10]]$Category==long_beach_1_ghg_waterfall[[10]]$Category[long_beach_1_ghg_waterfall[[10]]$Pos==min(long_beach_1_ghg_waterfall[[10]]$Pos)][2]],
                min(chula_vista_1_ghg_waterfall[[10]]$Pos) - 
                  2* chula_vista_1_ghg_waterfall[[10]]$STDev[chula_vista_1_ghg_waterfall[[10]]$Category==chula_vista_1_ghg_waterfall[[10]]$Category[chula_vista_1_ghg_waterfall[[10]]$Pos==min(chula_vista_1_ghg_waterfall[[10]]$Pos)][2]],
                min(larkspur_1_ghg_waterfall[[10]]$Pos) - 
                  2* larkspur_1_ghg_waterfall[[10]]$STDev[larkspur_1_ghg_waterfall[[10]]$Category==larkspur_1_ghg_waterfall[[10]]$Category[larkspur_1_ghg_waterfall[[10]]$Pos==min(larkspur_1_ghg_waterfall[[10]]$Pos)][2]]
)) # - max(sum(long_beach_1_ghg_waterfall[[10]]$STDev^2)^0.5,
     #     sum(chula_vista_1_ghg_waterfall[[10]]$STDev^2)^0.5,
       #   sum(larkspur_1_ghg_waterfall[[10]]$STDev^2)^0.5) -1000


long_beach_1_ghg_wf_few = long_beach_1_ghg_wf_few +
  scale_y_continuous(breaks = c(100, 200, 300, 400),
                     labels = c("100", "200", "300", "400"),
                     limits=c(ymin_wf, round(ymax_wf,-2)))
chula_vista_1_ghg_wf_few = chula_vista_1_ghg_wf_few +
  scale_y_continuous(breaks = c(100, 200, 300, 400),
                     labels = c("100", "200", "300", "400"),
                     limits=c(ymin_wf, round(ymax_wf,-2)))
larkspur_1_ghg_wf_few = larkspur_1_ghg_wf_few +
  scale_y_continuous(breaks = c(100, 200, 300, 400),
                     labels = c("100", "200", "300", "400"),
                     limits=c(ymin_wf, round(ymax_wf,-2))) 

grid_arrange_shared_legend(chula_vista_1_ghg_wf_few, long_beach_1_ghg_wf_few, larkspur_1_ghg_wf_few,
                           widths=c(1.2,1,1), ncol = 3)

long_beach_1_ghg_wf_few 

#------------------------------------------------------------------------------
# percent_bar_charts
#------------------------------------------------------------------------------


long_beach_1_ghg_percent_plot = ggplot() +
  ggtitle("Long Beach Generating Station \n Unit 1") + # Long Beach Generating Station - Unit 1
  geom_bar(data = long_beach_1_ghg_percent[[4]], aes(x = Category, y = Mean, fill = Component), position = "stack", stat = "identity", width = 0.5) + 
  theme_minimal() +
  # scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 20),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.position = "bottom",
        legend.title = element_text(size = 20),
        legend.text = element_text(size = 15)) # +
# coord_flip() # 1500 x 600


long_beach_1_ghg_percent_plot_g1 = ggplot() +
  ggtitle("Long Beach Generating Station Unit 1 - Li-ion BESS Life-cycle Global Warming Potential Breakdown") +
  geom_hline(yintercept=0) + 
  geom_rect(data = long_beach_1_ghg_percent[[5]][long_beach_1_ghg_percent[[4]]$Category=="Module Materials & Assembly",], aes(x = Category, fill = Component,
                                                      xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                      ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  theme_minimal() +
  scale_fill_manual(values = hex_codes3) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Module Materials & Assembly Emissions") +
  xlab("") +
  ylab("Percent of Total Greenhouse Gas Emissions") +
  theme(axis.text.y = element_text(size = 15),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 22.5),
        axis.text.x = element_text(size = 15),
        text = element_text(size=17.5),
        # legend.position = "bottom",
        legend.title = element_text(size = 15),
        legend.text = element_text(size = 12)) +
  scale_y_continuous(breaks = c(0, 0.25,0.5, 0.75, 1),
                     labels = c("0%", "25%", "50%", "75%", "100%")) +
  coord_flip()



long_beach_1_ghg_percent_plot_g2 = ggplot() +
  ggtitle("Long Beach Generating Station Unit 1 - Li-ion BESS Life-cycle Global Warming Potential Breakdown") +
  geom_hline(yintercept=0) + 
  geom_rect(data = long_beach_1_ghg_percent[[5]][long_beach_1_ghg_percent[[4]]$Category=="Energy Storage BOS",], aes(x = Category, fill = Component,
                                                                                                                              xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                                                                              ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  theme_minimal() +
  scale_fill_manual(values = hex_codes2) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Energy Storage BOS Emissions") +
  xlab("") +
  ylab("Percent of Total Emissions") +
  theme(axis.text.y = element_text(size = 15),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 22.5),
        axis.text.x = element_text(size = 15),
        text = element_text(size=17.5),
        # legend.position = "bottom",
        legend.title = element_text(size = 15),
        legend.text = element_text(size = 12)) +
  scale_y_continuous(breaks = c(0, 0.25,0.5, 0.75, 1),
                     labels = c("0%", "25%", "50%", "75%", "100%")) +
  coord_flip()


long_beach_1_ghg_percent_plot_g3 = ggplot() +
  ggtitle("Long Beach Generating Station Unit 1 - Li-ion BESS Life-cycle Global Warming Potential Breakdown") +
  geom_hline(yintercept=0) + 
  geom_rect(data = long_beach_1_ghg_percent[[5]][long_beach_1_ghg_percent[[4]]$Category=="Battery Charging & Losses",], aes(x = Category, fill = Component,
                                                                                                                     xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                                                                                     ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  theme_minimal() +
  scale_fill_manual(values = hex_codes1) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Battery Charging & Losses") +
  xlab("") +
  ylab("Percent of Total Greenhouse Gas Emissions") +
  theme(axis.text.y = element_text(size = 15),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 22.5),
        axis.text.x = element_text(size = 15),
        text = element_text(size=17.5),
        # legend.position = "bottom",
        legend.title = element_text(size = 15),
        legend.text = element_text(size = 12)) +
  scale_y_continuous(breaks = c(0, 0.25,0.5, 0.75, 1),
                     labels = c("0%", "25%", "50%", "75%", "100%")) +
  coord_flip()
# coord_flip() # 1500 x 600

legend_mod = get_legend(long_beach_1_ghg_percent_plot_g1)
legend_bos = get_legend(long_beach_1_ghg_percent_plot_g2)
legend_charge = get_legend(long_beach_1_ghg_percent_plot_g3)


long_beach_1_ghg_percent_plot_flip = ggplot() +
  ggtitle("Long Beach Generating Station Unit 1 - Li-ion BESS Life-cycle GWP") +
  geom_hline(yintercept=0) + 
  geom_rect(data = long_beach_1_ghg_percent[[5]], aes(x = Category, fill = Component,
                                                        xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                        ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  theme_minimal() +
  scale_fill_manual(values = hex_codes) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("Percent of Total Greenhouse Gas Emissions") +
  theme(axis.text.y = element_text(size = 15),
        plot.title = element_text(size = 22.5),
        axis.title = element_text(size = 22.5),
        axis.text.x = element_text(size = 15),
        text = element_text(size=17.5),
        legend.position = "none",
        legend.title = element_text(size = 15),
        legend.text = element_text(size = 12)) +
  scale_y_continuous(breaks = c(0, 0.25,0.5, 0.75, 1),
                     labels = c("0%", "25%", "50%", "75%", "100%")) +
  coord_flip()



legends_vert = plot_grid(legend_charge, legend_bos, legend_mod, ncol=1, align="v")

grid.arrange(long_beach_1_ghg_percent_plot_flip, legends_vert, nrow = 1, widths = c(1,0.4))

ggsave("scenario_figures_09_02_22/gwp_percent.png", width = 40, height = 20, units = "cm")





#------------------------------------------------------------------------------
# old stuff / working #
#------------------------------------------------------------------------------



long_beach_1_ghg_wf_few = ggplot() +
  ggtitle("Long Beach Generating Station Unit 1") +
  geom_hline(yintercept=0) + 
  geom_rect(data = long_beach_1_ghg_waterfall[[10]], aes(x = Category, fill = Category,
                                                         xmin = group.id - 0.25, xmax = group.id + 0.25,
                                                         ymin = end.bar, ymax = start.bar),
            color = "black", alpha = 0.95) + 
  geom_segment(data = long_beach_1_ghg_waterfall[[10]], aes(x=ifelse(group.id == last(group.id),
                                                                     last(group.id),
                                                                     group.id+0.25), 
                                                            xend=ifelse(group.id == last(group.id),
                                                                        last(group.id),
                                                                        group.id+0.75), 
                                                            y=ifelse(end.id == 1,
                                                                     end.bar,
                                                                     # these will be removed once we set the y limits
                                                                     max(end.bar)*2*99999999999), 
                                                            yend=ifelse(end.id == 1,
                                                                        end.bar,
                                                                        # these will be removed once we set the y limits
                                                                        max(end.bar)*2*99999999999)), 
               colour="black") +
  geom_errorbar(data = long_beach_1_ghg_waterfall[[10]], 
                aes(x = Category, ymin = Pos - 2*STDev, ymax = Pos + 2*STDev),
                width = 0.25) +
  theme_minimal() +
  scale_fill_manual(values = cbpalette5) + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  # scale_fill_brewer(palette = "Set3") + # CREATE COLORLIND PALETTE FOR 10 ITEMS
  scale_x_discrete(labels = function(x) str_wrap(x, width = 12.5)) +
  labs(fill = "Emissions Category") +
  xlab("") +
  ylab("kg CO2eq") +
  theme(axis.text.y = element_text(size = 20),
        plot.title = element_text(size = 27.5),
        axis.title = element_text(size = 27.5),
        axis.text.x = element_text(size = 20),
        text = element_text(size=17.5),
        # legend.position = "none",
        legend.title = element_text(size = 25),
        legend.text = element_text(size = 22.5)) +
  scale_y_continuous(breaks = c(-2*10^8, -1*10^8, 0, 1*10^8, 2*10^8),
                     labels = c("-2x10^8", "-1x10^8", "0", "1x10^8", "2x10^8"))


















# emissions by category










ggplot(test_mcp_LFP_ghg[[1]], aes(x = Category, y = Mean, fill = Category)) +
  geom_bar(stat="identity", width = 0.5) +
  geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
  # annotate("text", x = test_mcp_LFP_ghg[[1]]$Category,
  #          y = test_mcp_LFP_ghg[[1]]$Mean + 2*test_mcp_LFP_ghg[[1]]$STDev + max(abs(test_mcp_LFP_ghg[[1]]$STDev)/1.5),
  #          label = paste(scientific(test_mcp_LFP_ghg[[1]]$Mean, digits = 2), "+/-", scientific(2*test_mcp_LFP_ghg[[1]]$STDev, digits = 2)), size = 5.5) + 
  theme_minimal() +
  scale_fill_brewer(palette = "Spectral") + # CREATE COLORLIND PALETTE FOR 3 ITEMS
  labs(title = "Life-cycle GHG Emissions of Utility-Scale Li-ion BESS") +
  ylab("2020-USD per kWh") +
  xlab("Primary Component") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600

# emissions for cat 1

ggplot(test_mcp_LFP_ghg[[2]], aes(x = Component, y = Mean, fill = Component)) +
  geom_bar(stat="identity", width = 0.5) +
  geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
  annotate("text", x = test_mcp_LFP_ghg[[2]]$Component,
           y = test_mcp_LFP_ghg[[2]]$Mean + 2*test_mcp_LFP_ghg[[2]]$STDev + max(test_mcp_LFP_ghg[[2]]$STDev/5),
           label = paste(scientific(test_mcp_LFP_ghg[[2]]$Mean, digits = 2), "+/-", scientific(2*test_mcp_LFP_ghg[[2]]$STDev, digits = 2)), size = 5.5) + 
  theme_minimal() +
  scale_fill_brewer(palette = "Spectral") + # CREATE COLORLIND PALETTE FOR 3 ITEMS
  labs(title = "Life-cycle GHG Emissions of Utility-Scale Li-ion BESS") +
  ylab("2020-USD per kWh") +
  xlab("Primary Component") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600

# emissions for cat 2

ggplot(test_mcp_LFP_ghg[[3]], aes(x = Component, y = Mean, fill = Component)) +
  geom_bar(stat="identity", width = 0.5) +
  geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
  annotate("text", x = test_mcp_LFP_ghg[[3]]$Component,
           y = test_mcp_LFP_ghg[[3]]$Mean + 2*test_mcp_LFP_ghg[[3]]$STDev + max(test_mcp_LFP_ghg[[3]]$STDev/5),
           label = paste(scientific(test_mcp_LFP_ghg[[3]]$Mean, digits = 2), "+/-", scientific(2*test_mcp_LFP_ghg[[3]]$STDev, digits = 2)), size = 5.5) + 
  theme_minimal() +
  scale_fill_brewer(palette = "Spectral") + # CREATE COLORLIND PALETTE FOR 3 ITEMS
  labs(title = "Life-cycle GHG Emissions of Utility-Scale Li-ion BESS") +
  ylab("2020-USD per kWh") +
  xlab("Primary Component") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600

# emissions for cat 3

ggplot(test_mcp_LFP_ghg[[4]], aes(x = Component, y = Mean, fill = Component)) +
  geom_bar(stat="identity", width = 0.5) +
  geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
  annotate("text", x = test_mcp_LFP_ghg[[4]]$Component,
           y = test_mcp_LFP_ghg[[4]]$Mean + 2*test_mcp_LFP_ghg[[4]]$STDev + max(test_mcp_LFP_ghg[[4]]$STDev/5),
           label = paste(scientific(test_mcp_LFP_ghg[[4]]$Mean, digits = 2), "+/-", scientific(2*test_mcp_LFP_ghg[[4]]$STDev, digits = 2)), size = 5.5) + 
  theme_minimal() +
  scale_fill_brewer(palette = "Spectral") + # CREATE COLORLIND PALETTE FOR 3 ITEMS
  labs(title = "Life-cycle GHG Emissions of Utility-Scale Li-ion BESS") +
  ylab("2020-USD per kWh") +
  xlab("Primary Component") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600




### pollutant plotting ###

# emissions by category

ggplot(test_mcp_LFP_sox[[1]], aes(x = Category, y = Mean, fill = Category)) +
  geom_bar(stat="identity", width = 0.5) +
  geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
  annotate("text", x = test_mcp_LFP_sox[[1]]$Category,
           y = test_mcp_LFP_sox[[1]]$Mean + 2*test_mcp_LFP_sox[[1]]$STDev + max(abs(test_mcp_LFP_sox[[1]]$STDev)/4),
           label = paste(scientific(test_mcp_LFP_sox[[1]]$Mean, digits = 2), "+/-", scientific(2*test_mcp_LFP_sox[[1]]$STDev, digits = 2)), size = 5.5) + 
  theme_minimal() +
  scale_fill_brewer(palette = "Spectral") + # CREATE COLORLIND PALETTE FOR 3 ITEMS
  labs(title = "Life-cycle SOx Emissions of Utility-Scale Li-ion BESS") +
  ylab("2020-USD per kWh") +
  xlab("Primary Component") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600







# City = "Average"
# State = "National"
# Power_MW = 50
# Duration = 4
# Year = 2020
# Lifespan = 7.5
# Chem = "LFP Graphite"
# Fire = 2001
# Cycle_per_year = 250
# DoD = 0.8
# n = 1
# Deg_opt = "Yes"

##############################################################################
# NMC Graphite, Dur 4 # (default as long beach 1)
##############################################################################

runs = 1000

standard_NMC_Graphite_0_Cycles = function_monte_carlo_plot("Average",
                                                           "National",
                                                           114,
                                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                           2020,
                                                           7.5, # [15, 20],
                                                           "NMC Graphite",
                                                           2001,
                                                           1,
                                                           0.95,
                                                           runs,
                                                           "Yes",
                                                           65,
                                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                                           "r410a.kg",
                                                           "Long Beach Generating Station - Unit 1")
standard_NMC_Graphite_0_Cycles_LCA_input = standard_NMC_Graphite_0_Cycles[[2]]
standard_NMC_Graphite_0_Cycles_LCA_matrix = standard_NMC_Graphite_0_Cycles[[3]]
standard_NMC_Graphite_0_Cycles = standard_NMC_Graphite_0_Cycles[[1]]

# write.xlsx(standard_NMC_Graphite_0_Cycles_LCA_matrix, "test_LCA_matrix.xlsx", overwrite = TRUE)
# write.xlsx(standard_NMC_Graphite_0_Cycles_LCA_input, "test_LCA_input.xlsx", overwrite = TRUE)

standard_NMC_Graphite_1000_Cycles = function_monte_carlo_plot("Average",
                                                              "National",
                                                              114,
                                                              4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                              2020,
                                                              7.5, # [15, 20],
                                                              "NMC Graphite",
                                                              2001,
                                                              501,
                                                              0.95,
                                                              runs,
                                                              "Yes",
                                                              65,
                                                              "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                              "electricity.NG.kWh", # "electricity.NG.kWh"
                                                              "r410a.kg",
                                                              "Long Beach Generating Station - Unit 1")
standard_NMC_Graphite_1000_Cycles_LCA_input = standard_NMC_Graphite_1000_Cycles[[2]]
standard_NMC_Graphite_1000_Cycles_LCA_matrix = standard_NMC_Graphite_1000_Cycles[[3]]
standard_NMC_Graphite_1000_Cycles = standard_NMC_Graphite_1000_Cycles[[1]]

standard_NMC_Graphite_Var_Cycles = data.frame(`Mean` = numeric(), 
                                              `STDev` = numeric(),
                                              `5th P` = numeric(),
                                              `95th P` = numeric(),
                                              `Component` = factor(), 
                                              `temp` = numeric(), 
                                              `YPos_Cum` = numeric(), 
                                              `YPos_Ind` = numeric(),
                                              `City` = factor(),
                                              `State` = factor(),
                                              `Capacity MWh` = numeric(),
                                              `Power MW` = numeric(),
                                              `Duration Hr` = numeric(),
                                              `Year` = numeric(),
                                              `Lifespan Yr` = numeric(),
                                              `Chemistry` = factor(),
                                              `Fire Suppression` = numeric(),
                                              `Cycles per Year` = numeric(),
                                              `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           114,
                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NMC Graphite",
                                           2001,
                                           k,
                                           0.95,
                                           runs,
                                           "Yes",
                                           65,
                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                           "r410a.kg",
                                           "Long Beach Generating Station - Unit 1")
  temp_results = temp_results[[1]]
  
  standard_NMC_Graphite_Var_Cycles = rbind(standard_NMC_Graphite_Var_Cycles, temp_results)
  
}

standard_NMC_Graphite_cost_per_cycles = function_var_cycles_sum(standard_NMC_Graphite_Var_Cycles)


##############################################################################
# NCA Graphite #
##############################################################################

standard_NCA_Graphite_0_Cycles = function_monte_carlo_plot("Average",
                                                           "National",
                                                           114,
                                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                           2020,
                                                           7.5, # [15, 20],
                                                           "NCA Graphite",
                                                           2001,
                                                           1,
                                                           0.95,
                                                           runs,
                                                           "Yes",
                                                           65,
                                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                                           "r410a.kg",
                                                           "Long Beach Generating Station - Unit 1")
standard_NCA_Graphite_0_Cycles = standard_NCA_Graphite_0_Cycles[[1]]

standard_NCA_Graphite_1000_Cycles = function_monte_carlo_plot("Average",
                                                              "National",
                                                              114,
                                                              4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                              2020,
                                                              7.5, # [15, 20],
                                                              "NCA Graphite",
                                                              2001,
                                                              501,
                                                              0.95,
                                                              runs,
                                                              "Yes",
                                                              65,
                                                              "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                              "electricity.NG.kWh", # "electricity.NG.kWh"
                                                              "r410a.kg",
                                                              "Long Beach Generating Station - Unit 1")
standard_NCA_Graphite_1000_Cycles = standard_NCA_Graphite_1000_Cycles[[1]]





standard_NMC_Graphite_Var_Cycles = data.frame(`Mean` = numeric(), 
                                              `STDev` = numeric(),
                                              `5th P` = numeric(),
                                              `95th P` = numeric(),
                                              `Component` = factor(), 
                                              `temp` = numeric(), 
                                              `YPos_Cum` = numeric(), 
                                              `YPos_Ind` = numeric(),
                                              `City` = factor(),
                                              `State` = factor(),
                                              `Capacity MWh` = numeric(),
                                              `Power MW` = numeric(),
                                              `Duration Hr` = numeric(),
                                              `Year` = numeric(),
                                              `Lifespan Yr` = numeric(),
                                              `Chemistry` = factor(),
                                              `Fire Suppression` = numeric(),
                                              `Cycles per Year` = numeric(),
                                              `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           114,
                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NMC Graphite",
                                           2001,
                                           k,
                                           0.95,
                                           runs,
                                           "Yes",
                                           65,
                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                           "r410a.kg",
                                           "Long Beach Generating Station - Unit 1")
  temp_results = temp_results[[1]]
  
  standard_NMC_Graphite_Var_Cycles = rbind(standard_NMC_Graphite_Var_Cycles, temp_results)
  
}

standard_NMC_Graphite_cost_per_cycles = function_var_cycles_sum(standard_NMC_Graphite_Var_Cycles)





standard_NCA_Graphite_Var_Cycles = data.frame(`Mean` = numeric(), 
                                              `STDev` = numeric(),
                                              `5th P` = numeric(),
                                              `95th P` = numeric(), 
                                              `Component` = factor(), 
                                              `temp` = numeric(), 
                                              `YPos_Cum` = numeric(), 
                                              `YPos_Ind` = numeric(),
                                              `City` = factor(),
                                              `State` = factor(),
                                              `Capacity MWh` = numeric(),
                                              `Power MW` = numeric(),
                                              `Duration Hr` = numeric(),
                                              `Year` = numeric(),
                                              `Lifespan Yr` = numeric(),
                                              `Chemistry` = factor(),
                                              `Fire Suppression` = numeric(),
                                              `Cycles per Year` = numeric(),
                                              `Depth of Discharge` = numeric())


for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           114,
                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NCA Graphite",
                                           2001,
                                           k,
                                           0.95,
                                           runs,
                                           "Yes",
                                           65,
                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                           "r410a.kg",
                                           "Long Beach Generating Station - Unit 1")
  
  temp_results = temp_results[[1]]
  
  standard_NCA_Graphite_Var_Cycles = rbind(standard_NCA_Graphite_Var_Cycles, temp_results)
  
}


standard_NCA_Graphite_cost_per_cycles = function_var_cycles_sum(standard_NCA_Graphite_Var_Cycles)


##############################################################################
# LMO Graphite # Commented Out
##############################################################################

# standard_LMO_Graphite_0_Cycles = function_monte_carlo_plot("Average",
#                                                            "National",
#                                                            50,
#                                                            4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
#                                                            2020,
#                                                            7.5, # [15, 20],
#                                                            "LMO Graphite",
#                                                            2001,
#                                                            1,
#                                                            0.8,
#                                                            runs)
# 
# standard_LMO_Graphite_1000_Cycles = function_monte_carlo_plot("Average",
#                                                               "National",
#                                                               50,
#                                                               4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
#                                                               2020,
#                                                               7.5, # [15, 20],
#                                                               "LMO Graphite",
#                                                               2001,
#                                                               501,
#                                                               0.8,
#                                                               runs)
# 
# 
# standard_LMO_Graphite_Var_Cycles = data.frame(`Mean` = numeric(), 
#                                               `STDev` = numeric(), 
#                                               `Component` = factor(), 
#                                               `temp` = numeric(), 
#                                               `YPos_Cum` = numeric(), 
#                                               `YPos_Ind` = numeric(),
#                                               `City` = factor(),
#                                               `State` = factor(),
#                                               `Capacity MWh` = numeric(),
#                                               `Power MW` = numeric(),
#                                               `Duration Hr` = numeric(),
#                                               `Year` = numeric(),
#                                               `Lifespan Yr` = numeric(),
#                                               `Chemistry` = factor(),
#                                               `Fire Suppression` = numeric(),
#                                               `Cycles per Year` = numeric(),
#                                               `Depth of Discharge` = numeric())
# 
# for (k in seq(1,501, by=50)) {
#   
#   temp_results = function_monte_carlo_plot("Average",
#                                            "National",
#                                            50,
#                                            4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
#                                            2020,
#                                            7.5, # [15, 20],
#                                            "LMO Graphite",
#                                            2001,
#                                            k,
#                                            0.8,
#                                            runs)
#   
#   standard_LMO_Graphite_Var_Cycles = rbind(standard_LMO_Graphite_Var_Cycles, temp_results)
#   
# }
# 
# 
# standard_LMO_Graphite_cost_per_cycles = function_var_cycles_sum(standard_LMO_Graphite_Var_Cycles)

##############################################################################
# LFP Graphite #
##############################################################################

standard_LFP_Graphite_0_Cycles = function_monte_carlo_plot("Average",
                                                           "National",
                                                           114,
                                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                           2020,
                                                           7.5, # [15, 20],
                                                           "LFP Graphite",
                                                           2001,
                                                           1,
                                                           0.95,
                                                           runs,
                                                           "Yes",
                                                           65,
                                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                                           "r410a.kg",
                                                           "Long Beach Generating Station - Unit 1")
standard_LFP_Graphite_0_Cycles = standard_LFP_Graphite_0_Cycles[[1]]

standard_LFP_Graphite_1000_Cycles = function_monte_carlo_plot("Average",
                                                              "National",
                                                              114,
                                                              4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                              2020,
                                                              7.5, # [15, 20],
                                                              "LFP Graphite",
                                                              2001,
                                                              501,
                                                              0.95,
                                                              runs,
                                                              "Yes",
                                                              65,
                                                              "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                                              "electricity.NG.kWh", # "electricity.NG.kWh"
                                                              "r410a.kg",
                                                              "Long Beach Generating Station - Unit 1")
standard_LFP_Graphite_1000_Cycles = standard_LFP_Graphite_1000_Cycles[[1]]







standard_NMC_Graphite_Var_Cycles = data.frame(`Mean` = numeric(), 
                                              `STDev` = numeric(),
                                              `5th P` = numeric(),
                                              `95th P` = numeric(),
                                              `Component` = factor(), 
                                              `temp` = numeric(), 
                                              `YPos_Cum` = numeric(), 
                                              `YPos_Ind` = numeric(),
                                              `City` = factor(),
                                              `State` = factor(),
                                              `Capacity MWh` = numeric(),
                                              `Power MW` = numeric(),
                                              `Duration Hr` = numeric(),
                                              `Year` = numeric(),
                                              `Lifespan Yr` = numeric(),
                                              `Chemistry` = factor(),
                                              `Fire Suppression` = numeric(),
                                              `Cycles per Year` = numeric(),
                                              `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           114,
                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NMC Graphite",
                                           2001,
                                           k,
                                           0.95,
                                           runs,
                                           "Yes",
                                           65,
                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                           "r410a.kg",
                                           "Long Beach Generating Station - Unit 1")
  temp_results = temp_results[[1]]
  
  standard_NMC_Graphite_Var_Cycles = rbind(standard_NMC_Graphite_Var_Cycles, temp_results)
  
}

standard_NMC_Graphite_cost_per_cycles = function_var_cycles_sum(standard_NMC_Graphite_Var_Cycles)





standard_NCA_Graphite_Var_Cycles = data.frame(`Mean` = numeric(), 
                                              `STDev` = numeric(),
                                              `5th P` = numeric(),
                                              `95th P` = numeric(), 
                                              `Component` = factor(), 
                                              `temp` = numeric(), 
                                              `YPos_Cum` = numeric(), 
                                              `YPos_Ind` = numeric(),
                                              `City` = factor(),
                                              `State` = factor(),
                                              `Capacity MWh` = numeric(),
                                              `Power MW` = numeric(),
                                              `Duration Hr` = numeric(),
                                              `Year` = numeric(),
                                              `Lifespan Yr` = numeric(),
                                              `Chemistry` = factor(),
                                              `Fire Suppression` = numeric(),
                                              `Cycles per Year` = numeric(),
                                              `Depth of Discharge` = numeric())


for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           114,
                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NCA Graphite",
                                           2001,
                                           k,
                                           0.95,
                                           runs,
                                           "Yes",
                                           65,
                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                           "r410a.kg",
                                           "Long Beach Generating Station - Unit 1")
  
  temp_results = temp_results[[1]]
  
  standard_NCA_Graphite_Var_Cycles = rbind(standard_NCA_Graphite_Var_Cycles, temp_results)
  
}


standard_NCA_Graphite_cost_per_cycles = function_var_cycles_sum(standard_NCA_Graphite_Var_Cycles)







standard_LFP_Graphite_Var_Cycles = data.frame(`Mean` = numeric(), 
                                              `STDev` = numeric(), 
                                              `5th P` = numeric(),
                                              `95th P` = numeric(),
                                              `Component` = factor(), 
                                              `temp` = numeric(), 
                                              `YPos_Cum` = numeric(), 
                                              `YPos_Ind` = numeric(),
                                              `City` = factor(),
                                              `State` = factor(),
                                              `Capacity MWh` = numeric(),
                                              `Power MW` = numeric(),
                                              `Duration Hr` = numeric(),
                                              `Year` = numeric(),
                                              `Lifespan Yr` = numeric(),
                                              `Chemistry` = factor(),
                                              `Fire Suppression` = numeric(),
                                              `Cycles per Year` = numeric(),
                                              `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           114,
                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "LFP Graphite",
                                           2001,
                                           k,
                                           0.95,
                                           runs,
                                           "Yes",
                                           65,
                                           "electricity.Solar.kWh", # "electricity.Solar.kWh"
                                           "electricity.NG.kWh", # "electricity.NG.kWh"
                                           "r410a.kg",
                                           "Long Beach Generating Station - Unit 1")
  temp_results = temp_results[[1]]
  
  standard_LFP_Graphite_Var_Cycles = rbind(standard_LFP_Graphite_Var_Cycles, temp_results)
  
}


standard_LFP_Graphite_cost_per_cycles = function_var_cycles_sum(standard_LFP_Graphite_Var_Cycles)



##############################################################################
# NMC Graphite, Dur 2  #
##############################################################################

standard_NMC_Graphite_0_Cycles_Dur_2 = function_monte_carlo_plot("Average",
                                                                 "National",
                                                                 50,
                                                                 2, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                                 2020,
                                                                 7.5, # [15, 20],
                                                                 "NMC Graphite",
                                                                 2001,
                                                                 1,
                                                                 0.85,
                                                                 runs,
                                                                 "Yes",
                                                                 50)
standard_NMC_Graphite_0_Cycles_Dur_2 = standard_NMC_Graphite_0_Cycles_Dur_2[[1]]

standard_NMC_Graphite_1000_Cycles_Dur_2 = function_monte_carlo_plot("Average",
                                                                    "National",
                                                                    50,
                                                                    2, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                                    2020,
                                                                    7.5, # [15, 20],
                                                                    "NMC Graphite",
                                                                    2001,
                                                                    501,
                                                                    0.85,
                                                                    runs,
                                                                    "Yes",
                                                                    50)
standard_NMC_Graphite_1000_Cycles_Dur_2 = standard_NMC_Graphite_1000_Cycles_Dur_2[[1]]

standard_NMC_Graphite_Var_Cycles_Dur_2 = data.frame(`Mean` = numeric(), 
                                                    `STDev` = numeric(), 
                                                    `5th P` = numeric(),
                                                    `95th P` = numeric(),
                                                    `Component` = factor(), 
                                                    `temp` = numeric(), 
                                                    `YPos_Cum` = numeric(), 
                                                    `YPos_Ind` = numeric(),
                                                    `City` = factor(),
                                                    `State` = factor(),
                                                    `Capacity MWh` = numeric(),
                                                    `Power MW` = numeric(),
                                                    `Duration Hr` = numeric(),
                                                    `Year` = numeric(),
                                                    `Lifespan Yr` = numeric(),
                                                    `Chemistry` = factor(),
                                                    `Fire Suppression` = numeric(),
                                                    `Cycles per Year` = numeric(),
                                                    `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           50,
                                           2, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NMC Graphite",
                                           2001,
                                           k,
                                           0.85,
                                           runs,
                                           "Yes",
                                           50)
  temp_results = temp_results[[1]]
  
  standard_NMC_Graphite_Var_Cycles_Dur_2 = rbind(standard_NMC_Graphite_Var_Cycles_Dur_2, temp_results)
  
}


standard_NMC_Graphite_cost_per_cycles_Dur_2 = function_var_cycles_sum(standard_NMC_Graphite_Var_Cycles_Dur_2)


##############################################################################
# NMC Graphite, Dur 1  #
##############################################################################

standard_NMC_Graphite_0_Cycles_Dur_1 = function_monte_carlo_plot("Average",
                                                                 "National",
                                                                 50,
                                                                 1, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                                 2020,
                                                                 7.5, # [15, 20],
                                                                 "NMC Graphite",
                                                                 2001,
                                                                 1,
                                                                 0.8,
                                                                 runs,
                                                                 "Yes",
                                                                 50)
standard_NMC_Graphite_0_Cycles_Dur_1 = standard_NMC_Graphite_0_Cycles_Dur_1[[1]]

standard_NMC_Graphite_1000_Cycles_Dur_1 = function_monte_carlo_plot("Average",
                                                                    "National",
                                                                    50,
                                                                    1, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                                    2020,
                                                                    7.5, # [15, 20],
                                                                    "NMC Graphite",
                                                                    2001,
                                                                    501,
                                                                    0.8,
                                                                    runs,
                                                                    "Yes",
                                                                    50)
standard_NMC_Graphite_1000_Cycles_Dur_1 = standard_NMC_Graphite_1000_Cycles_Dur_1[[1]]

standard_NMC_Graphite_Var_Cycles_Dur_1 = data.frame(`Mean` = numeric(), 
                                                    `STDev` = numeric(), 
                                                    `5th P` = numeric(),
                                                    `95th P` = numeric(),
                                                    `Component` = factor(), 
                                                    `temp` = numeric(), 
                                                    `YPos_Cum` = numeric(), 
                                                    `YPos_Ind` = numeric(),
                                                    `City` = factor(),
                                                    `State` = factor(),
                                                    `Capacity MWh` = numeric(),
                                                    `Power MW` = numeric(),
                                                    `Duration Hr` = numeric(),
                                                    `Year` = numeric(),
                                                    `Lifespan Yr` = numeric(),
                                                    `Chemistry` = factor(),
                                                    `Fire Suppression` = numeric(),
                                                    `Cycles per Year` = numeric(),
                                                    `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           50,
                                           1, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NMC Graphite",
                                           2001,
                                           k,
                                           0.8,
                                           runs,
                                           "Yes",
                                           50)
  temp_results = temp_results[[1]]
  
  standard_NMC_Graphite_Var_Cycles_Dur_1 = rbind(standard_NMC_Graphite_Var_Cycles_Dur_1, temp_results)
  
}

standard_NMC_Graphite_cost_per_cycles_Dur_1 = function_var_cycles_sum(standard_NMC_Graphite_Var_Cycles_Dur_1)


##############################################################################
# NMC Graphite, Dur 0.5  #
##############################################################################

standard_NMC_Graphite_0_Cycles_Dur_0.5 = function_monte_carlo_plot("Average",
                                                                   "National",
                                                                   50,
                                                                   0.5, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                                   2020,
                                                                   7.5, # [15, 20],
                                                                   "NMC Graphite",
                                                                   2001,
                                                                   1,
                                                                   0.75,
                                                                   runs,
                                                                   "Yes",
                                                                   50)
standard_NMC_Graphite_0_Cycles_Dur_0.5 = standard_NMC_Graphite_0_Cycles_Dur_0.5[[1]]

standard_NMC_Graphite_1000_Cycles_Dur_0.5 = function_monte_carlo_plot("Average",
                                                                      "National",
                                                                      50,
                                                                      0.5, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                                      2020,
                                                                      7.5, # [15, 20],
                                                                      "NMC Graphite",
                                                                      2001,
                                                                      501,
                                                                      0.75,
                                                                      runs,
                                                                      "Yes",
                                                                      50)
standard_NMC_Graphite_1000_Cycles_Dur_0.5 = standard_NMC_Graphite_1000_Cycles_Dur_0.5[[1]]

standard_NMC_Graphite_Var_Cycles_Dur_0.5 = data.frame(`Mean` = numeric(), 
                                                      `STDev` = numeric(), 
                                                      `5th P` = numeric(),
                                                      `95th P` = numeric(),
                                                      `Component` = factor(), 
                                                      `temp` = numeric(), 
                                                      `YPos_Cum` = numeric(), 
                                                      `YPos_Ind` = numeric(),
                                                      `City` = factor(),
                                                      `State` = factor(),
                                                      `Capacity MWh` = numeric(),
                                                      `Power MW` = numeric(),
                                                      `Duration Hr` = numeric(),
                                                      `Year` = numeric(),
                                                      `Lifespan Yr` = numeric(),
                                                      `Chemistry` = factor(),
                                                      `Fire Suppression` = numeric(),
                                                      `Cycles per Year` = numeric(),
                                                      `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           50,
                                           0.5, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NMC Graphite",
                                           2001,
                                           k,
                                           0.75,
                                           runs,
                                           "Yes",
                                           50)
  temp_results = temp_results[[1]]
  
  standard_NMC_Graphite_Var_Cycles_Dur_0.5 = rbind(standard_NMC_Graphite_Var_Cycles_Dur_0.5, temp_results)
  
}

standard_NMC_Graphite_cost_per_cycles_Dur_0.5 = function_var_cycles_sum(standard_NMC_Graphite_Var_Cycles_Dur_0.5)



##############################################################################
# NMC Graphite, 1 MW, Dur 4  #
##############################################################################

MW1_NMC_Graphite_0_Cycles_Dur_4 = function_monte_carlo_plot("Average",
                                                            "National",
                                                            1,
                                                            4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                            2020,
                                                            7.5, # [15, 20],
                                                            "NMC Graphite",
                                                            2001,
                                                            1,
                                                            0.95,
                                                            runs,
                                                            "Yes",
                                                            1)
MW1_NMC_Graphite_0_Cycles_Dur_4 = MW1_NMC_Graphite_0_Cycles_Dur_4[[1]]

MW1_NMC_Graphite_1000_Cycles_Dur_4 = function_monte_carlo_plot("Average",
                                                               "National",
                                                               1,
                                                               4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                               2020,
                                                               7.5, # [15, 20],
                                                               "NMC Graphite",
                                                               2001,
                                                               501,
                                                               0.95,
                                                               runs,
                                                               "Yes",
                                                               1)
MW1_NMC_Graphite_1000_Cycles_Dur_4 = MW1_NMC_Graphite_1000_Cycles_Dur_4[[1]]

MW1_NMC_Graphite_Var_Cycles_Dur_4 = data.frame(`Mean` = numeric(), 
                                               `STDev` = numeric(), 
                                               `5th P` = numeric(),
                                               `95th P` = numeric(),
                                               `Component` = factor(), 
                                               `temp` = numeric(), 
                                               `YPos_Cum` = numeric(), 
                                               `YPos_Ind` = numeric(),
                                               `City` = factor(),
                                               `State` = factor(),
                                               `Capacity MWh` = numeric(),
                                               `Power MW` = numeric(),
                                               `Duration Hr` = numeric(),
                                               `Year` = numeric(),
                                               `Lifespan Yr` = numeric(),
                                               `Chemistry` = factor(),
                                               `Fire Suppression` = numeric(),
                                               `Cycles per Year` = numeric(),
                                               `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           1,
                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NMC Graphite",
                                           2001,
                                           k,
                                           0.95,
                                           runs,
                                           "Yes",
                                           50)
  temp_results = temp_results[[1]]
  
  MW1_NMC_Graphite_Var_Cycles_Dur_4 = rbind(MW1_NMC_Graphite_Var_Cycles_Dur_4, temp_results)
  
}

MW1_NMC_Graphite_cost_per_cycles_Dur_4 = function_var_cycles_sum(MW1_NMC_Graphite_Var_Cycles_Dur_4)



##############################################################################
# NMC Graphite, 10 MW, Dur 4  #
##############################################################################

MW10_NMC_Graphite_0_Cycles_Dur_4 = function_monte_carlo_plot("Average",
                                                             "National",
                                                             10,
                                                             4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                             2020,
                                                             7.5, # [15, 20],
                                                             "NMC Graphite",
                                                             2001,
                                                             1,
                                                             0.95,
                                                             runs,
                                                             "Yes",
                                                             10)
MW10_NMC_Graphite_0_Cycles_Dur_4 = MW10_NMC_Graphite_0_Cycles_Dur_4[[1]]

MW10_NMC_Graphite_1000_Cycles_Dur_4 = function_monte_carlo_plot("Average",
                                                                "National",
                                                                10,
                                                                4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                                2020,
                                                                7.5, # [15, 20],
                                                                "NMC Graphite",
                                                                2001,
                                                                501,
                                                                0.95,
                                                                runs,
                                                                "Yes",
                                                                10)
MW10_NMC_Graphite_1000_Cycles_Dur_4 = MW10_NMC_Graphite_1000_Cycles_Dur_4[[1]]


MW10_NMC_Graphite_Var_Cycles_Dur_4 = data.frame(`Mean` = numeric(), 
                                                `STDev` = numeric(), 
                                                `5th P` = numeric(),
                                                `95th P` = numeric(),
                                                `Component` = factor(), 
                                                `temp` = numeric(), 
                                                `YPos_Cum` = numeric(), 
                                                `YPos_Ind` = numeric(),
                                                `City` = factor(),
                                                `State` = factor(),
                                                `Capacity MWh` = numeric(),
                                                `Power MW` = numeric(),
                                                `Duration Hr` = numeric(),
                                                `Year` = numeric(),
                                                `Lifespan Yr` = numeric(),
                                                `Chemistry` = factor(),
                                                `Fire Suppression` = numeric(),
                                                `Cycles per Year` = numeric(),
                                                `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           10,
                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NMC Graphite",
                                           2001,
                                           k,
                                           0.95,
                                           runs,
                                           "Yes",
                                           10)
  temp_results = temp_results[[1]]
  
  MW10_NMC_Graphite_Var_Cycles_Dur_4 = rbind(MW10_NMC_Graphite_Var_Cycles_Dur_4, temp_results)
  
}

MW10_NMC_Graphite_cost_per_cycles_Dur_4 = function_var_cycles_sum(MW10_NMC_Graphite_Var_Cycles_Dur_4)


##############################################################################
# NMC Graphite, 100 MW, Dur 4  #
##############################################################################

MW100_NMC_Graphite_0_Cycles_Dur_4 = function_monte_carlo_plot("Average",
                                                              "National",
                                                              100,
                                                              4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                              2020,
                                                              7.5, # [15, 20],
                                                              "NMC Graphite",
                                                              2001,
                                                              1,
                                                              0.95,
                                                              runs,
                                                              "Yes",
                                                              100)
MW100_NMC_Graphite_0_Cycles_Dur_4 = MW100_NMC_Graphite_0_Cycles_Dur_4[[1]]

MW100_NMC_Graphite_1000_Cycles_Dur_4 = function_monte_carlo_plot("Average",
                                                                 "National",
                                                                 100,
                                                                 4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                                 2020,
                                                                 7.5, # [15, 20],
                                                                 "NMC Graphite",
                                                                 2001,
                                                                 501,
                                                                 0.95,
                                                                 runs,
                                                                 "Yes",
                                                                 100)
MW100_NMC_Graphite_1000_Cycles_Dur_4 = MW100_NMC_Graphite_1000_Cycles_Dur_4[[1]]

MW100_NMC_Graphite_Var_Cycles_Dur_4 = data.frame(`Mean` = numeric(), 
                                                 `STDev` = numeric(), 
                                                 `5th P` = numeric(),
                                                 `95th P` = numeric(),
                                                 `Component` = factor(), 
                                                 `temp` = numeric(), 
                                                 `YPos_Cum` = numeric(), 
                                                 `YPos_Ind` = numeric(),
                                                 `City` = factor(),
                                                 `State` = factor(),
                                                 `Capacity MWh` = numeric(),
                                                 `Power MW` = numeric(),
                                                 `Duration Hr` = numeric(),
                                                 `Year` = numeric(),
                                                 `Lifespan Yr` = numeric(),
                                                 `Chemistry` = factor(),
                                                 `Fire Suppression` = numeric(),
                                                 `Cycles per Year` = numeric(),
                                                 `Depth of Discharge` = numeric())

for (k in seq(1,501, by=50)) {
  
  temp_results = function_monte_carlo_plot("Average",
                                           "National",
                                           100,
                                           4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                           2020,
                                           7.5, # [15, 20],
                                           "NMC Graphite",
                                           2001,
                                           k,
                                           0.95,
                                           runs,
                                           "Yes",
                                           100)
  temp_results = temp_results[[1]]
  
  MW100_NMC_Graphite_Var_Cycles_Dur_4 = rbind(MW100_NMC_Graphite_Var_Cycles_Dur_4, temp_results)
  
}

MW100_NMC_Graphite_cost_per_cycles_Dur_4 = function_var_cycles_sum(MW100_NMC_Graphite_Var_Cycles_Dur_4)



##############################################################################
# NMC Graphite, 50 MW, Dur 4, No Degredation  #
##############################################################################

standard_NMC_Graphite_no_deg = function_monte_carlo_plot("Average",
                                                         "National",
                                                         50,
                                                         4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                         2020,
                                                         7.5, # [15, 20],
                                                         "NMC Graphite",
                                                         2001,
                                                         251,
                                                         0.95,
                                                         runs,
                                                         "No",
                                                         50)
standard_NMC_Graphite_no_deg = standard_NMC_Graphite_no_deg[[1]]

##############################################################################
# NCA Graphite, 50 MW, Dur 4, No Degredation  #
##############################################################################

standard_NCA_Graphite_no_deg = function_monte_carlo_plot("Average",
                                                         "National",
                                                         50,
                                                         4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                         2020,
                                                         7.5, # [15, 20],
                                                         "NCA Graphite",
                                                         2001,
                                                         251,
                                                         0.95,
                                                         runs,
                                                         "No",
                                                         50)
standard_NCA_Graphite_no_deg = standard_NCA_Graphite_no_deg[[1]]

##############################################################################
# LFP Graphite, 50 MW, Dur 4, No Degredation  #
##############################################################################

standard_LFP_Graphite_no_deg = function_monte_carlo_plot("Average",
                                                         "National",
                                                         50,
                                                         4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                         2020,
                                                         7.5, # [15, 20],
                                                         "LFP Graphite",
                                                         2001,
                                                         251,
                                                         0.95,
                                                         runs,
                                                         "No",
                                                         50)
standard_LFP_Graphite_no_deg = standard_LFP_Graphite_no_deg[[1]]

##############################################################################
# NMC Graphite, 50 MW, Dur 4, 251 Cycles  #
##############################################################################

standard_NMC_Graphite_251_cycles = function_monte_carlo_plot("Average",
                                                             "National",
                                                             50,
                                                             4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                             2020,
                                                             7.5, # [15, 20],
                                                             "NMC Graphite",
                                                             2001,
                                                             251,
                                                             0.95,
                                                             runs,
                                                             "Yes",
                                                             50)
standard_NMC_Graphite_251_cycles = standard_NMC_Graphite_251_cycles[[1]]

##############################################################################
# NCA Graphite, 50 MW, Dur 4, 251 Cycles  #
##############################################################################

standard_NCA_Graphite_251_cycles = function_monte_carlo_plot("Average",
                                                             "National",
                                                             50,
                                                             4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                             2020,
                                                             7.5, # [15, 20],
                                                             "NCA Graphite",
                                                             2001,
                                                             251,
                                                             0.95,
                                                             runs,
                                                             "Yes",
                                                             50)
standard_NCA_Graphite_251_cycles = standard_NCA_Graphite_251_cycles[[1]]

##############################################################################
# LFP Graphite, 50 MW, Dur 4, 251 Cycles  #
##############################################################################

standard_LFP_Graphite_251_cycles = function_monte_carlo_plot("Average",
                                                             "National",
                                                             50,
                                                             4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                             2020,
                                                             7.5, # [15, 20],
                                                             "LFP Graphite",
                                                             2001,
                                                             251,
                                                             0.95,
                                                             runs,
                                                             "Yes",
                                                             50)
standard_LFP_Graphite_251_cycles = standard_LFP_Graphite_251_cycles[[1]]


##############################################################################
# NMC Graphite, 4 duration, 251 cycles Both bar graphs
##############################################################################

ggplot(standard_NMC_Graphite_251_cycles, aes(x = Component, y = Mean, fill = Component)) +
  geom_bar(stat="identity", width = 0.5) +
  geom_errorbar(aes(ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
  annotate("text", x = graph_order,
           y = standard_NMC_Graphite_251_cycles$YPos_Ind + 2* standard_NMC_Graphite_251_cycles$STDev + 14, label = paste(standard_NMC_Graphite_251_cycles$Mean, '+/-', 2* standard_NMC_Graphite_251_cycles$STDev), size = 5.5) +
  theme_minimal() +
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  labs(title = "Upfront Capital Cost Breakdown of Utility-Scale Li-ion BESS") +
  ylab("2020-USD per kWh") +
  xlab("Primary Component") +
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600


ggplot(standard_NMC_Graphite_251_cycles, aes(x = `Duration Hr`, y = Mean, fill = Component)) +
  geom_bar(stat="identity", width = 0.25) +
  geom_errorbar(aes(ymin = sum(Mean) - 2*sum(STDev), ymax = sum(Mean) + 2*sum(STDev)), width = 0.25) +
  geom_text(aes(y=YPos_Cum, label=Mean),vjust = 1, size = 3) +
  annotate("text", x = standard_NMC_Graphite_251_cycles$`Duration Hr`[1], 
           y = sum(standard_NMC_Graphite_251_cycles$YPos_Ind) + 2*sum(standard_NMC_Graphite_251_cycles$STDev) + 15, label = paste(sum(standard_NMC_Graphite_251_cycles$Mean), '+/-', 2*sum(standard_NMC_Graphite_251_cycles$STDev))) +
  theme_minimal() +
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  labs(title = "BESS 200 MWh / 50 MW") +
  ylab("Cost 2020 USD / kWh")+
  theme(axis.text.y = element_text(size = 12.5),
        plot.title = element_text(size = 32.5),
        axis.title = element_text(size = 30),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=17.5),
        legend.title = element_text(size = 30),
        legend.text = element_text(size = 30)) # 1500 x 600


##############################################################################
# Chemistry 1000 Cycles Bar Plot # 
##############################################################################

chem_1000_cycles_graph = rbind(standard_NCA_Graphite_1000_Cycles, 
                               standard_NMC_Graphite_1000_Cycles, 
                               standard_LFP_Graphite_1000_Cycles #, 
                               #standard_LMO_Graphite_1000_Cycles
)

chem_1000_cycles_stats = function_results_chem_stats(chem_1000_cycles_graph)

chem_plot_1000_cycles = ggplot() +
  geom_bar(data = chem_1000_cycles_graph, aes(x = Chemistry, y = Mean, fill = Component), stat="identity", width = 0.5) + 
  geom_errorbar(data = chem_1000_cycles_stats, aes(x = Chemistry, ymin = Mean - 2 * STDev, ymax = Mean + 2 * STDev), width = 0.375, size = 1) +
  # geom_text(data = chem_1000_cycles_graph, aes(x = Chemistry, y=YPos_Cum, label=Mean),vjust = 1, size = 3) + 
  labs(title = "501 Annual Cycles") + 
  ylab("USD per kWh") +
  ylim(0, max(chem_1000_cycles_stats$Mean) + 2*max(chem_1000_cycles_stats$STDev) + 100) +
  theme_minimal() + 
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  # scale_fill_brewer(palette = "Spectral") +
  annotate("text", x = c("NCA Graphite", "NMC Graphite", "LFP Graphite"),
           y = c(sum(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "NCA Graphite"], 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "NCA Graphite"]) + 30,
                 sum(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "NMC Graphite"], 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "NMC Graphite"]) + 30,
                 sum(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "LFP Graphite"], 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "LFP Graphite"]) + 30 #,
                 # sum(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "LMO Graphite"], 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "LMO Graphite"]) + 30
           ),
           label = c(paste(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "NCA Graphite"], "+/-", 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "NCA Graphite"]),
                     paste(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "NMC Graphite"], "+/-", 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "NMC Graphite"]),
                     paste(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "LFP Graphite"], "+/-", 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "LFP Graphite"]) #,
                     # paste(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "LMO Graphite"], "+/-", 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "LMO Graphite"])
           ),
           size = 5.5
  ) +
  theme(axis.title.y = element_blank(),
        plot.title = element_text(size = 27.5),
        axis.title = element_text(size = 27.5),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=15),
        legend.title = element_text(size = 27.5),
        legend.text = element_text(size = 27.5))

##############################################################################
# Chemistry 0 Cycles Bar Plot #
##############################################################################

chem_0_cycles_graph = rbind(standard_NCA_Graphite_0_Cycles, 
                            standard_NMC_Graphite_0_Cycles, 
                            standard_LFP_Graphite_0_Cycles #, 
                            #standard_LMO_Graphite_0_Cycles
)

chem_0_cycles_stats = function_results_chem_stats(chem_0_cycles_graph)

chem_plot_0_cycles = ggplot() +
  geom_bar(data = chem_0_cycles_graph, aes(x = Chemistry, y = Mean, fill = Component), stat="identity", width = 0.5) + 
  geom_errorbar(data = chem_0_cycles_stats, aes(x = Chemistry, ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.375, size = 1) +
  # geom_text(data = chem_0_cycles_graph, aes(x = Chemistry, y=YPos_Cum, label=Mean),vjust = 1, size = 3) + 
  labs(title = "1 Annual Cycle") + 
  ylab("USD per kWh") +
  ylim(0, max(chem_1000_cycles_stats$Mean) + 2*max(chem_1000_cycles_stats$STDev) + 100) +
  theme_minimal() + 
  scale_fill_manual(values = cbpalette) +
  # scale_fill_brewer(palette = "Spectral") +
  annotate("text", x = c("NCA Graphite", "NMC Graphite", "LFP Graphite"),
           y = c(sum(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "NCA Graphite"], 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "NCA Graphite"]) + 30,
                 sum(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "NMC Graphite"], 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "NMC Graphite"]) + 30,
                 sum(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "LFP Graphite"], 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "LFP Graphite"]) + 30
           ),
           label = c(paste(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "NCA Graphite"], "+/-", 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "NCA Graphite"]),
                     paste(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "NMC Graphite"], "+/-", 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "NMC Graphite"]),
                     paste(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "LFP Graphite"], "+/-", 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "LFP Graphite"])
           ),
           size = 5.5
  ) +
  theme(legend.position = "none",
        plot.title = element_text(size = 27.5),
        axis.title = element_text(size = 27.5),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=15))



# chem_plot_0_cycles_EBI = ggplot() +
#   geom_bar(data = chem_0_cycles_graph, aes(x = Chemistry, y = Mean, fill = Component), stat="identity", width = 0.5) + 
#   geom_errorbar(data = chem_0_cycles_stats, aes(x = Chemistry, ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.25) +
#   # geom_text(data = chem_0_cycles_graph, aes(x = Chemistry, y=YPos_Cum, label=Mean),vjust = 1, size = 3) + 
#   labs(title = "50 MW / 200 MWh Li-Ion BESS Costs - Varying Chemistries") + 
#   ylab("USD per kWh") +
#   # ylim(0, max(chem_1000_cycles_stats$Mean) + 2*max(chem_1000_cycles_stats$STDev) + 100) +
#   theme_minimal() + 
#   # scale_fill_manual(values = test_pal)
#   scale_fill_brewer(palette = "Spectral") +
#   annotate("text", x = c("NCA Graphite", "NMC Graphite", "LFP Graphite", "LMO Graphite"),
#            y = c(sum(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "NCA Graphite"], 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "NCA Graphite"]) + 30,
#                  sum(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "NMC Graphite"], 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "NMC Graphite"]) + 30,
#                  sum(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "LFP Graphite"], 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "LFP Graphite"]) + 30,
#                  sum(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "LMO Graphite"], 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "LMO Graphite"]) + 30
#            ),
#            label = c(paste(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "NCA Graphite"], "+/-", 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "NCA Graphite"]),
#                      paste(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "NMC Graphite"], "+/-", 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "NMC Graphite"]),
#                      paste(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "LFP Graphite"], "+/-", 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "LFP Graphite"]),
#                      paste(chem_0_cycles_stats$Mean[chem_0_cycles_stats$Chemistry == "LMO Graphite"], "+/-", 2 * chem_0_cycles_stats$STDev[chem_0_cycles_stats$Chemistry == "LMO Graphite"])
#            ),
#            size = 5
#   ) +
#   theme(plot.title = element_text(size = 30),
#         axis.title = element_text(size = 25),
#         axis.text.x = element_text(size = 15),
#         text = element_text(size=20),
#         legend.title = element_text(size = 25),
#         legend.text = element_text(size = 20))



##############################################################################
# Chemistry Cycles Plot #
##############################################################################

chem_var_cycles_graph = rbind(standard_NCA_Graphite_cost_per_cycles, 
                              standard_NMC_Graphite_cost_per_cycles,
                              standard_LFP_Graphite_cost_per_cycles #,
                              #standard_LMO_Graphite_cost_per_cycles
)

colnames(chem_var_cycles_graph) = c("Tot", 
                                    "STDev",
                                    "5th P",
                                    "95th P",
                                    "Component", 
                                    "temp", 
                                    "YPos_Cum", 
                                    "YPos_Ind",
                                    "City",
                                    "State",
                                    "Capacity.MWh",
                                    "Power.MW",
                                    "Duration (Hrs)",
                                    "Year",
                                    "Lifespan.Yr",
                                    "Chemistry",
                                    "Fire.Suppression",
                                    "Cycles.per.Year",
                                    "Depth.of.Discharge",
                                    "Tot 5th P",
                                    "Tot 95th P"
)

chem_plot_var_cycles = ggplot(data = chem_var_cycles_graph) +
  geom_line(aes(x = Cycles.per.Year, y = Tot, group = Chemistry, linetype = Chemistry, color = Chemistry), size = 0.5) + # ,color = Chemistry
  geom_point(aes(x = Cycles.per.Year, y = Tot, group = Chemistry, shape = Chemistry, color = Chemistry), size = 2) + 
  xlab("Expected Annual Cycles") +
  ylab("USD per kWh") +
  labs(title = "Varying Cycles") +
  ylim(0,max(chem_1000_cycles_stats$Mean) + 2*max(chem_1000_cycles_stats$STDev) + 100) +
  labs("60 MW / 240 MWh, Cost vs Annual Cycles") +
  scale_linetype_manual(values=c("solid", "solid", "solid"))+
  scale_shape_manual(values=c(0, 1, 2, 4))+
  scale_color_manual(values=c("#56B4E9", "#009E73", "#D55E00")) +
  theme_minimal() + 
  theme(legend.position = c(0.5,0.25),
        legend.title = element_text(size = 25),
        legend.text = element_text(size = 25),
        plot.title = element_text(size = 27.5, hjust = 0.5),
        axis.title = element_text(size = 27.5),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size = 12.5),
        legend.background = element_rect(fill = "white", size = 0.5, linetype = "solid", color = "black"),
        text = element_text(size=15))


##############################################################################
# Grid Arrange Chemistry #
##############################################################################

grid.arrange(chem_plot_0_cycles,chem_plot_var_cycles, chem_plot_1000_cycles, nrow = 1, widths = c(1.3, 1, 2.1)) # , top=textGrob("50 MW / 200 MWH Li-Ion BESS",gp=gpar(fontsize=40,font=3)))


##############################################################################
# Dur Tot and STD Stats #
##############################################################################

function_results_dur_stats <- function(results_binded) {
  
  Stats = data.frame(Mean = numeric(4), STDev = numeric(4), `Duration Hr` = numeric(4))
  Stats$Mean = c(sum(results_binded$Mean[results_binded$`Duration Hr`== 4]),
                 sum(results_binded$Mean[results_binded$`Duration Hr`== 2]),
                 sum(results_binded$Mean[results_binded$`Duration Hr`== 1]),
                 sum(results_binded$Mean[results_binded$`Duration Hr`== 0.5])
  )
  Stats$STDev = round(c(sum(results_binded$STDev[results_binded$`Duration Hr`== 4]),
                        sum(results_binded$STDev[results_binded$`Duration Hr`== 2]),
                        sum(results_binded$STDev[results_binded$`Duration Hr`== 1]),
                        sum(results_binded$STDev[results_binded$`Duration Hr`== 0.5]))
  )
  Stats$`Duration Hr` = c(4, 2, 1, 0.5)
  
  return(Stats)
  
}


##############################################################################
# Duration Hr 1000 Cycles Bar Plot #
##############################################################################

dur_1000_cycles_graph = rbind(standard_NMC_Graphite_1000_Cycles_Dur_0.5, standard_NMC_Graphite_1000_Cycles_Dur_1, standard_NMC_Graphite_1000_Cycles_Dur_2, standard_NMC_Graphite_1000_Cycles)

dur_1000_cycles_stats = function_results_dur_stats(dur_1000_cycles_graph)

dur_plot_1000_cycles = ggplot() +
  geom_bar(data = dur_1000_cycles_graph, aes(x = `Duration Hr`, y = Mean, fill = Component), stat="identity", width = 0.5) + 
  geom_errorbar(data = dur_1000_cycles_stats, aes(x = as.character(`Duration Hr`), ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.25) +
  # geom_text(data = dur_1000_cycles_graph, aes(x = `Duration Hr`, y=YPos_Cum, label=Mean),vjust = 1, size = 3) + 
  labs(title = "500 Annual Cycles") + 
  ylab("USD per kWh") +
  ylim(0, max(dur_1000_cycles_stats$Mean) + 2*max(dur_1000_cycles_stats$STDev) + 100) +
  theme_minimal() + 
  # scale_fill_manual(values = test_pal)
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  annotate("text", x = c("0.5", "1", "2", "4"),
           y = c(sum(dur_1000_cycles_stats$Mean[dur_1000_cycles_stats$`Duration Hr` == "0.5"], 2* dur_1000_cycles_stats$STDev[dur_1000_cycles_stats$`Duration Hr` == "0.5"]) + 30,
                 sum(dur_1000_cycles_stats$Mean[dur_1000_cycles_stats$`Duration Hr` == "1"], 2* dur_1000_cycles_stats$STDev[dur_1000_cycles_stats$`Duration Hr` == "1"]) + 30,
                 sum(dur_1000_cycles_stats$Mean[dur_1000_cycles_stats$`Duration Hr` == "2"], 2* dur_1000_cycles_stats$STDev[dur_1000_cycles_stats$`Duration Hr` == "2"]) + 30,
                 sum(dur_1000_cycles_stats$Mean[dur_1000_cycles_stats$`Duration Hr` == "4"], 2* dur_1000_cycles_stats$STDev[dur_1000_cycles_stats$`Duration Hr` == "4"]) + 30
           ),
           label = c(paste(dur_1000_cycles_stats$Mean[dur_1000_cycles_stats$`Duration Hr` == "0.5"], "+/-", 2* dur_1000_cycles_stats$STDev[dur_1000_cycles_stats$`Duration Hr` == "0.5"]),
                     paste(dur_1000_cycles_stats$Mean[dur_1000_cycles_stats$`Duration Hr` == "1"], "+/-", 2* dur_1000_cycles_stats$STDev[dur_1000_cycles_stats$`Duration Hr` == "1"]),
                     paste(dur_1000_cycles_stats$Mean[dur_1000_cycles_stats$`Duration Hr` == "2"], "+/-", 2* dur_1000_cycles_stats$STDev[dur_1000_cycles_stats$`Duration Hr` == "2"]),
                     paste(dur_1000_cycles_stats$Mean[dur_1000_cycles_stats$`Duration Hr` == "4"], "+/-", 2* dur_1000_cycles_stats$STDev[dur_1000_cycles_stats$`Duration Hr` == "4"])
           ),
           size = 4
  ) +
  theme(axis.title.y = element_blank(),
        plot.title = element_text(size = 27.5),
        axis.title = element_text(size = 27.5),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=15),
        legend.title = element_text(size = 27.5),
        legend.text = element_text(size = 27.5))


##############################################################################
# Duration Hr 0 Cycles Bar Plot #
##############################################################################

dur_0_cycles_graph = rbind(standard_NMC_Graphite_0_Cycles_Dur_0.5, standard_NMC_Graphite_0_Cycles_Dur_1, standard_NMC_Graphite_0_Cycles_Dur_2, standard_NMC_Graphite_0_Cycles)

dur_0_cycles_stats = function_results_dur_stats(dur_0_cycles_graph)

dur_plot_0_cycles = ggplot() +
  geom_bar(data = dur_0_cycles_graph, aes(x = `Duration Hr`, y = Mean, fill = Component), stat="identity", width = 0.5) + 
  geom_errorbar(data = dur_0_cycles_stats, aes(x = as.character(`Duration Hr`), ymin = Mean - 2 * STDev, ymax = Mean + 2 * STDev), width = 0.25) +
  # geom_text(data = dur_0_cycles_graph, aes(x = `Duration Hr`, y=YPos_Cum, label=Mean),vjust = 1, size = 3) + 
  labs(title = "0 Annual Cycles") + 
  ylab("USD per kWh") +
  ylim(0, max(dur_1000_cycles_stats$Mean) + 2*max(dur_1000_cycles_stats$STDev) + 100) +
  theme_minimal() + 
  # scale_fill_manual(values = test_pal)
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  annotate("text", x = c("0.5", "1", "2", "4"),
           y = c(sum(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "0.5"], 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "0.5"]) + 30,
                 sum(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "1"], 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "1"]) + 30,
                 sum(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "2"], 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "2"]) + 30,
                 sum(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "4"], 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "4"]) + 30
           ),
           label = c(paste(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "0.5"], "+/-", 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "0.5"]),
                     paste(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "1"], "+/-", 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "1"]),
                     paste(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "2"], "+/-", 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "2"]),
                     paste(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "4"], "+/-", 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "4"])
           ),
           size = 4
  ) +
  theme(legend.position = "none",
        plot.title = element_text(size = 27.5),
        axis.title = element_text(size = 27.5),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=15))




dur_plot_0_cycles_EBI = ggplot() +
  geom_bar(data = dur_0_cycles_graph, aes(x = `Duration Hr`, y = Mean, fill = Component), stat="identity", width = 0.5) + 
  geom_errorbar(data = dur_0_cycles_stats, aes(x = as.character(`Duration Hr`), ymin = Mean - 2 * STDev, ymax = Mean + 2 * STDev), width = 0.25) +
  # geom_text(data = dur_0_cycles_graph, aes(x = `Duration Hr`, y=YPos_Cum, label=Mean),vjust = 1, size = 3) + 
  labs(title = "50 MW Li-Ion BESS Costs - Varying Durations") + 
  ylab("USD per kWh") +
  # ylim(0, max(dur_1000_cycles_stats$Mean) + 2*max(dur_1000_cycles_stats$STDev) + 100) +
  theme_minimal() + 
  # scale_fill_manual(values = test_pal)
  scale_fill_brewer(palette = "Spectral") +
  annotate("text", x = c("0.5", "1", "2", "4"),
           y = c(sum(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "0.5"], 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "0.5"]) + 30,
                 sum(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "1"], 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "1"]) + 30,
                 sum(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "2"], 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "2"]) + 30,
                 sum(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "4"], 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "4"]) + 30
           ),
           label = c(paste(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "0.5"], "+/-", 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "0.5"]),
                     paste(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "1"], "+/-", 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "1"]),
                     paste(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "2"], "+/-", 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "2"]),
                     paste(dur_0_cycles_stats$Mean[dur_0_cycles_stats$`Duration Hr` == "4"], "+/-", 2 * dur_0_cycles_stats$STDev[dur_0_cycles_stats$`Duration Hr` == "4"])
           ),
           size = 5
  ) +
  theme(plot.title = element_text(size = 30),
        axis.title = element_text(size = 25),
        text = element_text(size=20),
        legend.title = element_text(size = 25),
        legend.text = element_text(size = 20))





##############################################################################
# Duration Cycles Plot #
##############################################################################

dur_var_cycles_graph = rbind(standard_NMC_Graphite_cost_per_cycles_Dur_0.5,
                             standard_NMC_Graphite_cost_per_cycles_Dur_1,
                             standard_NMC_Graphite_cost_per_cycles_Dur_2,
                             standard_NMC_Graphite_cost_per_cycles)

colnames(dur_var_cycles_graph) = c("Mean", 
                                   "STDev",
                                   "5th P",
                                   "95th P",
                                   "Component", 
                                   "temp", 
                                   "YPos_Cum", 
                                   "YPos_Ind",
                                   "City",
                                   "State",
                                   "Capacity.MWh",
                                   "Power.MW",
                                   "Duration (Hrs)",
                                   "Year",
                                   "Lifespan.Yr",
                                   "Chemistry",
                                   "Fire.Suppression",
                                   "Cycles.per.Year",
                                   "Depth.of.Discharge",
                                   "Tot 5th P",
                                   "Tot 95th P"
)

dur_plot_var_cycles = ggplot(data = dur_var_cycles_graph) +
  geom_point(aes(x = Cycles.per.Year, y = Mean, group = `Duration (Hrs)`, shape = `Duration (Hrs)`, color = `Duration (Hrs)`), size = 2) + 
  geom_line(aes(x = Cycles.per.Year, y = Mean, group = `Duration (Hrs)`, color = `Duration (Hrs)`), size = 0.5) +
  xlab("Cycle per Year") +
  ylab("USD per kWh") +
  labs(title = "Varying Cycles") +
  ylim(0,max(dur_1000_cycles_stats$Mean) + 2*max(dur_1000_cycles_stats$STDev) + 100) +
  labs("Varying Cycles") +
  scale_linetype_manual(values=c("solid", "solid", "solid", "solid"))+
  scale_shape_manual(values=c(0, 1, 2, 4))+
  scale_color_manual(values=c("#56B4E9", "#009E73", "#D55E00", "#FF6699")) +
  theme_minimal() + 
  theme(legend.position = c(0.5,0.15),
        legend.title = element_text(size = 25),
        legend.text = element_text(size = 25),
        plot.title = element_text(size = 27.5, hjust = 0.5),
        axis.title = element_text(size = 27.5),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size = 12.5),
        legend.background = element_rect(fill = "white", size = 0.5, linetype = "solid", color = "black"),
        text = element_text(size=15))

##############################################################################
# Grid Arrange Duration #
##############################################################################

grid.arrange(dur_plot_0_cycles,dur_plot_var_cycles, dur_plot_1000_cycles, nrow = 1, widths = c(1.3, 1, 2.1))

##############################################################################
# Pow Tot and STD Stats #
##############################################################################

function_results_pow_stats <- function(results_binded) {
  
  Stats = data.frame(Mean = numeric(3), STDev = numeric(3), `Power MW` = numeric(3))
  Stats$Mean = c(# sum(results_binded$Mean[results_binded$`Power MW`== 1]),
                 sum(results_binded$Mean[results_binded$`Power MW`== 10]),
                 sum(results_binded$Mean[results_binded$`Power MW`== 50]),
                 sum(results_binded$Mean[results_binded$`Power MW`== 100])
  )
  Stats$STDev = round(c(# sum(results_binded$STDev[results_binded$`Power MW`== 1]),
                        sum(results_binded$STDev[results_binded$`Power MW`== 10]),
                        sum(results_binded$STDev[results_binded$`Power MW`== 50]),
                        sum(results_binded$STDev[results_binded$`Power MW`== 100])))

  Stats$`Power MW` = c(# 1, 
                       10, 
                       50, 
                       100)
  
  return(Stats)
  
}

##############################################################################
# Power 1000 Cycles Bar Plot #
##############################################################################

pow_1000_cycles_graph = rbind(# MW1_NMC_Graphite_1000_Cycles_Dur_4, 
                              MW10_NMC_Graphite_1000_Cycles_Dur_4, 
                              standard_NMC_Graphite_1000_Cycles, 
                              MW100_NMC_Graphite_1000_Cycles_Dur_4)

pow_1000_cycles_stats = function_results_pow_stats(pow_1000_cycles_graph)

pow_1000_cycles_graph$`Power MW` = as.factor(pow_1000_cycles_graph$`Power MW`)

pow_1000_cycles_stats$`Power MW` = as.factor(pow_1000_cycles_stats$`Power MW`)

pow_plot_1000_cycles = ggplot() +
  geom_bar(data = pow_1000_cycles_graph, aes(x = `Power MW`, y = Mean, fill = Component), stat="identity", width = 0.5) + 
  geom_errorbar(data = pow_1000_cycles_stats, aes(x = `Power MW`, ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.25) +
  # geom_text(data = pow_1000_cycles_graph, aes(x = `Power MW`, y=YPos_Cum, label=Mean),vjust = 1, size = 3) + 
  labs(title = "500 Annual Cycles") + 
  ylab("USD per kWh") +
  ylim(0, max(pow_1000_cycles_stats$Mean) + 2*max(pow_1000_cycles_stats$STDev) + 100) +
  theme_minimal() + 
  # scale_fill_manual(values = test_pal)
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  annotate("text", x = c(# "1", 
                         "10", 
                         "50", 
                         "100"),
           y = c(# sum(pow_1000_cycles_stats$Mean[pow_1000_cycles_stats$`Power MW` == "1"], 2* pow_1000_cycles_stats$STDev[pow_1000_cycles_stats$`Power MW` == "1"]) + 30,
                 sum(pow_1000_cycles_stats$Mean[pow_1000_cycles_stats$`Power MW` == "10"], 2* pow_1000_cycles_stats$STDev[pow_1000_cycles_stats$`Power MW` == "10"]) + 30,
                 sum(pow_1000_cycles_stats$Mean[pow_1000_cycles_stats$`Power MW` == "50"], 2* pow_1000_cycles_stats$STDev[pow_1000_cycles_stats$`Power MW` == "50"]) + 30,
                 sum(pow_1000_cycles_stats$Mean[pow_1000_cycles_stats$`Power MW` == "100"], 2* pow_1000_cycles_stats$STDev[pow_1000_cycles_stats$`Power MW` == "100"]) + 30
           ),
           label = c(# paste(pow_1000_cycles_stats$Mean[pow_1000_cycles_stats$`Power MW` == "1"], "+/-", 2* pow_1000_cycles_stats$STDev[pow_1000_cycles_stats$`Power MW` == "1"]),
                     paste(pow_1000_cycles_stats$Mean[pow_1000_cycles_stats$`Power MW` == "10"], "+/-", 2* pow_1000_cycles_stats$STDev[pow_1000_cycles_stats$`Power MW` == "10"]),
                     paste(pow_1000_cycles_stats$Mean[pow_1000_cycles_stats$`Power MW` == "50"], "+/-", 2* pow_1000_cycles_stats$STDev[pow_1000_cycles_stats$`Power MW` == "50"]),
                     paste(pow_1000_cycles_stats$Mean[pow_1000_cycles_stats$`Power MW` == "100"], "+/-", 2* pow_1000_cycles_stats$STDev[pow_1000_cycles_stats$`Power MW` == "100"])
           )) +
  theme(axis.title.y = element_blank(),
        plot.title = element_text(size = 27.5),
        axis.title = element_text(size = 27.5),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=15),
        legend.title = element_text(size = 27.5),
        legend.text = element_text(size = 27.5))
# pow_plot_1000_cycles


##############################################################################
# Power 0 Cycles Bar Plot #
##############################################################################

pow_0_cycles_graph = rbind(# MW1_NMC_Graphite_0_Cycles_Dur_4, 
                           MW10_NMC_Graphite_0_Cycles_Dur_4, 
                           standard_NMC_Graphite_0_Cycles, 
                           MW100_NMC_Graphite_0_Cycles_Dur_4)

pow_0_cycles_stats = function_results_pow_stats(pow_0_cycles_graph)

pow_0_cycles_graph$`Power MW` = as.factor(pow_0_cycles_graph$`Power MW`)

pow_0_cycles_stats$`Power MW` = as.factor(pow_0_cycles_stats$`Power MW`)

pow_plot_0_cycles = ggplot() +
  geom_bar(data = pow_0_cycles_graph, aes(x = `Power MW`, y = Mean, fill = Component), stat="identity", width = 0.5) + 
  geom_errorbar(data = pow_0_cycles_stats, aes(x = `Power MW`, ymin = Mean - 2* STDev, ymax = Mean + 2* STDev), width = 0.25) +
  # geom_text(data = pow_1000_cycles_graph, aes(x = `Power MW`, y=YPos_Cum, label=Mean),vjust = 1, size = 3) + 
  labs(title = "0 Annual Cycles") + 
  ylab("USD per kWh") +
  ylim(0, max(pow_1000_cycles_stats$Mean) + 2*max(pow_1000_cycles_stats$STDev) + 100) +
  theme_minimal() + 
  # scale_fill_manual(values = test_pal)
  # scale_fill_brewer(palette = "Spectral") +
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  annotate("text", x = c(# "1", 
                         "10", 
                         "50", 
                         "100"),
           y = c(# sum(pow_0_cycles_stats$Mean[pow_0_cycles_stats$`Power MW` == "1"], 2* pow_0_cycles_stats$STDev[pow_0_cycles_stats$`Power MW` == "1"]) + 30,
                 sum(pow_0_cycles_stats$Mean[pow_0_cycles_stats$`Power MW` == "10"], 2* pow_0_cycles_stats$STDev[pow_0_cycles_stats$`Power MW` == "10"]) + 30,
                 sum(pow_0_cycles_stats$Mean[pow_0_cycles_stats$`Power MW` == "50"], 2* pow_0_cycles_stats$STDev[pow_0_cycles_stats$`Power MW` == "50"]) + 30,
                 sum(pow_0_cycles_stats$Mean[pow_0_cycles_stats$`Power MW` == "100"], 2* pow_0_cycles_stats$STDev[pow_0_cycles_stats$`Power MW` == "100"]) + 30
           ),
           label = c(# paste(pow_0_cycles_stats$Mean[pow_0_cycles_stats$`Power MW` == "1"], "+/-", 2* pow_0_cycles_stats$STDev[pow_0_cycles_stats$`Power MW` == "1"]),
                     paste(pow_0_cycles_stats$Mean[pow_0_cycles_stats$`Power MW` == "10"], "+/-", 2* pow_0_cycles_stats$STDev[pow_0_cycles_stats$`Power MW` == "10"]),
                     paste(pow_0_cycles_stats$Mean[pow_0_cycles_stats$`Power MW` == "50"], "+/-", 2* pow_0_cycles_stats$STDev[pow_0_cycles_stats$`Power MW` == "50"]),
                     paste(pow_0_cycles_stats$Mean[pow_0_cycles_stats$`Power MW` == "100"], "+/-", 2* pow_0_cycles_stats$STDev[pow_0_cycles_stats$`Power MW` == "100"])
           )) +
  theme(legend.position = "none",
        plot.title = element_text(size = 27.5),
        axis.title = element_text(size = 27.5),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=15))
# pow_plot_0_cycles

##############################################################################
# Power Cycles Plot #
##############################################################################

pow_var_cycles_graph = rbind(# MW1_NMC_Graphite_cost_per_cycles_Dur_4,
                             MW10_NMC_Graphite_cost_per_cycles_Dur_4,
                             standard_NMC_Graphite_cost_per_cycles,
                             MW100_NMC_Graphite_cost_per_cycles_Dur_4)

pow_var_cycles_graph$Power.MW = as.character(pow_var_cycles_graph$Power.MW)

colnames(pow_var_cycles_graph) = c("Tot", 
                                   "STDev",
                                   "5th P",
                                   "95th P",
                                   "Component", 
                                   "temp", 
                                   "YPos_Cum", 
                                   "YPos_Ind",
                                   "City",
                                   "State",
                                   "Capacity.MWh",
                                   "Power.MW",
                                   "Duration (Hrs)",
                                   "Year",
                                   "Lifespan.Yr",
                                   "Chemistry",
                                   "Fire.Suppression",
                                   "Cycles.per.Year",
                                   "Depth.of.Discharge",
                                   "Tot 5th P",
                                   "Tot 95th P"
)

pow_plot_var_cycles = ggplot(data = pow_var_cycles_graph) +
  geom_line(aes(x = Cycles.per.Year, y = Tot, group = `Power.MW`, color = `Power.MW`), size = 0.5) +
  geom_point(aes(x = Cycles.per.Year, y = Tot, group = `Power.MW`, shape = `Power.MW`, color = `Power.MW`), size = 2) + 
  xlab("Expected Annual Cycles") +
  ylab("USD per kWh") +
  labs(title = "Varying Cycles") +
  ylim(0,max(pow_1000_cycles_stats$Mean) + 2*max(pow_1000_cycles_stats$STDev) + 100) +
  labs("60 MW / 240 MWh, Cost vs Annual Cycles") +
  scale_linetype_manual(values=c("solid", "solid", "solid"))+
  scale_shape_manual(values=c(0, 1, 2, 4))+
  scale_color_manual(values=c("#56B4E9", "#009E73", "#D55E00")) +
  theme_minimal() + 
  theme(legend.position = c(0.5,0.25),
        legend.title = element_text(size = 25),
        legend.text = element_text(size = 25),
        plot.title = element_text(size = 27.5, hjust = 0.5),
        axis.title = element_text(size = 27.5),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size = 12.5),
        legend.background = element_rect(fill = "white", size = 0.5, linetype = "solid", color = "black"),
        text = element_text(size=15)) # + 
# scale_color_manual(values=c("#FF0000", "#FF9966", "#99FF99", "#0066CC"))
# pow_plot_var_cycles


chem_plot_var_cycles = ggplot(data = chem_var_cycles_graph) +
  geom_line(aes(x = Cycles.per.Year, y = Tot, group = Chemistry, linetype = Chemistry, color = Chemistry), size = 0.5) + # ,color = Chemistry
  geom_point(aes(x = Cycles.per.Year, y = Tot, group = Chemistry, shape = Chemistry, color = Chemistry), size = 2) + 
  xlab("Expected Annual Cycles") +
  ylab("USD per kWh") +
  labs(title = "Varying Cycles") +
  ylim(0,max(chem_1000_cycles_stats$Mean) + 2*max(chem_1000_cycles_stats$STDev) + 100) +
  labs("60 MW / 240 MWh, Cost vs Annual Cycles") +
  scale_linetype_manual(values=c("solid", "solid", "solid"))+
  scale_shape_manual(values=c(0, 1, 2, 4))+
  scale_color_manual(values=c("#56B4E9", "#009E73", "#D55E00")) +
  theme_minimal() + 
  theme(legend.position = c(0.5,0.25),
        legend.title = element_text(size = 25),
        legend.text = element_text(size = 25),
        plot.title = element_text(size = 27.5, hjust = 0.5),
        axis.title = element_text(size = 27.5),
        axis.title.y = element_blank(),
        axis.text.x = element_text(size = 12.5),
        legend.background = element_rect(fill = "white", size = 0.5, linetype = "solid", color = "black"),
        text = element_text(size=15))



##############################################################################
# Grid Arrange Power #
##############################################################################

grid.arrange(pow_plot_0_cycles, pow_plot_var_cycles, pow_plot_1000_cycles, nrow = 1, widths = c(1.3, 1, 2.1))



##############################################################################
# CalPeak Power - Eneterprise Plant # 
##############################################################################

runs = 10000

standard_NCA_Graphite_1000_Cycles = function_monte_carlo_plot("Average",
                                                              "National",
                                                              120,
                                                              4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                              2020,
                                                              10, # [15, 20],
                                                              "NCA Graphite",
                                                              2001,
                                                              28,
                                                              0.95,
                                                              runs,
                                                              "Yes",
                                                              51)
standard_NCA_Graphite_1000_Cycles = standard_NCA_Graphite_1000_Cycles[[1]]

standard_NMC_Graphite_1000_Cycles = function_monte_carlo_plot("Average",
                                                              "National",
                                                              120,
                                                              4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                              2020,
                                                              10, # [15, 20],
                                                              "NMC Graphite",
                                                              2001,
                                                              28,
                                                              0.95,
                                                              runs,
                                                              "Yes",
                                                              51)
standard_NMC_Graphite_1000_Cycles = standard_NMC_Graphite_1000_Cycles[[1]]

standard_LFP_Graphite_1000_Cycles = function_monte_carlo_plot("Average",
                                                              "National",
                                                              120,
                                                              4, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                                                              2020,
                                                              10, # [15, 20],
                                                              "LFP Graphite",
                                                              2001,
                                                              28,
                                                              0.95,
                                                              runs,
                                                              "Yes",
                                                              51)
standard_LFP_Graphite_1000_Cycles = standard_LFP_Graphite_1000_Cycles[[1]]





chem_1000_cycles_graph = rbind(standard_NCA_Graphite_1000_Cycles, 
                               standard_NMC_Graphite_1000_Cycles, 
                               standard_LFP_Graphite_1000_Cycles #, 
                               #standard_LMO_Graphite_1000_Cycles
)

chem_1000_cycles_stats = function_results_chem_stats(chem_1000_cycles_graph)

chem_plot_1000_cycles = ggplot() +
  geom_bar(data = chem_1000_cycles_graph, aes(x = Chemistry, y = Mean, fill = Component), stat="identity", width = 0.5) + 
  geom_errorbar(data = chem_1000_cycles_stats, aes(x = Chemistry, ymin = Mean - 2 * STDev, ymax = Mean + 2 * STDev), width = 0.375, size = 1) +
  # geom_text(data = chem_1000_cycles_graph, aes(x = Chemistry, y=YPos_Cum, label=Mean),vjust = 1, size = 3) + 
  labs(title = "CalPeak Power - Enterprise CapEx") + 
  ylab("USD per kWh") +
  ylim(0, max(chem_1000_cycles_stats$Mean) + 2*max(chem_1000_cycles_stats$STDev) + 100) +
  theme_minimal() + 
  scale_fill_manual(values = cbpalette, labels = c("Dev. Costs", "Sales Tax", "Inst. and Labor", "Struct. BOS", "Elec. BOS", "Cont. BOS", "Inverter", "Battery")) +
  # scale_fill_brewer(palette = "Spectral") +
  annotate("text", x = c("NCA Graphite", "NMC Graphite", "LFP Graphite"),
           y = c(sum(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "NCA Graphite"], 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "NCA Graphite"]) + 30,
                 sum(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "NMC Graphite"], 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "NMC Graphite"]) + 30,
                 sum(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "LFP Graphite"], 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "LFP Graphite"]) + 30 #,
                 # sum(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "LMO Graphite"], 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "LMO Graphite"]) + 30
           ),
           label = c(paste(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "NCA Graphite"], "+/-", 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "NCA Graphite"]),
                     paste(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "NMC Graphite"], "+/-", 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "NMC Graphite"]),
                     paste(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "LFP Graphite"], "+/-", 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "LFP Graphite"]) #,
                     # paste(chem_1000_cycles_stats$Mean[chem_1000_cycles_stats$Chemistry == "LMO Graphite"], "+/-", 2 * chem_1000_cycles_stats$STDev[chem_1000_cycles_stats$Chemistry == "LMO Graphite"])
           ),
           size = 5.5
  ) +
  theme(# axis.title.y = element_blank(),
        plot.title = element_text(size = 27.5),
        axis.title = element_text(size = 27.5),
        axis.text.x = element_text(size = 12.5),
        text = element_text(size=15),
        legend.title = element_text(size = 27.5),
        legend.text = element_text(size = 27.5))





