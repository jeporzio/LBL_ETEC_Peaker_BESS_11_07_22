
##############################################################################
# Notes #
##############################################################################

# v1 (06/17/21) : Start - Pseudo Code


##############################################################################
# Libraries, Clear, and Runs #
##############################################################################

rm(list = ls())

runs = 5 # might need to delete
runs_2 = 5 # might need to delete

library(readxl)
library(ggplot2)
library(RColorBrewer)
library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

##############################################################################
# Data Loading and Cleaning#
##############################################################################

plant_size_raw_RTE85 = read_excel("opt_results/opt_results_june17_RTE85.xlsx", 
                                  sheet = "BatterySizing")

# ADD RTE80 AND RTE90 ONCE DATA AVAILABLE #


# read load profile (if this is an issue can just sum load profile and read sums)
load_profiles_raw = read_excel("opt_results/load_data_v3.xlsx")
load_profiles_size = dim(load_profiles_raw)
load_profiles_raw = load_profiles_raw[,3:load_profiles_size[2]]

feas_plant = c(30,31,32,33,48,56,57,58,59,75,98,107,138,139,140,141,142,146,147,
               148,149,150,151,152,153,154,155,156,160,161,166,168,169,170,177,
               178,192,194,195,196,198,205,206,208,213,215,216,221,222,223,224,
               225,226,227,244,257,258,259)
load_data = data.frame(matrix(NA, nrow = load_profiles_size[1], ncol = load_profiles_size[2]))
count = 1

for(i in 1:((load_profiles_size[2]-2)/2)) {
  
  load_data[,i] = load_profiles_raw[,count] * load_profiles_raw[,count+1]
  count = count+2

}

load_data = load_data[,feas_plant]
# load_data[is.na(load_data)] = 0

real_plants = c(1:10, 12:56)
fake_plants = c(11, 57, 58)

##############################################################################
# Annual Cycles Function #
##############################################################################

# function inputs:
#   Load profile
#   plant_size_pre_deg

func_annual_cycles <- function(load, plant_size) {
  
  load = as.numeric(load)
  plant_size = as.numeric(plant_size)
  
  throughput = sum(load)
  tot_cycles = throughput/plant_size
  hours = length(load)
  ann_cycles = tot_cycles / (hours/8760)
  ann_cycles = round(ann_cycles,0)

  return(ann_cycles)
  
}

# sum load profile
# divid sum by plant size pre deg
# divide by number of years (hours / 8760)

# function outputs:
#   eq cycles per year

##############################################################################
# Battery Sizing Function #
##############################################################################

# funtion inputs: 
#   Battery chem
#   Duration/DoD
#   Cycles per year





# function outputs
#   adjusted battery size
#   all material quantities


##############################################################################
# Run Annual Cycles Function for all Plants #
##############################################################################

load_data_size = dim(load_data)
eq_plant_cycles = rep(0,load_data_size[2])

for (i in real_plants) {
  
  tload = load_data[,i]
  tsize = plant_size_raw_RTE85[i,2]
  
  eq_plant_cycles[i] = func_annual_cycles(tload,tsize)
  
}

count = 1
fake_plant_start = c(1, 19705, 19705)
fake_plant_end = c(17520, 24096, 24096)

for (i in fake_plants) {
  
  idx_start = fake_plant_start[count]
  idx_end = fake_plant_end[count]
  
  tload = load_data[idx_start:idx_end,i]
  tsize = plant_size_raw_RTE85[i,2]
  
  eq_plant_cycles[i] = func_annual_cycles(tload,tsize)
  count = count+1
  
}

##############################################################################
# Run Battery Sizing Function for all Plants #
##############################################################################







