#-----------------------------------------------------------------------------
# peaker mapping #
#-----------------------------------------------------------------------------

# Notes started 05/19

# working directory: /Documents/Shell Research/peaker replacement/cost_model_8_30_21

#-----------------------------------------------------------------------------
# Libraries, Clear #
#-----------------------------------------------------------------------------

rm(list = ls()) # remove for final version

library(readxl)
library(ggplot2)
library(RColorBrewer)
library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)
library(rcartocolor)
library(stringr)
library(plyr)
library(matrixStats)
library(CVXR)
# library(gurobi)
library(ggpubr)
library(openxlsx)

# mapping packages
library(maptools)
library(RColorBrewer)
library(classInt)
library(maps)
library(binovisualfields)

color_one = "darkgrey"
color_two = "red"

scaling_factor = (1.15)
scaling_mult = 1/25

#-----------------------------------------------------------------------------
# colorRampPaletteAlpha function #
#-----------------------------------------------------------------------------

# addalpha()
addalpha <- function(colors, alpha=1.0) {
  r <- col2rgb(colors, alpha=T)
  # Apply alpha
  r[4,] <- alpha*255
  r <- r/255.0
  return(rgb(r[1,], r[2,], r[3,], r[4,]))
}

# colorRampPaletteAlpha()
colorRampPaletteAlpha <- function(colors, n=32, interpolate='linear') {
  # Create the color ramp normally
  cr <- colorRampPalette(colors, interpolate=interpolate)(n)
  # Find the alpha channel
  a <- col2rgb(colors, alpha=T)[4,]
  # Interpolate
  if (interpolate=='linear') {
    l <- approx(a, n=n)
  } else {
    l <- spline(a, n=n)
  }
  l$y[l$y > 255] <- 255 # Clamp if spline is > 255
  cr <- addalpha(cr, l$y/255.0)
  return(cr)
}



colorRampAlpha <- function(..., n, alpha) {
  colors <- colorRampPalette(...)(n)
  paste(colors, sprintf("%x", ceiling(255*alpha)), sep="")
}



#-----------------------------------------------------------------------------
# Data Loading and cleaning #
#-----------------------------------------------------------------------------
# colors function

mycol <- function(x, myrange, n=100) round( 1+(x-myrange[1])/diff(myrange) * (n-1))
colfunc <- colorRampPalette(c(color_one, color_two), alpha=0.5) # opt 1
n = 100


# load data
plants_raw = read_excel("BatteryCandidates-AllWest.xlsx")

plants_raw = plants_raw[order(plants_raw$maxLoad*-1),]
plants_raw$dPerMWh = log(plants_raw$dPerMWh) # uncomment this line for color adjustment

plants_raw = plants_raw[plants_raw$state=="CA",]

pre_maxLoad = plants_raw$maxLoad
pre_dPerMWh = plants_raw$dPerMWh

# plants_infeas = plants_raw[plants_raw$op_prop > quantile(plants_raw$op_prop, 0.25) | plants_raw$maxSpellMWh > 1200,] # adjust these until 19 plants in feas_keep
plants_infeas = plants_raw[plants_raw$op_prop > quantile(plants_raw$op_prop, 0.25) | plants_raw$maxSpellMWh > 1200,] # adjust these until 19 plants in feas_keep

plants_feas = plants_raw[plants_raw$op_prop <= quantile(plants_raw$op_prop, 0.25) & plants_raw$maxSpellMWh <= 1200,] # adjust these until 19 plants in feas_keep

map_colors = colfunc(n)[mycol(plants_feas$dPerMWh, range(plants_feas$dPerMWh), n)]
map_colors_trans = adjustcolor(map_colors, alpha.f = 0.3)

plants_feas = cbind(plants_feas, map_colors,map_colors_trans)


plants_feas_keep = plants_feas[plants_feas$keep==1,]
plants_feas_nokeep = plants_feas[plants_feas$keep==0,]
  
  

plants_ca = plants_raw[plants_raw$state=="CA",]

#-----------------------------------------------------------------------------
# Plotting #
#-----------------------------------------------------------------------------

# testing

map(database='state',regions=c("California"),col="black", lwd=1, resolution=.1)
# points(plants_infeas$longitude, plants_infeas$latitude, pch=21, lwd=2, 
#        cex=scaling_mult*(plants_infeas$maxLoad)^scaling_factor, # (plants_infeas$maxLoad/avg_plant_size), 
#        bg=plants_infeas$map_colors_trans)
points(plants_feas_nokeep$longitude, plants_feas_nokeep$latitude, pch=21, lwd=2, 
       cex=scaling_mult*(plants_feas_nokeep$maxLoad)^scaling_factor, # (plants_raw$maxLoad/avg_plant_size), 
       bg=plants_feas_nokeep$map_colors_trans)
points(plants_feas_keep$longitude, plants_feas_keep$latitude, pch=23, lwd=2, 
       cex=scaling_mult*(plants_feas_keep$maxLoad)^scaling_factor, # (plants_feas_keep$maxLoad/avg_plant_size), 
       bg=plants_feas_keep$map_colors_trans)
rect(xleft = -119.17, xright = -114.055, ytop = 42.01, ybottom = 36, col = "white")

mylist <- (c(10, 500, 1000))
legend_colors = colfunc(n)[mycol(mylist, range(mylist), n)]
mylist = c(0, 175, 350)
legend_colors_trans = adjustcolor(legend_colors, alpha.f = 0.5)
legend(x = -119.15, y = 42, title="Damages (USD per MWh)", legend=mylist, col="black",
       pch=21, cex = 1.25, 
       pt.cex = 3, pt.bg = legend_colors_trans, pt.lwd = 2,
       x.intersp = 2,
       box.lwd = 0)

mylist_size = c(10,40,70)
legend(x = -118.45, y = 40.125 ,title="Rated Power (MW)", legend=mylist_size, col="black",
       pch=21, cex = 1.25, 
       pt.cex = c(1,3,5.5), pt.lwd = 2,
       y.intersp = c(1, 1, 1.175), x.intersp = 2,
       box.lwd = 0)

mylist_shape = c("Not Studied","Studied")
legend(x = -118.65, y = 37.85, ,title="In Study", legend=mylist_shape, col="black",
       pch=c(21, 23), cex = 1.25, 
       pt.cex = 3, pt.lwd = 2,
       y.intersp = 1.2, x.intersp = 2,
       box.lwd = 0)





# testing

map(database='state',regions=c("California"),col="black", lwd=0, resolution=.1)
# points(plants_ca_nokeep$longitude, plants_ca_nokeep$latitude, pch=21, lwd=2, 
#        cex=plants_ca_nokeep$maxLoad, # (plants_ca_nokeep$maxLoad/avg_plant_size), 
#        bg=plants_ca_nokeep$map_colors_trans)
# points(plants_ca_keep$longitude, plants_ca_keep$latitude, pch=23, lwd=2, 
#        cex=plants_ca_keep$maxLoad, # (plants_ca_keep$maxLoad/avg_plant_size), 
#        bg=plants_ca_keep$map_colors_trans)

rect(xleft = -119.015, xright = -114.3, ytop = 42.01, ybottom = 36.3, col = "white")

mylist <- (c(10, 500, 1000))
legend_colors = colfunc(n)[mycol(mylist, range(mylist), n)]
legend_colors_trans = adjustcolor(legend_colors, alpha.f = 0.5)
legend(x = -119, y = 42, title="Damages (USD per MWh)", legend=mylist, col="black",
       pch=21, cex = 1.25, 
       pt.cex = 3, pt.bg = legend_colors_trans, pt.lwd = 2,
       x.intersp = 2,
       box.lwd = 0)

mylist_size = c(10,100,1000)
legend(x = -118.3, y = 40.15 ,title="Peaker Size (MW)", legend=mylist_size, col="black",
       pch=21, cex = 1.25, 
       pt.cex = c(1,3,6), pt.lwd = 2,
       y.intersp = c(1, 1, 1.175), x.intersp = 2,
       box.lwd = 0)

mylist_shape = c("Not Feasible","Feasible")
legend(x = -118.75, y = 38, ,title="Replacement Feasibility", legend=mylist_shape, col="black",
       pch=c(21, 23), cex = 1.25, 
       pt.cex = 3, pt.lwd = 2,
       y.intersp = 1.2, x.intersp = 2,
       box.lwd = 0)






# 
# # load map - ca
# 
# 
# 
# map_colors = colfunc(n)[mycol(plants_ca$mDamageTotal, range(plants_ca$mDamageTotal), n)]
# map_colors_trans = adjustcolor(map_colors, alpha.f = 0.5)
# map(database='state',regions=c("California"),col="black", lwd=1, resolution=.1)
# points(plants_ca$longitude, plants_ca$latitude, pch=21, lwd=1, 
#        cex=(plants_ca$maxLoad)/(mean((plants_ca$maxLoad)) - 0*sd((plants_ca$maxLoad))), 
#        bg=map_colors_trans)
# 
# 
# # load map - ca feas
# 
# map_colors = colfunc(n)[mycol(plants_ca_feas$mDamageTotal, range(plants_ca_feas$mDamageTotal), n)]
# map_colors_trans = adjustcolor(map_colors, alpha.f = 0.5)
# map(database='state',regions=c("California"),col="black", lwd=1, resolution=.1)
# points(plants_ca_feas$longitude, plants_ca_feas$latitude, pch=21, lwd=.4, 
#        cex=(plants_ca_feas$maxLoad)/(mean((plants_ca_feas$maxLoad)) - 2*sd((plants_ca_feas$maxLoad))), 
#        bg=map_colors_trans,
#        col = plants_ca_feas$keep)
# mylist <- exp(c(min(plants_ca_feas$mDamageTotal), median(plants_ca_feas$mDamageTotal), max(plants_ca_feas$mDamageTotal)))/10^6
# legend("topright",title="Damages (Million USD)", legend=mylist, col = c(map_colors_trans[1], map_colors_trans[length(map_colors_trans)/2], map_colors_trans[length(map_colors_trans)]), pch=20)
# 
# 
# # load map - ca keep
# 
# map_colors = colfunc(n)[mycol(plants_ca$mDamageTotal, range(plants_ca$mDamageTotal), n)]
# map_colors_trans = adjustcolor(map_colors, alpha.f = 0.5)
# map(database='state',regions=c("California"),col="black", lwd=1, resolution=.1)
# points(plants_ca$longitude, plants_ca$latitude, pch=21, lwd=.4, 
#        cex=(plants_ca$maxLoad)/(mean((plants_ca$maxLoad)) - 0*sd((plants_ca$maxLoad))), 
#        bg=map_colors_trans,
#        col = plants_ca$keep)
# 
# 
# mylist <- exp(c(min(plants_ca$mDamageTotal), median(plants_ca$mDamageTotal), max(plants_ca$mDamageTotal)))/10^6
# legend("topright",title="Damages (Million USD)", legend=mylist, col = c(map_colors_trans[1], map_colors_trans[length(map_colors_trans)/2], map_colors_trans[length(map_colors_trans)]), pch=20)
# 
# 
# 
# 
# 
