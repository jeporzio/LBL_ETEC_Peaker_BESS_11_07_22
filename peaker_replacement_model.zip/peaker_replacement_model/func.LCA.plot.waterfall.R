#------------------------------------------------------------------------------
# func_LCA_plot_waterfall #
#------------------------------------------------------------------------------

# Used to clean LCA outputs from func.monte.carlo.plot for plotting

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------

function_LCA_plot_waterfall <- function(df_LCA, df_losses, unicorn, peaker_name, pollutant, df_damages, peaker_name_short) {
  
  # currently only for GWP
  
  # delete below #
  # 
  # df_LCA = long_beach_1[[3]]
  # df_losses = long_beach_1[[11]]
  # unicorn = 1 # [0: indicates non-unicorn numbers, 1: indicates unicorn (idealized) numbers)]
  # peaker_name = "Long Beach Generating Station - Unit 1"
  # pollutant = "GWP" #  [GWP: just CO2; NOx; SOx; PM25]
  # df_damages = batt_damages_raw
  # peaker_name_short = "Long Beach 1"

  # delete above #
  
  nonunicorn_damages = read_excel("batt_damages_02_15_22.xlsx")


  if (unicorn==0 & pollutant == "GWP") {

    df_LCA$Mean[df_LCA$Component=="purchased.electricity.cycle"] = nonunicorn_damages$CO2T_DIFF_OtherPlant[nonunicorn_damages$peaker_name==peaker_name] * 1000 * Lifetime
    df_LCA$STDev[df_LCA$Component=="purchased.electricity.cycle"] = 0 # temp

    df_LCA$Mean[df_LCA$Component=="sold.electricity.cycle"] = nonunicorn_damages$CO2T_DIFF_ReplacedPlant[nonunicorn_damages$peaker_name==peaker_name] * 1000 * Lifetime
    df_LCA$STDev[df_LCA$Component=="sold.electricity.cycle"] = 0

  } else if (unicorn==0 & pollutant == "NOx") { # fill these in if needed. not needed rn



  } else if (unicorn==0 & pollutant == "SOx") {



  } else if (unicorn==0 & pollutant == "PM25") {



  }

  
  # convert to kt
  
  df_LCA$Mean = df_LCA$Mean/1000/1000 # /(10^6)
  df_LCA$STDev = df_LCA$STDev/1000/1000 # /(10^6)
  df_LCA$`5th P` = df_LCA$`5th P`/1000/1000 # /(10^6)
  df_LCA$`95th P` = df_LCA$`95th P`/1000/1000 # /(10^6)
  
  
  dim_df_LCA = dim(df_LCA)
  
  plot_categories = unique(df_LCA$Category)
  df_categories = data.frame(matrix(NA, nrow = length(plot_categories), ncol = dim_df_LCA[2]-1))
  colnames(df_categories) = c("Mean", "STDev", "5th P", "95th P", "Category")
  
  results = vector(mode = "list", length = length(plot_categories) + 1)
  
  for (i in 1:length(plot_categories)) {
    
    #df creation for each category - has values for each component in each category
    assign(paste("df",plot_categories[i], sep = "_"), df_LCA[df_LCA$Category == plot_categories[i],])
    
    df_categories$Mean[i] = sum(df_LCA$Mean[df_LCA$Category==plot_categories[i]])
    df_categories$STDev[i] = sum(df_LCA$STDev[df_LCA$Category==plot_categories[i]])
    df_categories$`5th P`[i] = sum(df_LCA$`5th P`[df_LCA$Category==plot_categories[i]])
    df_categories$`95th P`[i] = sum(df_LCA$`95th P`[df_LCA$Category==plot_categories[i]])
    df_categories$Category[i] = str_replace(plot_categories[i], "_", " ")
    
    results[[i+1]] = get(paste("df",plot_categories[i], sep = "_"))
    
  }
  
  results[[1]] = df_categories
  
  
  
  ### change system_other_list to change what's included in other ###
  
  system_other_list = c("inverter.count", "Switchgear.count", "Conductor.ft",
                        "Conduit.ft", "Battcont.cont", "Invcont.cont",
                        "Found.quant", "Rack.cont")
  
  system_oth_mean = 0
  system_oth_STDev = 0
  system_oth_5thP = 0
  system_oth_95thP = 0
  system_oth_row = rep(NA,6)
  
  for (j in system_other_list) {
    
    system_oth_mean = system_oth_mean + results[[3]]$Mean[results[[3]]$Component==j]
    system_oth_STDev = system_oth_STDev + results[[3]]$STDev[results[[3]]$Component==j]
    system_oth_5thP = system_oth_5thP + results[[3]]$`5th P`[results[[3]]$Component==j]
    system_oth_95thP = system_oth_95thP + results[[3]]$`95th P`[results[[3]]$Component==j]
    
    results[[3]] = results[[3]][!(results[[3]]$Component==j),]
    
  }
  
  system_row_names = row.names(results[[3]])
  results[[3]] = rbind(results[[3]], system_oth_row)
  row.names(results[[3]]) = c(system_row_names, "Other BOS")
  
  results[[3]]["Other BOS",]$Mean = system_oth_mean
  results[[3]]["Other BOS",]$STDev = system_oth_STDev
  results[[3]]["Other BOS",]$`5th P` = system_oth_5thP
  results[[3]]["Other BOS",]$`95th P` = system_oth_95thP
  results[[3]]["Other BOS",]$Component = "Other BOS"
  results[[3]]["Other BOS",]$Category = "BOS_Materials"
  
  
  
  ### change battery_other_list to change what's included in other ###
  
  batt_other_list = c("BMS.kg", "LiPF6.kg", "PVFD.kg", "ethylene.carbonate.kg", 
                      "dimethyl.carbonate.kg", "HDPE.kg", "PP.kg", "PET.kg", 
                      "NMP.kg", "carbon.black.kg", "copper.kg", "aluminum.virgin.wrought.kg")
  
  batt_oth_mean = 0
  batt_oth_STDev = 0
  batt_oth_5thP = 0
  batt_oth_95thP = 0
  batt_oth_row = rep(NA,6)
  
  for (k in batt_other_list) {
    
    batt_oth_mean = batt_oth_mean + results[[4]]$Mean[results[[4]]$Component==k]
    batt_oth_STDev = (batt_oth_STDev^2 + results[[4]]$STDev[results[[4]]$Component==k]^2)^0.5
    batt_oth_5thP = batt_oth_5thP + results[[4]]$`5th P`[results[[4]]$Component==k]
    batt_oth_95thP = batt_oth_95thP + results[[4]]$`95th P`[results[[4]]$Component==k]
    
    results[[4]] = results[[4]][!(results[[4]]$Component==k),]
    
  }
  
  batt_row_names = row.names(results[[4]])
  results[[4]] = rbind(results[[4]], batt_oth_row)
  row.names(results[[4]]) = c(batt_row_names, "Other Battery Materials")
  
  results[[4]]["Other Battery Materials",]$Mean = batt_oth_mean
  results[[4]]["Other Battery Materials",]$STDev = batt_oth_STDev
  results[[4]]["Other Battery Materials",]$`5th P` = batt_oth_5thP
  results[[4]]["Other Battery Materials",]$`95th P` = batt_oth_95thP
  results[[4]]["Other Battery Materials",]$Component = "Other Battery Materials"
  results[[4]]["Other Battery Materials",]$Category = "Battery_Materials"
  
  results[[7]] = rbind(results[[2]], results[[3]], results[[4]], results[[5]], results[[6]])
  
  # renaming items for graphing
  
  results[[7]][results[[7]]=="Battery_Assembly"] = "Module Materials & Assembly" #"Battery Assembly"
  results[[7]][results[[7]]=="BOS_Materials"] = "Energy Storage BOS"
  results[[7]][results[[7]]=="Battery_Materials"] = "Module Materials & Assembly"
  results[[7]][results[[7]]=="Purchased_Electricity"] = "Battery Charging & Losses" # "Purchased Electricity"
  results[[7]][results[[7]]=="Sold_Electricity"] = "Offset Electricity" # "Offset Electricity"
  
  results[[7]][results[[7]]=="battery.assembly.kWh"] = "Battery Assembly"
  results[[7]][results[[7]]=="transformer.count"]  = "Transformer"
  results[[7]][results[[7]]=="Fire.cont"] = "Fire Suppression"
  results[[7]][results[[7]]=="HVAC.cont"] = "HVAC"
  results[[7]][results[[7]]=="graphite.kg"] = "Graphite"
  results[[7]][results[[7]]=="copper.kg"] = "Copper"
  results[[7]][results[[7]]=="aluminum.virgin.wrought.kg"] = "Aluminum"
  results[[7]][results[[7]]=="purchased.electricity.cycle"] = "Battery Charging & Losses"
  results[[7]][results[[7]]=="sold.electricity.cycle"] = "Offset Electricity"
  
  results[[7]][results[[7]]=="NCA.kg"] = "NCA Cathode"
  results[[7]][results[[7]]=="LFP-HT.kg"] = "LFP Cathode (Hydrothermal Prod.)"
  results[[7]][results[[7]]=="NMC-811.kg"] = "NMC-811 Cathode"
  results[[7]][results[[7]]=="LMO.kg"] = "LMO Cathode"
  results[[7]][results[[7]]=="NMC-111.kg"] = "NMC-111 Cathode"
  results[[7]][results[[7]]=="NMC-532,kg"] = "NMC-532 Cathode"
  results[[7]][results[[7]]=="NMC-622.kg"] = "NMC-622 Cathode"
  results[[7]][results[[7]]=="NMC-811.kg"] = "NMC-811 Cathode"
  results[[7]][results[[7]]=="LFP-SS.kg"] = "LFP Cathode"
  
  
  batt_factor = ceiling(Lifetime / Lifespan)
  results[[7]]$Mean[results[[7]]$Category=="Module Materials & Assembly"] = results[[7]]$Mean[results[[7]]$Category=="Module Materials & Assembly"] * batt_factor
  results[[7]]$STDev[results[[7]]$Category=="Module Materials & Assembly"] = ((results[[7]]$STDev[results[[7]]$Category=="Module Materials & Assembly"])^2 * batt_factor)^0.5
  
  results[[7]]$Mean[results[[7]]$Component=="Offset Electricity"] =  results[[7]]$Mean[results[[7]]$Component=="Offset Electricity"] # * -1
  
  
  
  results[[8]] = subset(results[[7]], select = -c(Component, `5th P`, `95th P`))
  temp_results8 = results[[8]]
  results[[8]] = ddply(results[[8]], "Category", numcolwise(sum))
  
  for (m in unique(results[[8]]$Category)) {
    
    results[[8]]$STDev[results[[8]]$Category==m]= sum(temp_results8$STDev[temp_results8$Category==m]^2)^0.5
    
  }
  
  
  
  cathode_name = results[[7]][results[[7]]$Category=="Module Materials & Assembly",]
  cathode_name = cathode_name$Component[!(cathode_name$Component=="Battery Assembly" | cathode_name$Component=="Graphite" | cathode_name$Component=="Other Battery Materials")]
  
  eff_losses = results[[7]]$Mean[results[[7]]$Component=="Battery Charging & Losses"] *(1 - (1 - df_losses["Transformer","Mean"])^2 * (1 - df_losses["Inverter","Mean"])^2  * (1 - df_losses["Battery","Mean"])^2 * (1 - df_losses["Thermal","Mean"])^2 * (1 - df_losses["Misc.","Mean"])^2) 
  
  eff_losses_std = eff_losses * sqrt(2 * (df_losses["Transformer","STDev"]/df_losses["Transformer","Mean"])^2 + 
                                       2 * (df_losses["Transformer","STDev"]/df_losses["Inverter","Mean"])^2 + 
                                       2 * (df_losses["Transformer","STDev"]/df_losses["Battery","Mean"])^2 +
                                       2 * (df_losses["Transformer","STDev"]/df_losses["Thermal","Mean"])^2 +
                                       2 * (df_losses["Transformer","STDev"]/df_losses["Misc","Mean"])^2)
  
  df_eff_losses = data.frame(c(eff_losses), c(eff_losses_std), c(NA), c(NA), c("Energy Losses"), c("Battery Charging & Losses"))
  colnames(df_eff_losses) = colnames(results[[7]])
  
  results[[7]] = rbind(results[[7]], df_eff_losses)
  row.names(results[[7]]) = c("Battery Assembly", "Transformer", "Fire Suppression", "HVAC", "Other BOS", "LFP Cathode", "Graphite", "Other Battery Materials", "Battery Charging & Losses", "Offset Electricity", "Energy Losses")
  
  results[[7]]["Battery Charging & Losses", "Mean"] = results[[7]]["Battery Charging & Losses", "Mean"] - results[[7]]["Energy Losses", "Mean"]
  # results[[7]]["Battery Charging & Losses", "STDev"] = (results[[7]]["Battery Charging & Losses", "STDev"]^2 + results[[7]]["Losses", "STDev"]^2)^0.5
  
  results[[8]]$STDev[results[[8]]$Category=="Battery Charging & Losses"] = (results[[7]]["Battery Charging & Losses", "STDev"]^2 + results[[7]]["Energy Losses", "STDev"]^2)^0.5
  
  
  # might need to delete these two lines
  results[[7]]$Category = factor(results[[7]]$Category, levels = c("Module Materials & Assembly", "Energy Storage BOS", "Battery Charging & Losses", "Offset Electricity"))
  results[[7]]$Component = factor(results[[7]]$Component, levels = c("Other Battery Materials", "Graphite", cathode_name, "Battery Assembly", "Other BOS", "Transformer", "Fire Suppression", "HVAC", "Energy Losses", "Battery Charging & Losses", "Offset Electricity"))
  results[[8]]$Category = factor(results[[8]]$Category, levels = c("Module Materials & Assembly", "Energy Storage BOS", "Battery Charging & Losses", "Offset Electricity"))
  
  
  df_wf = data.frame(results[[7]]$Category, results[[7]]$Component, results[[7]]$Mean)
  colnames(df_wf) = c("Category", "Component", "Mean")
  
  df_wf = df_wf[order(df_wf$Category),]
  df_wf = mutate(df_wf, end.bar = cumsum(Mean), start.bar = c(0, head(end.bar, -1)))
                 # do group indicies manually, # group.id = group_indices(., Category))
  group.id = c(1,1,1,1,2,2,2,2,3,3,4)
  end.id = c(0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1)
  df_wf = cbind(df_wf, group.id, end.id)
  
  df_wf_std = results[[8]][order(results[[8]]$Category),]
  
  
  ### ADD IMPACTS OF TIME SHIFTING TO "Battery Charging & Losses" AND "Offset Electricity"
  
  df_wf_std$Mean[df_wf_std$Category=="Battery Charging & Losses"] = df_wf_std$Mean[df_wf_std$Category=="Battery Charging & Losses"] + batt_damages_raw$CO2TDIFF_OtherPlant_TSC_Charge[batt_damages_raw$peaker_name==peaker_name]/10^6
  df_wf_std$Mean[df_wf_std$Category=="Offset Electricity"] = df_wf_std$Mean[df_wf_std$Category=="Offset Electricity"] + batt_damages_raw$CO2TDIFF_OtherPlant_TSD_Discharge[batt_damages_raw$peaker_name==peaker_name]/10^6
  
  
  
  ###
  
  
  df_wf_std = cbind(df_wf_std, df_wf$end.bar[df_wf$end.id==1])
  colnames(df_wf_std) = c("Category", "Mean", "STDev", "Pos")
  df_wf_std = mutate(df_wf_std, end.bar = cumsum(Mean), start.bar = c(0, head(end.bar, -1)))
  
  group.id = c(1,2,3,4)
  end.id = c(1,1,1,1)
  df_wf_std = cbind(df_wf_std, group.id, end.id)
 
  results[[9]] = df_wf
  results[[10]] = df_wf_std
  
  df_tot = data.frame(Category = "Net Emissions", 
                      Mean = sum(results[[10]]$Mean),
                      STDev = sum(results[[10]]$STDev^2)^0.5,
                      Pos = results[[10]]$Pos[results[[10]]$Category=="Offset Electricity"],
                      end.bar = results[[10]]$end.bar[results[[10]]$Category=="Offset Electricity"],
                      start.bar = 0,
                      group.id = 5,
                      end.id = 1
                      )
  
  results[[10]] = rbind(df_wf_std, df_tot)
  
  results[[10]] = cbind(results[[10]], rep(peaker_name,dim(results[[10]])[1]), rep(peaker_name_short,dim(results[[10]])[1]))
  colnames(results[[10]]) = c("Category", "Mean", "STDev", "Pos", "end.bar", 
                              "start.bar", "group.id", "end.id", "Peaker Plant Long", "Peaker Plant")
  
  
  ### df for all plotting
  
  results[[11]] = results[[10]]
  
  results[[11]] = results[[11]][results[[11]]$Category!="Net Emissions",]
  results[[11]]$end.bar[results[[11]]$Category=="Offset Electricity"] = 0 - (results[[11]]$start.bar[results[[11]]$Category=="Offset Electricity"] - results[[11]]$end.bar[results[[11]]$Category=="Offset Electricity"])
  results[[11]]$start.bar[results[[11]]$Category=="Offset Electricity"] = 0
  
  return(results)
  
}
  

