#------------------------------------------------------------------------------
# function_li_BESS #
#------------------------------------------------------------------------------

### DESCRIPTION ###

# Used in battery cost modeling

# calculates item quant and price by item
# calculates labor-hours and wages by by item
# outputs cost, materials, and variable LCA items


### VERSION TRACKER - NEGATIVE NOTATION ###

# v-1 (09/07/21): first iteration of removed function

# v-2 (09/17/21): pre moving cable lengths to after basic input manipulation

# v-3 (09/17/21): moved price to after quantity calculations

# v-5 (11/29/21): check point before LCA integration

# v-6 (12/02/21): LCA integration successful!
##                check point before improvements to run-time
###                 (removing writing then reading csv)
##                checkpoint before adding use-phase impacts

# v-7 (12/05/21): Use-phase impacts added
##                  check point before adding new variables for purchased and sold electricity type, as well as refrigerant type
##                  Also adding life-cycle EFs for GHG of utility solar PV

# v-8 (12/6/21): changing HVAC efficiency
##                adding in rte effects to purchased electricity quantity

# v-9 (01/06/22): adding NPV analysis

# v-10 (01/10/22): changing LCA to 3 sections (1) upfront, (2) annual, (3) pulse

# v-11 (01/31/22): reformatted npv to be prediscount - no discounting in function

### TASK LIST ###

# fire suppression price and quantities need to match RMI - done
## Chose correct container and update price and mass

# thermal system characteristics for cabinets of battery storage

# update so capacity per container changes automatically with container size

# manufacturing energies for non-battery materials (in LCA) - done?

# have subinput as HVAC refrigerant with options: r410a and others
## add properties of refrigerant ghgs

# changes required for battery tray (rack) LCA
## adjusting ModuleSize, ModulesPerRack, and RackPerContainer
### this changes module, rack, and container quants
## LCA for rack assumes uniform quant of steel per rack

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

source("func.DoD.rec.R")
source("func.lnnorm.dist.R")
source("input_output5.R")


#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------


function_li_BESS <- function(City, # Average,
                             State, # National,
                             Power_MW, # 60 MW
                             Duration, # [4, 3, 2, 1, 0.75, 0.5, 0.25]
                             Year, # 2020,
                             Lifespan, # [15, 20],
                             Chem,
                             Fire,
                             Cycle_per_year,
                             DoD,
                             n,
                             Deg_opt,
                             eBOS_MW,
                             purchased_electricity,
                             sold_electricity,
                             refrigerant,
                             peaker_name) {
  
  # DELETE BELOW
# 
# City = "Average"
# State = "National"
# Power_MW = 114 # 60 MW
# Duration = 4 # [4, 3, 2, 1, 0.75, 0.5, 0.25]
# Year = 2020 # 2020,
# Lifespan = 7.5 # [15, 20],
# Chem = "NMC Graphite 811"
# Fire = 2001
# Cycle_per_year = 24
# DoD = 0.95
# m = 100
# Deg_opt = "Yes"
# 
# eBOS_MW = 65
# 
# purchased_electricity = "electricity.Solar.kWh"
# sold_electricity = "electricity.NG.kWh"
# refrigerant = "r32.kg" # "r410a.kg"
# 
# peaker_name = "Long Beach Generating Station - Unit 1"
# 
# n = 1

  
  
  ##############################################################################
  # Basic Input Manipulation #
  ##############################################################################
  
  DoD = Duration_DoD$DoD[Duration_DoD$Duration==Duration]
  
  # calc capacity
  
  Capacity_MWh = Power_MW * Duration
  
  
  # sub chem  
  
  Chem_sub = 0
  
  if (grepl("LTO", Chem, fixed = TRUE) == TRUE) {
    
    Chem_sub = "LTO"
    
  } else if (grepl("LTO", Chem, fixed = TRUE) == FALSE) {
    
    Chem_sub = substr(Chem, 1, 3)
    
  }
  
  
  # for small systems
  
  if (MV_Trans_Size_MW > Power_MW) {
    
    MV_Trans_Size_MW = Power_MW
  }
  
  
  # Battery housing dimmensions and detector/controller quantities
  
  if (Cont_type == "40 ft") {
    
    Cont_Length = 40
    Cont_Width = 8
    Cont_Height = 8
    Cont_Price = 30000
    
    Det_quant = 4 # fire and gas detectors per container
    Controller_quant = 1/6 # controller capacity attributed to detectors in container
    
  } else if (Cont_type == "20 ft") {
    
    Cont_Length = 20
    Cont_Width = 8
    Cont_Height = 8
    Cont_Price = 15000
    
    Det_quant = 2
    Controller_quant = 1/12
    
  } else if (Cont_type == "Cabinet") {
    
    Cont_Length = 3
    Cont_Width = 4
    Cont_Height = 7
    Cont_Price = 5000
    
    Det_quant = 1
    Controller_quant = 1
  }
  
  
  # Inverter Housing dimmensions
  
  if (Inv_type == "20 ft") {
    
    Inv_Length = 20
    Inv_Width = 8
    Inv_Height = 8
    Inv_Cont_Price = 15000
    
  } else if (Inv_type == "Cabinet") {
    
    Inv_Length = 3
    Inv_Width = 4
    Inv_Height = 7
    Inv_Cont_Price = 5000
    
  } else if (Inv_type == "In_Batt") {
    
    Inv_Length = 0
    Inv_Width = 0
    Inv_Height = 0
    Inv_Cont_Price = 0
    
  }
  
  
  # thermal system
  
  if (therm_tech=="HVAC") {
    
    therm_price = 10000
    
  } else if (therm_tech=="Cell") {
    
    therm_price = 2000 * rack_per_cont
    
  }
  
  
  # misc spacing
  
  # MV_Switch_Size_MW = MV_Trans_Size_MW
  
  Inv_Space_ft = 0
  
  if (LV_AC_Voltage <= eq_spacing$V_Ceiling[1]) {
    Inv_Space_ft = eq_spacing$Con_3[1]
    
  } else if (LV_AC_Voltage > eq_spacing$V_Floor[2] &
             LV_AC_Voltage <= eq_spacing$V_Ceiling[2]) {
    Inv_Space_ft = eq_spacing$Con_3[2]
    
  } else if (LV_AC_Voltage > eq_spacing$V_Floor[3] &
             LV_AC_Voltage <= eq_spacing$V_Ceiling[3]) {
    Inv_Space_ft = eq_spacing$Con_3[3]
    
  } else if (LV_AC_Voltage > eq_spacing$V_Floor[4] &
             LV_AC_Voltage <= eq_spacing$V_Ceiling[4]) {
    Inv_Space_ft = eq_spacing$Con_3[4]
    
  } else {
    Inv_Space_ft = eq_spacing$Con_3[5]
    
  }
  
  # MV_Trans_Space_ft
  
  MV_Trans_Space_ft = 0
  
  if (MV_AC_Voltage <= eq_spacing$V_Ceiling[1]) {
    MV_Trans_Space_ft = eq_spacing$Con_3[1]
    
  } else if (MV_AC_Voltage > eq_spacing$V_Floor[2] &
             MV_AC_Voltage <= eq_spacing$V_Ceiling[2]) {
    MV_Trans_Space_ft = eq_spacing$Con_3[2]
    
  } else if (MV_AC_Voltage > eq_spacing$V_Floor[3] &
             MV_AC_Voltage <= eq_spacing$V_Ceiling[3]) {
    MV_Trans_Space_ft = eq_spacing$Con_3[3]
    
  } else if (MV_AC_Voltage > eq_spacing$V_Floor[4] &
             MV_AC_Voltage <= eq_spacing$V_Ceiling[4]) {
    MV_Trans_Space_ft = eq_spacing$Con_3[4]
    
  } else {
    MV_Trans_Space_ft = eq_spacing$Con_3[5]
    
  }
 
  ##############################################################################
  # Efficiency #
  ##############################################################################
  
  trans_eff_up = Transformer_Eff$Efficiency[dim(Transformer_Eff)[1]]
  trans_eff_low = Transformer_Eff$Efficiency[dim(Transformer_Eff)[1]-1]
  
  trans_size_up = Transformer_Eff$kVA[dim(Transformer_Eff)[1]]
  trans_size_low = Transformer_Eff$kVA[dim(Transformer_Eff)[1]-1]
  
  
  for (i in 2:dim(Transformer_Eff)[1]) {
    
    if (MV_Trans_Size_MW*1000 <= Transformer_Eff$kVA[i] & MV_Trans_Size_MW > Transformer_Eff$kVA[i-1]) {
      
      trans_eff_up = Transformer_Eff$Efficiency[i]
      trans_eff_low = Transformer_Eff$Efficiency[i-1]
      
      trans_size_up = Transformer_Eff$kVA[i]
      trans_size_low = Transformer_Eff$kVA[i-1]
      
    }
  }
  
  trans_eff = (trans_eff_up - trans_eff_low) / (trans_size_up - trans_size_low) * (MV_Trans_Size_MW*1000 - trans_size_low) + trans_eff_low
  Eff_trans = (100 - trans_eff)/100
  
  Eff_trans = Eff_trans + rnorm(n, mean = 0, sd = 0.25 * Eff_trans / C_half)
  
  Eff_inv = 1.83/100 + rnorm(n, mean = 0, sd = 0.599/100)
  
  
  if (Eff_inv<=0) {
    
    Eff_inv_back_up = data.frame(1.83/100 + rnorm(1000, mean = 0, sd = 0.599/100))
    colnames(Eff_inv_back_up) = c("Eff")
    Eff_inv_back_up = Eff_inv_back_up[!(Eff_inv_back_up$Eff<=0),]
    
    temp = runif(1,min = 1, max = length(Eff_inv_back_up))
    
    Eff_inv = Eff_inv_back_up[temp]
    
  }
  
  Loss_therm = 0
  
  
  if (therm_tech=="HVAC") {

    Loss_therm = 0.015 + runif(n, min = -0.010, max = 0.010)

  } else if (therm_tech=="Cell") {

    Loss_therm = 0.01 + runif(n, min = -0.005, max = 0.005)

  }
  
  
  Loss_misc = 0.03 + runif(n, min = -0.02, max = 0.02)
  
  Eff_batt_charge = runif(n, min = Battery_Eff_Charge$Eff_min[Battery_Eff_Charge$Duration==Duration], max = Battery_Eff_Charge$Eff_max[Battery_Eff_Charge$Duration==Duration])
  
  Eff_batt_dis = runif(n, min = Battery_Eff_Dis$Eff_min[Battery_Eff_Dis$Duration==Duration], max = Battery_Eff_Dis$Eff_max[Battery_Eff_Charge$Duration==Duration])
  
  Eff_batt = Eff_batt_charge * Eff_batt_dis
  
  Efficiency = data.frame(Eff_trans,
                          Eff_inv,
                          Eff_batt,
                          Loss_therm,
                          Loss_misc
  )
  
  colnames(Efficiency) = c("Transformer", "Inverter","Battery", "Thermal_Draw", "Misc_Draw")
  
  ##############################################################################
  # Deg_per_Cycle #
  ##############################################################################
  
  
  # for relative impact of cycle life - currently set at 10%
  cyc_pos_neg_mod = 1
  
  if(grepl("+c",Chem, fixed = TRUE)) {
    
    cyc_pos_neg_mod = 1.1
    
  } else if (grepl("-c",Chem, fixed = TRUE)) {
    
    cyc_pos_neg_mod = 0.9
    
  }
  
  
  
  
  Cycle_Life_High = Cycle_Life$High[Cycle_Life$Chemistry==Chem_sub]*cyc_pos_neg_mod
  
  Cycle_Life_Low = Cycle_Life$Low[Cycle_Life$Chemistry==Chem_sub]*cyc_pos_neg_mod
  
  cycle_life = (Cycle_Life_High - Cycle_Life_Low) / 2 + Cycle_Life_Low + rnorm(n, mean = 0, sd = (Cycle_Life_High - Cycle_Life_Low) / C) # runif(n, min = Cycle_Life_Low, max = Cycle_Life_High) * (1/DoD)
  
  
  for (i in 1:length(cycle_life)) {
    
    if (cycle_life[i] <= 0) {
      
      cycle_life[i] = runif(1, min = Cycle_Life_Low, max = Cycle_Life_High)
      
    }
  }
  
  
  eol = 0.8 # runif(n, min = 0.7, max = 0.8)
  
  Deg_per_Cycle_cycle_life = 1 - eol^(1/cycle_life)
  
  
  ##############################################################################
  # Deg_per_Year_Shelf #
  ##############################################################################
  
  
  # for relative impact of shef life - currently set at 10%
  shl_pos_neg_mod = 1
  
  if(grepl("+s",Chem, fixed = TRUE)) {
    
    shl_pos_neg_mod = 1.1
    
  } else if (grepl("-s",Chem, fixed = TRUE)) {
    
    shl_pos_neg_mod = 0.9
    
  }
  
  
  
  Shelf_Life_High = Shelf_Life$High[Shelf_Life$Chemistry==Chem_sub] * shl_pos_neg_mod
  
  Shelf_Life_Low = Shelf_Life$Low[Shelf_Life$Chemistry==Chem_sub] * shl_pos_neg_mod
  
  Shelf_life = (Shelf_Life_High - Shelf_Life_Low) / 2 + Shelf_Life_Low + rnorm(n, mean = 0, sd = (Shelf_Life_High - Shelf_Life_Low) / C) # runif(n, min = Shelf_Life_Low, max = Shelf_Life_High)
  
  eol = 0.8 # runif(n, min = 0.7, max = 0.8)
  
  Deg_per_Year_Shelf = 1 - eol^(1/Shelf_life)
  
  # wont work if Cycle_per_year = 0
  
  Deg_per_Cycle_shelf_life = Deg_per_Year_Shelf * (1/ Cycle_per_year)
  
  ##############################################################################
  # overdesign_percent #
  ##############################################################################
  
  r_pos_neg_mod = 1
  
  if(grepl("+d",Chem, fixed = TRUE)) {
    
    r_pos_neg_mod = 1.1
    
  } else if (grepl("-d",Chem, fixed = TRUE)) {
    
    r_pos_neg_mod = 0.9
    
  }
  
  RTE_tot = (1-Efficiency$Transformer)^2 * (1-Efficiency$Inverter)^2 * (Efficiency$Battery) * (1-Efficiency$Thermal_Draw - Efficiency$Misc_Draw)
  
  Loss_conv = .138 + rnorm(1, mean = 0, sd = .138 / C)
  
  if(Loss_conv<0) {
    
    Loss_conv = 13.8
    
  }
  
  Loss_cons = .107 + runif(1, min = -0.02675, max = .02675)
  
  # RTE_tot = (Efficiency$Battery) * (1 - Loss_conv) * (1 - Loss_cons)
  
  r = (-1 * (Deg_per_Cycle_cycle_life + Deg_per_Cycle_shelf_life))*r_pos_neg_mod
  
  # r = -1* max(c(Deg_per_Cycle_cycle_life,Deg_per_Cycle_shelf_life))*r_pos_neg_mod # might need to del
  
  Cycles_tot = Cycle_per_year * Lifespan
  
  DoD_adj = function_DoD_rec(Cycles_tot, r, DoD)
  
  if (Deg_opt == "Yes") {
    
    Cap_Adj = Capacity_MWh * (1/DoD_adj) * (1/RTE_tot) # * ((1 + r)^Lifespan)
    
  } else if (Deg_opt == "No") {
    
    Cap_Adj = Capacity_MWh * (1/DoD) * (1/RTE_tot) # * ((1 + r)^Lifespan)
    
  }
  
  ##############################################################################
  # Quantities #
  ##############################################################################
  
  #     a: Battery Price (Batt, labor)
  
  mat_a = Cap_Adj *  1000 #  * overdesign_percent / 100
  
  chem_multiplier = Chem_Mult$Multiplier[Chem_Mult$Chemistry == Chem]
  
  # price_a = Price$a
  
  lab_a = mat_a / Module_size_kWh * Module_install_time
  
  wage_a = 54.40 * Cost_Adj_2020
  
  
  #     b: Inverter (Inv, labor) (Labor as MV transformer)
  
  Container_Pow_MW = Container_Cap_MWh / Duration
  Cont_quant = ceiling(mat_a / 1000 / Container_Cap_MWh)
  
  Cont_per_Inv = Inv_Size_MW / Container_Pow_MW
  Cont_per_MV_Trans = MV_Trans_Size_MW / Container_Pow_MW
  Cont_per_MV_Switch = MV_Switch_Size_MW / Container_Pow_MW
  # Inv_quant = ceiling(Cont_quant / Cont_per_Inv)
  
  Inv_quant = ceiling(eBOS_MW / Inv_Size_MW) # Inv size a sub input
    
    # ceiling(Power_MW / Inv_Size_MW) # old deriation
  
  mat_b = Inv_quant
  
  # price_b = Price$b
  
  lab_b_up = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]]
  lab_b_low = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]-1]
  
  size_b_up = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]]
  size_b_low = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]-1]
  
  for (i in 2:dim(MV_Trans_Costs)[1]) {
    
    if (Inv_Size_MW <= MV_Trans_Costs$Size_MW[i] & Inv_Size_MW > MV_Trans_Costs$Size_MW[i-1]) {
      
      lab_b_up = MV_Trans_Costs$Lab_hrs[i]
      lab_b_low = MV_Trans_Costs$Lab_hrs[i-1]
      
      size_b_up = MV_Trans_Costs$Size_MW[i]
      size_b_low = MV_Trans_Costs$Size_MW[i-1]
      
    }
  }
  
  # price_b = Price$b
  
  lab_b = ((lab_b_up - lab_b_low) / (size_b_up - size_b_low) * (Inv_Size_MW - size_b_low) + lab_b_low) * mat_b
  
  #lab_b = 110 * mat_b 
  
  wage_b = 64.45 * Cost_Adj_2020
  
  
  #     c: Transformer (eBOS, labor) (26 12 19.10)
  
  MV_Trans_quant = ceiling(eBOS_MW / MV_Trans_Size_MW) # MV Trans size a subinput
    
    # ceiling(Power_MW / MV_Trans_Size_MW) # old derivations
    # ceiling(Cont_quant / Cont_per_MV_Trans)
  
  mat_c = MV_Trans_quant
  
  lab_c_up = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]]
  lab_c_low = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]-1]
  
  size_c_up = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]]
  size_c_low = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]-1]
  
  for (i in 2:dim(MV_Trans_Costs)[1]) {
    
    if (MV_Trans_Size_MW <= MV_Trans_Costs$Size_MW[i] & MV_Trans_Size_MW > MV_Trans_Costs$Size_MW[i-1]) {
      
      lab_c_up = MV_Trans_Costs$Lab_hrs[i]
      lab_c_low = MV_Trans_Costs$Lab_hrs[i-1]
      
      size_c_up = MV_Trans_Costs$Size_MW[i]
      size_c_low = MV_Trans_Costs$Size_MW[i-1]
      
    }
  }
  
  # price_c = Price$c
  
  lab_c = ((lab_c_up - lab_c_low) / (size_c_up - size_c_low) * (MV_Trans_Size_MW - size_c_low) + lab_c_low) * mat_c
  
  # price_c = 55600 * Cost_Adj_2020
  
  # lab_c = 110 * mat_c
  
  wage_c = 64.45 * Cost_Adj_2020
  
  
  #     d: Switchgear
  
  MV_Switch_quant = ceiling(eBOS_MW / MV_Switch_Size_MW) # MV switch size fixed
    
    # ceiling(Power_MW / MV_Switch_Size_MW) # old derivations
    # ceiling(Cont_quant / Cont_per_MV_Trans)
  
  mat_d = MV_Switch_quant
  
  # price_d = Price$d
  
  lab_d_up = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]]
  lab_d_low = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]-1]
  
  size_d_up = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]]
  size_d_low = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]-1]
  
  for (i in 2:dim(MV_Trans_Costs)[1]) {
    
    if (MV_Switch_Size_MW <= MV_Trans_Costs$Size_MW[i] & MV_Switch_Size_MW > MV_Trans_Costs$Size_MW[i-1]) {
      
      lab_d_up = MV_Trans_Costs$Lab_hrs[i]
      lab_d_low = MV_Trans_Costs$Lab_hrs[i-1]
      
      size_d_up = MV_Trans_Costs$Size_MW[i]
      size_d_low = MV_Trans_Costs$Size_MW[i-1]
      
    }
  }
  
  lab_d = ((lab_d_up - lab_d_low) / (size_d_up - size_d_low) * (MV_Switch_Size_MW - size_d_low) + lab_d_low) * mat_d # fix to d and swithc
  
  wage_d = 64.45 * Cost_Adj_2020
  
  
  #     e: Conductors (based from 26 05 13.16 1000-1600)
  
  DC_Cont = (
    Container_Space_ft / 2 * (Cont_per_Inv) + (Cont_Width / 2 + Container_Space_ft /
                                                 2) * 2 * (Cont_per_Inv - 1)
  ) * Inv_quant
  
  DC_Inv = (Inv_Space_ft / 2) * (Cont_quant / Cont_per_Inv)
  
  if (Inv_Space_ft / 2 < Container_Space_ft / 2) {
    DC_Inv = Container_Space_ft / 2 * (Cont_quant / Cont_per_Inv)
  }
  
  Inv_per_MV_Trans = Inv_quant / MV_Trans_quant
  
  LV_AC_Inv = (
    Inv_Space_ft / 2 * (Inv_per_MV_Trans) + (Inv_Width / 2 + Inv_Space_ft /
                                               2) * 2 * (Inv_per_MV_Trans - 1)
  ) * MV_Trans_quant
  
  LV_AC_MV_Trans = (MV_Trans_Space_ft / 2) * (MV_Trans_quant)
  
  if (MV_Trans_Space_ft / 2 < Inv_Space_ft / 2) {
    LV_AC_MV_Trans = MV_Trans_Space_ft / 2 * (MV_Trans_quant)
  }
  
  MV_AC_MV_Trans = MV_Trans_Space_ft / 2 * (MV_Trans_quant) + (MV_Trans_Width /
                                                                 2 + MV_Trans_Space_ft / 2) * 2 * (MV_Trans_quant - 1) + MV_Trans_Space_ft /
    2
  # Switchgear side plus inv side
  
  mat_e = DC_Cont + DC_Inv + LV_AC_Inv + LV_AC_MV_Trans + MV_AC_MV_Trans
  
  if (Config=="Conv") {
    
    mat_e = mat_e
    
  } else if (Config=="Tesla") {
    
    mat_e = LV_AC_Inv + LV_AC_MV_Trans + MV_AC_MV_Trans
    
  }
  
  # price_e = Price$e
  
  lab_e = 5.5 / 100 * mat_e
  
  wage_e = 58.20 * Cost_Adj_2020
  
  
  #     f: Conduits (Rigid galvanized steel 4 in diameter 26 05 39.40 1000)
  
  mat_f = mat_e
  
  # price_f = Price$f
  
  lab_f = 0.160 * mat_f
  
  wage_f = 58.20 * Cost_Adj_2020
  
  
  #     g: BMS
  
  mat_g = 1
  
  # price_g = Price$g 
  
  lab_g = 800 / 60 * Power_MW # NREL 400 assumption
  
  wage_g = 58.15 * Cost_Adj_2020
  
  
  #     h: Fire Suppression 21 22 16.50 2460 + 6000*container volume + 28 42 15.50 0140
  
  mat_h = Cont_quant
  
  
  if (Fire == 12) {
    
    lab_h = (8 + 2.667) * mat_h
    wage_h = (8 * 58.20 + 2.667 * 55.92) / (8 + 2.667) * Cost_Adj_2020
    
  } else if (Fire == 13) {
    
    lab_h = (0.1*Cont_Length + ceiling(Cont_Length / 15) * 0.5) * mat_h
    wage_h = 55.92 * Cost_Adj_2020 
    
  } else if (Fire == 2001) {
    
    lab_h = (2 + (0.1*Cont_Length + ceiling(Cont_Length / 15) * 0.5))* mat_h
    wage_h = 55.92 * Cost_Adj_2020
    
    
  }
  
  # price_h = Price$h
  
  
  #     i: Thermal Regulation, fix later, for now use NREL 10,000
  
  alpha = 0.0768 # https://www.solarpowerworldonline.com/2019/04/the-importance-of-thermal-management-of-stationary-lithium-ion-energy-storage-enclosures/#:~:text=The%20low%20prescribed%20battery%20operating,requires%20near%20perfect%20air%20distribution.
  
  # https://www.cedengineering.com/userfiles/Cooling%20Load%20Calculations%20and%20Principles.pdf
  
  mat_i = Cont_quant
  
  # price_i = Price$i
  
  lab_i = 400 / 60 * Power_MW / Cont_quant * mat_i
  
  wage_i = 57.20 * Cost_Adj_2020
  
  
  #     j: Battery Housing      # sBOS, labor
  
  mat_j = Cont_quant
  
  # price_j = Price$j
  
  lab_j_up = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]]
  lab_j_low = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]-1]
  
  size_j_up = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]]
  size_j_low = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]-1]
  
  for (i in 2:dim(MV_Trans_Costs)[1]) {
    
    if ((Container_Cap_MWh/Duration) <= MV_Trans_Costs$Size_MW[i] & (Container_Cap_MWh/Duration) > MV_Trans_Costs$Size_MW[i-1]) {
      
      lab_j_up = MV_Trans_Costs$Lab_hrs[i]
      lab_j_low = MV_Trans_Costs$Lab_hrs[i-1]
      
      size_j_up = MV_Trans_Costs$Size_MW[i]
      size_j_low = MV_Trans_Costs$Size_MW[i-1]
      
    }
  }
  
  lab_j = ((lab_j_up - lab_j_low) / (size_j_up - size_j_low) * (MV_Trans_Size_MW - size_j_low) + lab_j_low) * mat_j
  
  wage_j = 64.45 * Cost_Adj_2020
  
  
  #     k: Inverter Housing
  
  mat_k = Inv_quant
  
  # price_k = Price$k
  
  lab_k = 0 # no double counting
  
  wage_k = 0
  
  
  #     l: Foundations (03 30 53.40 4700)
  
  Cont_Found = Cont_Length * Cont_Width * Cont_quant
  Inv_Found = Inv_Length * Inv_Width * Inv_quant
  MV_Trans_Found = MV_Trans_Pad_Length * MV_Trans_Pad_Width * MV_Trans_quant
  MV_Switch_Found = (MV_Switch_Length + MV_Trans_Space_ft*2) * (MV_Switch_Width*MV_Switch_quant + MV_Trans_Space_ft*2)
  
  mat_l = 0.5 * (Cont_Found + Inv_Found + MV_Trans_Found + MV_Switch_Found) / 27
  
  # price_l = Price$l
  
  lab_l = 0.957 * mat_l
  
  wage_l = 49.36 * Cost_Adj_2020
  
  
  #     m: Grading (31 22 13.20 0100 - 0280)
  
  mat_m = 1
  
  # price_m = Price$m
  
  Cont_Site = (Cont_Length + Container_Space_ft) * (Cont_Width + Container_Space_ft) *
    Cont_quant
  Inv_Site = (Inv_Length + Inv_Space_ft) * (Inv_Width + Inv_Space_ft) * Inv_quant
  MV_Trans_Site = (MV_Trans_Length + MV_Trans_Space_ft) * (MV_Trans_Width +
                                                             MV_Trans_Space_ft) * MV_Trans_quant
  
  Tot_site = Cont_Site + Inv_Site + MV_Trans_Site + MV_Switch_Found
  
  size = dim(site_hours)
  
  site_labor = site_hours$Labor_hrs[size[1]]
  site_wage = site_hours$Wage[size[1]]
  
  
  for (count in 1:size[1]) {
    if (Tot_site > site_hours$SF_Floor[count] &
        Tot_site <= site_hours$SF_Ceiling[count]) {
      
      site_labor = site_hours$Labor_hrs[count]
      site_eq = site_hours$Eq_cost[count]
      O_P_labor = site_hours$Labor_Perc[count]
      site_wage = site_hours$Wage[count]
      
    }
  }
  
  lab_m = site_labor
  
  wage_m = site_wage * Cost_Adj_2020
  
  
  #     n: Trenching (31 23 16.13 0050)
  
  mat_n = mat_e * 4 / 27
  
  # price_n = Price$n
  
  lab_n = 0.107 * mat_n
  
  wage_n = 49.36 * Cost_Adj_2020
  
  
  #     o: Backfill (31 23 23.13 0015+0400)
  
  mat_o = mat_n
  
  # price_o = Price$o
  
  lab_o = (0.571 + 0.120) * mat_o
  
  wage_o = 54.39 * Cost_Adj_2020
  
  
  #     p: Hauling (loosely from 31 23 23.20)
  
  mat_p = mat_n
  
  # price_p = Price$p
  
  lab_p = 0 # 0.075 * mat_p
  
  wage_p = 0 # 88.33 * Cost_Adj_2020
  
  
  #     q: Communication and Market Participation
  
  mat_q = 1
  
  # price_q = Price$q
  
  lab_q = lab_c / mat_c # assume transformer install
  
  wage_q = 58.20 * Cost_Adj_2020 # 1 electrician
  
  
  #     r: Gas Detection Probes
  
  mat_r = Cont_quant * Det_quant
  
  # price_r = Price$r
  
  lab_r = 1 * mat_r
  
  wage_r = 58.2
  
  #     s: Gas Detection Controller
  
  mat_s = Cont_quant * Controller_quant
  
  # price_s = Price$s
  
  lab_s = 1 * mat_s
  
  wage_s = 0 # no labor?
  
  
  #     t: Fire Detectors
  
  mat_t = Cont_quant * Det_quant
  
  # price_t = Price$t
  
  lab_t = 1 * mat_t
  
  wage_t = 58.2
  
  ##############################################################################
  # Price #
  ##############################################################################
  
  # battery module
  alpha = Chem_Mult$alpha[Chem_Mult$Chem == Chem]
  beta = Chem_Mult$beta[Chem_Mult$Chem == Chem]
  mu = Chem_Mult$mu[Chem_Mult$Chem == Chem]
  sd = Chem_Mult$sd[Chem_Mult$Chem == Chem]
  min = Chem_Mult$min[Chem_Mult$Chem == Chem]
  max = Chem_Mult$max[Chem_Mult$Chem == Chem]
  chem_rack = Chem_Mult$rack[Chem_Mult$Chem == Chem]
  
  chem_multiplier = function_lnnorn_dist(alpha, beta, mu, sd, min, max, n)
  
  price_a = chem_multiplier * chem_rack
  
  # price_a = chem_multiplier * base_price_batt + rnorm(n, mean = 0, sd = 0.25*chem_multiplier * base_price_batt/C_half)
  # price_a = chem_multiplier * base_price_batt * EV_stat_adj + rnorm(n, mean = 0, sd = 0.25*chem_multiplier * base_price_batt * EV_stat_adj/C_half)
  # distribution: +/- 25%, SD is range/C or (max - mean)/(C/2)
  # rnorm(n, mean = chem_multiplier * base_price_batt * 1.5, sd = chem_multiplier * base_price_batt * 1.5 * .25 / 2)
  
  # inverter
  price_b = Inv_Size_MW*1000*1000*0.06 + rnorm(n, mean = 0, sd = Inv_Size_MW*1000*1000*0.02 / C_half)
  # Inv_Size_MW * 1000 * 1000 * rnorm(n, mean = 0.06, sd = 0.01)
  
  # transformer
  price_c_up = MV_Trans_Costs$Mat[dim(MV_Trans_Costs)[1]]
  price_c_low = MV_Trans_Costs$Mat[dim(MV_Trans_Costs)[1]-1]
  
  lab_c_up = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]]
  lab_c_low = MV_Trans_Costs$Lab_hrs[dim(MV_Trans_Costs)[1]-1]
  
  size_c_up = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]]
  size_c_low = MV_Trans_Costs$Size_MW[dim(MV_Trans_Costs)[1]-1]
  
  for (i in 2:dim(MV_Trans_Costs)[1]) {
    
    if (MV_Trans_Size_MW <= MV_Trans_Costs$Size_MW[i] & MV_Trans_Size_MW > MV_Trans_Costs$Size_MW[i-1]) {
      
      price_c_up = MV_Trans_Costs$Mat[i]
      price_c_low = MV_Trans_Costs$Mat[i-1]
      
      lab_c_up = MV_Trans_Costs$Lab_hrs[i]
      lab_c_low = MV_Trans_Costs$Lab_hrs[i-1]
      
      size_c_up = MV_Trans_Costs$Size_MW[i]
      size_c_low = MV_Trans_Costs$Size_MW[i-1]
      
    }
  }
  
  price_c = ((price_c_up - price_c_low) / (size_c_up - size_c_low) * (MV_Trans_Size_MW - size_c_low) + price_c_low) * Cost_Adj_2020
  
  price_c = (price_c + rnorm(n, mean = 0, sd = 0.25 * price_c/C_half)) * Cost_Adj_2020
  
  
  # switchgear
  price_d_int = 0
  price_d = 0
  
  if (eBOS_MW < 25) {
    
    price_d_int = 100000
    price_d = price_d_int + rnorm(n, mean = 0, sd = 0.25 * price_d_int / C_half)
    
  } else if (eBOS_MW >= 25) {
    
    price_d_int = ((200000 - 100000) / (100 - 25)) * (Power_MW - 25) + 100000
    price_d = price_d_int + rnorm(n, mean = 0, sd = 0.25 * price_d_int / C_half)
    
  }
  
  Intercon_Fee = 0
  
  if (Intercon_Level ==1) {
    
    Intercon_Fee = runif(n, 1000000, 3000000)
    
  }
  
  price_d = price_d + Intercon_Fee
  
  # conductors 
  price_e = 5 + runif(n, -2.5, 2.5)
  
  # conduits
  price_f = (18.9 + rnorm(n, mean = 0, sd = 3.4)) * Cost_Adj_2020
  
  # BMS
  price_g = 400000 + runif(n, -200000, 200000)
  
  # fire suppression
  
  fire_2001_price_factor = 1
  
  if (Cont_type== "40 ft") {
    
    fire_2001_price_factor = 2
    
  }
  
  
  if (Fire == 0) {
    
    price_h = 0
    
  } else if (Fire == 12) {
    
    price_h = ((1300 + 920) + rnorm(n, mean = 0, sd  = 0.25 * (1300 + 920) / C_half)) * Cost_Adj_2020
    
  } else if (Fire == 13) {
    
    price_h =  (5 * Cont_Length + ceiling(Cont_Length / 15) * 20 + rnorm(n, mean = 0, sd = 0.25 * (5 * Cont_Length + ceiling(Cont_Length / 15) * 20) / C_half)) * Cost_Adj_2020
    
  } else if (Fire == 2001) {
    
    price_h = (1975*fire_2001_price_factor + 1.76 * Cont_Length * Cont_Width * Cont_Height + rnorm(n, mean = 0 , sd = 0.25 * (1975 + 1.76 * Cont_Length * Cont_Width * Cont_Height) / C_half)) * Cost_Adj_2020
    # removed 1975 from meansince redundant
    
  }
  
  # thermal management
  price_i = therm_price + runif(n, min = -0.5 * therm_price, max = 0.5 * therm_price) # per container
  
  # battery housing
  price_j = Cont_Price + rnorm(n, mean = 0, sd = 0.5 * Cont_Price / C_half)
  
  # inverter housing
  
  price_k = Inv_Cont_Price + rnorm(n, mean = 0, sd = 0.5 * Inv_Cont_Price / C_half + 0.00001)
  
  # foundation
  price_l = (140 + rnorm(n, mean = 0, sd = 0.25 * 140 / C_half)) * Cost_Adj_2020
  
  price_m = rep(0,n)
  
  price_n = rep(0,n)
  
  price_o = rep(0,n)
  
  price_p = rep(0,n)
  
  # communications
  price_q = 200000 + runif(n, min = -100000, max = 100000) # RIG(Remote integrating gateway - 100,000), Telemetry (70,000), Market Participation (30,000)
  
  # Gas detection Probes, r
  price_r = 630
  
  # Gas detection controller, s
  price_s = 2925
  
  #Fire detection, t
  price_t = 51.50
  
  Price = data.frame(price_a,
                     price_b,
                     price_c,
                     price_d,
                     price_e,
                     price_f,
                     price_g,
                     price_h,
                     price_i,
                     price_j,
                     price_k,
                     price_l,
                     price_m,
                     price_n,
                     price_o,
                     price_p,
                     price_q,
                     price_r,
                     price_s,
                     price_t
  )
  
  colnames(Price) = c("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t")
  
  
  
  
  
  
  ##############################################################################
  # Matrix Definitions #
  ##############################################################################
  
  # tot
  mat_tot = matrix(
    data = c(
      mat_a,
      mat_b,
      mat_c,
      mat_d,
      mat_e,
      mat_f,
      mat_g,
      mat_h,
      mat_i,
      mat_j,
      mat_k,
      mat_l,
      mat_m,
      mat_n,
      mat_o,
      mat_p,
      mat_q,
      mat_r,
      mat_s,
      mat_t
    ),
    nrow = 1
  )
  
  price_tot = t(matrix(
    data = c(
      price_a,
      price_b,
      price_c,
      price_d,
      price_e,
      price_f,
      price_g,
      price_h,
      price_i,
      price_j,
      price_k,
      price_l,
      price_m,
      price_n,
      price_o,
      price_p,
      price_q,
      price_r,
      price_s,
      price_t
    ),
    nrow = 1
  ))
  
  lab_tot = matrix(
    data = c(
      lab_a,
      lab_b,
      lab_c,
      lab_d,
      lab_e,
      lab_f,
      lab_g,
      lab_h,
      lab_i,
      lab_j,
      lab_k,
      lab_l,
      lab_m,
      lab_n,
      lab_o,
      lab_p,
      lab_q,
      lab_r,
      lab_s,
      lab_t
    ),
    nrow = 1
  )
  
  wage_tot = t(matrix(
    data = c(
      wage_a,
      wage_b,
      wage_c,
      wage_d,
      wage_e,
      wage_f,
      wage_g,
      wage_h,
      wage_i,
      wage_j,
      wage_k,
      wage_l,
      wage_m,
      wage_n,
      wage_o,
      wage_p,
      wage_q,
      wage_r,
      wage_s,
      wage_t
    ),
    nrow = 1
  ))
  
  
  # batt: a
  mat_batt = matrix(data = c(mat_a), nrow = 1)
  
  price_batt = t(matrix(data = c(price_a), nrow = 1))
  
  lab_batt = matrix(data = c(lab_a), nrow = 1)
  
  wage_batt = t(matrix(data = c(wage_a), nrow = 1))
  
  
  #inv: b
  mat_inv = matrix(data = c(mat_b), nrow = 1)
  
  price_inv = t(matrix(data = c(price_b), nrow = 1))
  
  lab_inv = matrix(data = c(lab_b), nrow = 1)
  
  wage_inv = t(matrix(data = c(wage_b), nrow = 1))
  
  
  # eBOS: c, d, e, f, g, q
  mat_eBOS = matrix(data = c(mat_c, mat_d, mat_e, mat_f, mat_g, mat_q), nrow = 1)
  
  price_eBOS = t(matrix(
    data = c(price_c, price_d, price_e, price_f, price_g, price_q), nrow = 1))
  
  lab_eBOS = matrix(data = c(lab_c, lab_d, lab_e, lab_f, lab_g, lab_q), nrow = 1)
  
  wage_eBOS = t(matrix(
    data = c(wage_c, wage_d, wage_e, wage_f, wage_g, wage_q), nrow = 1))
  
  
  # sBOS: j, k, l
  
  mat_sBOS = matrix(data = c(mat_j, mat_k, mat_l), nrow = 1)
  
  price_sBOS = t(matrix(data = c(price_j, price_k, price_l), nrow = 1))
  
  lab_sBOS = matrix(data = c(lab_j, lab_k, lab_l), nrow = 1)
  
  wage_sBOS = t(matrix(data = c(wage_j, wage_k, wage_l), nrow = 1))
  
  # cBOS: h, i, r, s, t
  
  mat_cBOS = matrix(data = c(mat_h, mat_i, mat_r, mat_s, mat_t), nrow = 1)
  
  price_cBOS = t(matrix(data = c(price_h, price_i, price_r, price_s, price_t), nrow = 1))
  
  lab_cBOS = matrix(data = c(lab_h, lab_i, lab_r, lab_s, lab_t), nrow = 1)
  
  wage_cBOS = t(matrix(data = c(wage_h, wage_i, wage_r, wage_s, wage_t), nrow = 1))
  
  ##############################################################################
  # Cost Calculations #
  ##############################################################################
  
  
  idx_mat = Price_Index_City_State$Cost_Index_Mat[Price_Index_City_State$City ==
                                                    City & Price_Index_City_State$State == State] / 100
  idx_lab = Price_Index_City_State$Cost_Index_Inst[Price_Index_City_State$City ==
                                                     City & Price_Index_City_State$State == State] / 100
  
  cost_mat_tot = mat_tot %*% price_tot * idx_mat
  cost_lab_tot = lab_tot %*% wage_tot * idx_lab
  cost_mat_tot_kWh = cost_mat_tot / (Capacity_MWh * 1000)
  cost_lab_tot_kWh = cost_lab_tot / (Capacity_MWh * 1000)
  
  cost_lab_tot_kWh = cost_lab_tot_kWh + rnorm(1, mean = 0, sd = 0.25 * cost_lab_tot_kWh / C_half)
  
  
  cost_mat_batt = mat_batt %*% price_batt * idx_mat
  cost_lab_batt = lab_batt %*% wage_batt * idx_lab
  cost_mat_batt_kWh = cost_mat_batt / (Capacity_MWh * 1000)
  cost_lab_batt_kWh = cost_lab_batt / (Capacity_MWh * 1000)
  
  cost_lab_batt_kWh = cost_lab_batt_kWh + rnorm(1, mean = 0, sd = 0.25 * cost_lab_batt_kWh / C_half)
  
  
  cost_mat_inv = mat_inv %*% price_inv * idx_mat
  cost_lab_inv = lab_inv %*% wage_inv * idx_lab
  cost_mat_inv_kWh = cost_mat_inv / (Capacity_MWh * 1000)
  cost_lab_inv_kWh = cost_lab_inv / (Capacity_MWh * 1000)
  
  cost_lab_inv_kWh = cost_lab_inv_kWh + rnorm(1, mean = 0, sd =0.25 * cost_lab_inv_kWh / C_half)
  
  
  cost_mat_eBOS = mat_eBOS %*% price_eBOS * idx_mat
  cost_lab_eBOS = lab_eBOS %*% wage_eBOS * idx_lab
  cost_mat_eBOS_kWh = cost_mat_eBOS / (Capacity_MWh * 1000)
  cost_lab_eBOS_kWh = cost_lab_eBOS / (Capacity_MWh * 1000)
  
  cost_lab_eBOS_kWh = cost_lab_eBOS_kWh + rnorm(1, mean = 0, sd = 0.25 * cost_lab_eBOS_kWh / C_half)
  
  
  cost_mat_sBOS = mat_sBOS %*% price_sBOS * idx_mat
  cost_lab_sBOS = lab_sBOS %*% wage_sBOS * idx_lab
  cost_mat_sBOS_kWh = cost_mat_sBOS / (Capacity_MWh * 1000)
  cost_lab_sBOS_kWh = cost_lab_sBOS / (Capacity_MWh * 1000)
  
  cost_lab_sBOS_kWh = cost_lab_sBOS_kWh + rnorm(1, mean = 0, sd = 0.25 * cost_lab_sBOS_kWh / C_half)
  
  
  cost_mat_cBOS = mat_cBOS %*% price_cBOS * idx_mat
  cost_lab_cBOS = lab_cBOS %*% wage_cBOS * idx_lab
  cost_mat_cBOS_kWh = cost_mat_cBOS / (Capacity_MWh * 1000)
  cost_lab_cBOS_kWh = cost_lab_cBOS / (Capacity_MWh * 1000)
  
  cost_lab_cBOS_kWh = cost_lab_cBOS_kWh + rnorm(1, mean = 0, sd = 0.25 * cost_lab_cBOS_kWh / C_half)
  
  
  ##############################################################################
  # EPC Overhead, Sales Tax, and Dev Costs #
  ##############################################################################
  
  # EPC Overhead
  cost_EPC_Overhead = 0.25 * cost_lab_tot + 0.0867 * (cost_mat_inv + cost_mat_eBOS + cost_mat_sBOS)
  # cost_EPC_Overhead_kWh = cost_EPC_Overhead / (Capacity_MWh * 1000)
  
  # Sales Tax
  
  tax = Sales_Tax_Table$Sales_Tax[Sales_Tax_Table$State == State]
  
  cost_st = tax * cost_mat_tot
  cost_st_kWh = cost_st / (Capacity_MWh * 1000)
  
  # Dev costs #
  
  # Dev overhead
  
  dev_overhead = (((0.12 - 0.015) / (5 - 100)) * (Power_MW - 5) + 0.12)
  
  if (dev_overhead<0.015) {
    
    dev_overhead = 0.015
    
  }
  
  dev_overhead = dev_overhead * (cost_mat_tot + cost_lab_tot) # need nrel data
  
  dev_overhead = dev_overhead + rnorm(1, mean = 0, sd = 0.25 * dev_overhead / C_half)
  
  # pii
  perm = Permit_State$Permit[Permit_State$State == State]
  perm = perm + rnorm(1, mean = 0, sd = 0.25 * perm /C_half + 0.001)
  
  intercon = (((1.7 - 3) / (60 - 100)) * (Power_MW - 60) + 1.7) * 1000000 # need NREL data
  
  if (intercon > 0) {
    
    intercon = intercon + rnorm(1, mean = 0, sd = 0.5 * intercon / C_half)
    
  } else {
    
    intercon = 0
    
  }
  
  insp = 10000 + runif(1, min = -5000, max = 5000)
  
  pii = perm + intercon + insp
  
  # contingency
  cont_perc = 0.04 + runif(1, min = -0.01, max = 0.01)
  contingency = cont_perc * (cost_mat_tot + cost_lab_tot)
  
  # net prof
  net_prof_perc = 0.05 + rnorm(1, mean = 0, sd = 0.025/C_half)
  net_prof = net_prof_perc * (cost_mat_tot + cost_lab_tot)
  
  # env study
  env_study = 10000 + runif(1, min = -5000, max = 5000)
  
  env_mitigation = 50000 + runif(1, min = -50000, max = 50000)
  
  env = env_study + env_mitigation
  
  # land acquisition
  land_aq = 250000 + runif(1, min = -0.5 *250000, max = 0.5 *250000)
  
  
  cost_Dev = dev_overhead + pii + contingency + net_prof + env + land_aq + cost_EPC_Overhead
  
  cost_Dev_kWh = cost_Dev / (Capacity_MWh * 1000)
  
  ##############################################################################
  # Non Battery LCA Matrix Items #
  ##############################################################################
  
  ### UPFRONT EMISSION ### (Remove replacement factors)
  
  # Battery assembly # energy / kWh - capacity
  
  BattAssembly_energy_tot = 0
  
  BattAssembly_energy_elec_kWh = 0
  BattAssembly_energy_therm_kWh = 0
  
  BattAssembly_energy_natgas_kWh = 0
  BattAssembly_energy_coal_kWh = 0
  
  # options for battery assembly energy total
  if(batt_assembly_input[1]=="Pilot") {
    
    BattAssembly_energy_tot = rtri(n, min = 100, max = 10000, mode = 1000) * 0.277778
    
  } else if(batt_assembly_input[1]=="Nth") {
    
    BattAssembly_energy_tot = runif(n, min = 100, max = 1000) * 0.277778
    
  } else if (batt_assembly_input[1]=="Unspec") {
    
    BattAssembly_energy_tot = rtri(n, min = 100, max = 10000, mode = 101) * 0.277778
    
  }
  
  # options for battery assembly energy scenarios
  if(batt_assembly_input[2]=="Max_therm") {
    
    BattAssembly_energy_elec_kWh = 0.2
    BattAssembly_energy_therm_kWh = 0.8
    
  } else if(batt_assembly_input[2]=="Min_therm") {
    
    BattAssembly_energy_elec_kWh = 1
    BattAssembly_energy_therm_kWh = 0
    
  } else if(batt_assembly_input[2]=="Unspec") {
    
    BattAssembly_energy_therm_kWh = rtri(n, min = 0, max = 0.8, mode = 0.4)
    BattAssembly_energy_elec_kWh = 1 - BattAssembly_energy_therm_kWh
    
  }
  
  # options for battery assembly thermal fuel source
  # if not relevant, does not matter which fuel type selected
  
  BattAssembly_energy_elec_kWh = BattAssembly_energy_elec_kWh * BattAssembly_energy_tot
  
  if(batt_assembly_input[3]=="Nat_gas") {
    
    BattAssembly_energy_natgas_kWh = BattAssembly_energy_therm_kWh * BattAssembly_energy_tot
    BattAssembly_energy_coal_kWh = 0
    
  } else if(batt_assembly_input[3]=="Coal") {
    
    BattAssembly_energy_natgas_kWh = 0
    BattAssembly_energy_coal_kWh = BattAssembly_energy_therm_kWh * BattAssembly_energy_tot
    
  } else if(batt_assembly_input[3]=="Unspec") {
    
    BattAssembly_energy_natgas_kWh = BattAssembly_energy_therm_kWh * BattAssembly_energy_tot * runif(n, min = 0, max = 1)
    BattAssembly_energy_coal_kWh = BattAssembly_energy_therm_kWh * BattAssembly_energy_tot - BattAssembly_energy_natgas_kWh
    
  }
  
  BattAssembly_input_col = c(BattAssembly_energy_elec_kWh, BattAssembly_energy_natgas_kWh, BattAssembly_energy_coal_kWh)
  BattAssembly_input_length = length(BattAssembly_input_col)
  BattAssembly_input_names = c("electricity.US.kWh", "natural.gas.kWh", "coal.kWh")
  
  BattAssembly_LCA_matrix = data.frame(rep("battery.assembly.kWh", BattAssembly_input_length),
                                       BattAssembly_input_names,
                                       BattAssembly_input_col,
                              rep("Yuan et al. 2021 and Porzio and Scown 2021", BattAssembly_input_length),
                              rep("NA", BattAssembly_input_length))
  colnames(BattAssembly_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  # Inverter # kg / inverter
  
  Inv_lifetime = 10
  
  if (Inv_lifetime <= Lifetime) {
    
    Inv_factor = ceiling(Lifetime / Inv_lifetime)
    
  } else {
    
    Inv_factor = 1
    
  }
  
  Inv_mass = 1987.3 * (Inv_Size_MW ^ 0.7484) * Inv_factor
  
  Inv_mass_steel = Inv_mass * 0.6024
  Inv_mass_aluminum = Inv_mass * 0.1774
  Inv_mass_copper = Inv_mass * 0.1240
  Inv_mass_plastics = Inv_mass * 0.0962
  
  Inv_energy_elec_kWh = 5.6856 * (Inv_Size_MW ^ 0.68) * Inv_factor
  Inv_energy_oil_MJ = 0.1211 * (Inv_Size_MW ^ 0.68) * Inv_factor
  Inv_energy_natgas_MJ = 1.9131 * (Inv_Size_MW ^ 0.68) * Inv_factor
  Inv_energy_heatwaste_MJ = 4.9277 * (Inv_Size_MW ^ 0.68) * Inv_factor

  Inv_emit_CO2 = 0
  Inv_emit_CH4 = 0
  Inv_emit_N20 = 0
  Inv_emit_VOC = 0
  Inv_emit_CO = 0
  Inv_emit_NOx = 0
  Inv_emit_PM10 = 0
  Inv_emit_PM25 = 0
  Inv_emit_SOx = 0
  
  Inv_input_col = c(Inv_mass_steel, Inv_mass_aluminum, Inv_mass_copper, Inv_mass_plastics,
                    Inv_energy_elec_kWh, Inv_energy_oil_MJ, Inv_energy_natgas_MJ, Inv_energy_heatwaste_MJ,
                    Inv_emit_CO2, Inv_emit_CH4, Inv_emit_N20, Inv_emit_VOC, Inv_emit_CO,
                    Inv_emit_NOx, Inv_emit_PM10, Inv_emit_PM25, Inv_emit_SOx)
  Inv_input_length = length(Inv_input_col)
  Inv_input_names = c("steel.kg", "aluminum.kg", "copper.kg", "nylon.kg", "electricity.US.kWh",
                      "residual.oil.MJ", "natural.gas.MJ", "heat.waste.MJ",
                      "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                      "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg")
  
  Inv_LCA_matrix = data.frame(rep("inverter.count", Inv_input_length),
                              Inv_input_names,
                              Inv_input_col,
                              rep("Rahman et al. 2021", Inv_input_length),
                              rep("https://doi.org/10.1016/j.enconman.2021.114497 - Mass size and energy from function in SI, mass breakdown from SI", Inv_input_length))
  colnames(Inv_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  # Transformer # kg / transformer
  
  Trans_lifetime = 40
  
  if (Trans_lifetime <= Lifetime) {
    
    Trans_factor = ceiling(Lifetime / Trans_lifetime)
    
  } else {
    
    Trans_factor = 1
    
  }
  
  Trans_mass = 2780.7 * (MV_Trans_Size_MW ^ 0.8674) * Trans_factor
  
  Trans_mass_oil = Trans_mass * 0.24
  Trans_mass_steel = Trans_mass * 0.56
  Trans_mass_copper = Trans_mass * 0.12
  Trans_mass_pressboard = Trans_mass * 0.03
  Trans_mass_paper = Trans_mass * 0.01
  Trans_mass_other = Trans_mass * 0.04
  
  Trans_energy_elec_kWh = 1.9933 * MV_Trans_Size_MW * 1000 * Trans_factor
  Trans_energy_natgas_MJ = 3.8652 * MV_Trans_Size_MW * 1000 * Trans_factor
  
  Trans_emit_CO2 = 0
  Trans_emit_CH4 = 0
  Trans_emit_N20 = 0
  Trans_emit_VOC = 0
  Trans_emit_CO = 0
  Trans_emit_NOx = 0
  Trans_emit_PM10 = 0
  Trans_emit_PM25 = 0
  Trans_emit_SOx = 0
  
  
  Trans_input_col = c(Trans_mass_oil, Trans_mass_steel, Trans_mass_copper, Trans_mass_pressboard,
                      Trans_mass_paper, Trans_mass_other, Trans_energy_elec_kWh, Trans_energy_natgas_MJ,
                      Trans_emit_CO2, Trans_emit_CH4, Trans_emit_N20, Trans_emit_VOC, Trans_emit_CO,
                      Trans_emit_NOx, Trans_emit_PM10, Trans_emit_PM25, Trans_emit_SOx)
  Trans_input_length = length(Trans_input_col)
  Trans_input_names = c("transformer.oil.kg", "steel.kg", "copper.kg", "pressboard.kg",
                      "paper.kg", "other.kg", "electricity.US.kWh", "natural.gas.MJ",
                      "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                      "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg")
  
  Trans_LCA_matrix = data.frame(rep("transformer.count", Trans_input_length),
                              Trans_input_names,
                              Trans_input_col,
                              rep("Rahman et al. 2021", Trans_input_length),
                              rep("https://doi.org/10.1016/j.enconman.2021.114497 - Mass size from function in SI, mass breakdown from SI, energy demand assumed linear with trans_size_mw from DOI: 10.1089/ees.2018.0256", Trans_input_length))
  colnames(Trans_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  # Switchgear # kg / switchgear
  
  Switch_lifetime = 40
  
  if (Switch_lifetime <= Lifetime) {
    
    Switch_factor = ceiling(Lifetime / Switch_lifetime)
    
  } else {
    
    Switch_factor = 1
    
  }
  
  Switch_mass = 2400 * Switch_factor
  
  Switch_mass_aluminum = Switch_mass * 0.15
  Switch_mass_steel = Switch_mass * 0.3167
  Switch_mass_stainless = Switch_mass * 0.0179167
  Switch_mass_copper = Switch_mass * 0.010833
  Switch_mass_sf6 = Switch_mass * 0.004167 * Lifetime * 0.02
  Switch_mass_epdm = Switch_mass * 0.0005
  Switch_mass_copper_tungsten = Switch_mass * 0.00125
  Switch_mass_ptfe = Switch_mass * 0.000625
  Switch_mass_epoxy_resin = Switch_mass * 0.001667
  Switch_mass_molecular_sieve = Switch_mass * 0.00070833
  Switch_mass_porcelain = Switch_mass * 0.441667
  Switch_mass_other = Switch_mass * 0.054
  
  Switch_energy_elec_kWh = 1.9933 * MV_Switch_Size_MW * 1000 * Switch_factor
  Switch_energy_natgas_MJ = 3.8652 * MV_Switch_Size_MW * 1000 * Switch_factor
  
  Switch_emit_CO2 = 0
  Switch_emit_CH4 = 0
  Switch_emit_N20 = 0
  Switch_emit_VOC = 0
  Switch_emit_CO = 0
  Switch_emit_NOx = 0
  Switch_emit_PM10 = 0
  Switch_emit_PM25 = 0
  Switch_emit_SOx = 0
  
  Switch_input_col = c(Switch_mass_aluminum, Switch_mass_steel, Switch_mass_stainless, Switch_mass_copper,
                       Switch_mass_sf6, Switch_mass_epdm, Switch_mass_copper_tungsten, Switch_mass_ptfe,
                       Switch_mass_epoxy_resin, Switch_mass_molecular_sieve, Switch_mass_porcelain, Switch_mass_other,
                       Switch_energy_elec_kWh, Switch_energy_natgas_MJ,
                       Switch_emit_CO2, Switch_emit_CH4, Switch_emit_N20, Switch_emit_VOC, Switch_emit_CO,
                       Switch_emit_NOx, Switch_emit_PM10, Switch_emit_PM25, Switch_emit_SOx)
            
  Switch_input_length = length(Switch_input_col)
  Switch_input_names = c("aluminum.virgin.wrought.kg", "steel.kg", "stainless.steel.kg", "copper.kg",
                         "SF6.kg", "epdm.kg", "copper.tungsten.kg", "ptfe.kg",
                         "epoxy.resin.kg", "molecular.sieve.kg", "porcelain.kg", "other.kg",
                         "electricity.US.kWh", "natural.gas.MJ",
                         "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                         "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg")
  
  Switch_LCA_matrix = data.frame(rep("Switchgear.count", Switch_input_length),
                                Switch_input_names,
                                Switch_input_col,
                                rep("EPA Circuit Breaker", Switch_input_length),
                                rep("https://www.epa.gov/sites/default/files/2016-02/documents/conf00_krondorfer.pdf - mass breakdown from EPA, energy use modeled off inverter", Switch_input_length))
  colnames(Switch_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  
  
  # Conductor # kg / ft
  
  Conductor_mass_xlpe = 0.1643 # name as HDPE to enact assumption that xlpe modeled as HDPE
  Conductor_mass_copper = 0.887
  
  Conductor_emit_CO2 = 0
  Conductor_emit_CH4 = 0
  Conductor_emit_N20 = 0
  Conductor_emit_VOC = 0
  Conductor_emit_CO = 0
  Conductor_emit_NOx = 0
  Conductor_emit_PM10 = 0
  Conductor_emit_PM25 = 0
  Conductor_emit_SOx = 0
  
  Conductor_input_col = c(Conductor_mass_xlpe, Conductor_mass_copper,
                          Conductor_emit_CO2, Conductor_emit_CH4, Conductor_emit_N20, Conductor_emit_VOC, Conductor_emit_CO,
                          Conductor_emit_NOx, Conductor_emit_PM10, Conductor_emit_PM25, Conductor_emit_SOx)
  
  Conductor_input_length = length(Conductor_input_col)
  Conductor_input_names = c("HDPE.kg", "copper.kg",
                            "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                            "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg")
  
  Conductor_LCA_matrix  = data.frame(rep("Conductor.ft", Conductor_input_length),
                                     Conductor_input_names,
                                     Conductor_input_col,
                                     rep("Calcs", Conductor_input_length),
                                     rep("See excel for calcs + assumptions", Conductor_input_length))
  colnames(Conductor_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")

  
  # Conduits # kg/ft
  
  Conduit_mass_galv = 2.1098
  
  Conduit_emit_CO2 = 0
  Conduit_emit_CH4 = 0
  Conduit_emit_N20 = 0
  Conduit_emit_VOC = 0
  Conduit_emit_CO = 0
  Conduit_emit_NOx = 0
  Conduit_emit_PM10 = 0
  Conduit_emit_PM25 = 0
  Conduit_emit_SOx = 0
  
  Conduit_input_col = c(Conduit_mass_galv,
                        Conduit_emit_CO2, Conduit_emit_CH4, Conduit_emit_N20, Conduit_emit_VOC, Conduit_emit_CO,
                        Conduit_emit_NOx, Conduit_emit_PM10, Conduit_emit_PM25, Conduit_emit_SOx)
  
  Conduit_input_length = length(Conduit_input_col)
  Conduit_input_names = c("galvanized.steel.kg",
                          "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                          "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg")
  
  Conduit_LCA_matrix  = data.frame(rep("Conduit.ft", Conduit_input_length),
                                     Conduit_input_names,
                                     Conduit_input_col,
                                     rep("Calcs", Conduit_input_length),
                                     rep("See excel for calcs + assumptions", Conduit_input_length))
  colnames(Conduit_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  
  # BMS #
  
  BMS_mass_copper = 0.08787
  BMS_mass_glass_fiber = 0.09989
  BMS_mass_epoxy_resin = 0.03034
  BMS_mass_steel = 0.4299
  BMS_mass_aluminum = 0.04528
  BMS_mass_nylon = 0.04210
  BMS_mass_hdpe = 0.04566
  BMS_mass_pc = 0.08393
  BMS_energy_elec_kWh = 1.0275
  BMS_energy_natgas_MJ = 0.03661
  
  BMS_input_col = c(BMS_mass_copper, BMS_mass_glass_fiber, BMS_mass_epoxy_resin,
                    BMS_mass_steel, BMS_mass_aluminum, BMS_mass_nylon,
                    BMS_mass_hdpe, BMS_mass_pc, BMS_energy_elec_kWh,
                    BMS_energy_natgas_MJ) # replace
  
  BMS_input_length = length(BMS_input_col)
  BMS_input_names = c("copper.kg", "glass.fiber.kg", "epoxy.resin.kg",
                      "steel.virgin.hotrolled.kg", "aluminum.virgin.wrought.kg",
                      "nylon.kg", "HDPE.kg", "PC.kg", "electricity.US.kWh",
                      "naturalgas_select.MJ")
  
  BMS_LCA_matrix = data.frame(rep("BMS.kg", BMS_input_length),
                              BMS_input_names,
                              BMS_input_col,
                              rep("Farzad 2019", BMS_input_length),
                              rep("http://www.diva-portal.org/smash/get/diva2:1367018/FULLTEXT01.pdf"))
  colnames(BMS_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  
  # Fire-Sup # kg per battery container
  
  Fire_ghg_lifetime = 10
  
  if (Fire_ghg_lifetime <= Lifetime) {
    
    Fire_ghg_factor = ceiling(Lifetime / Fire_ghg_lifetime)
    
  } else {
    
    Fire_ghg_factor = 1
    
  }
  
  
  if(Cont_type == "40 ft") {
    
    Fire_mass_galv =  635.8137 # per cont
    Fire_mass_agent = 193.0932 * runif(n, min = 0.025, max = 0.075) * Fire_ghg_factor # MAY NEED TO ADJUST IF BIGGER TANK REQUIRED
    
  } else if (Cont_type == "20 ft") {
    
    Fire_mass_galv =  408.7374 # per cont
    Fire_mass_agent = 96.5466 * runif(n, min = 0.025, max = 0.075) * Fire_ghg_factor
    
  } else if (Cont_type == "Cabinet") {
    
    Fire_mass_galv =  408.7374/4 # per cont
    Fire_mass_agent = 96.5466/4 * runif(n, min = 0.025, max = 0.075) * Fire_ghg_factor
    
  }
  
  Fire_emit_CO2 = 0
  Fire_emit_CH4 = 0
  Fire_emit_N20 = 0
  Fire_emit_VOC = 0
  Fire_emit_CO = 0
  Fire_emit_NOx = 0
  Fire_emit_PM10 = 0
  Fire_emit_PM25 = 0
  Fire_emit_SOx = 0
  
  Fire_input_col = c(Fire_mass_galv, Fire_mass_agent,
                     Fire_emit_CO2, Fire_emit_CH4, Fire_emit_N20, Fire_emit_VOC, Fire_emit_CO,
                     Fire_emit_NOx, Fire_emit_PM10, Fire_emit_PM25, Fire_emit_SOx)
  
  Fire_input_length = length(Fire_input_col)
  Fire_input_names = c("galvanized.steel.kg", "FM200.HFC227.agent.kg",
                       "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                       "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg")
  
  Fire_LCA_matrix  = data.frame(rep("Fire.cont", Fire_input_length),
                                   Fire_input_names,
                                   Fire_input_col,
                                   rep("Calcs", Fire_input_length),
                                   rep("See excel for calcs, assumptions, and sources", Fire_input_length))
  colnames(Fire_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  # Thermals # kg per battery container
  
  HVAC_lifetime = 15
  
  if (HVAC_lifetime <= Lifetime) {
    
    HVAC_factor = ceiling(Lifetime / HVAC_lifetime)
    
  } else {
    
    HVAC_factor = 1
    
  }
  
  
  if(Cont_type == "40 ft") {
    
    HVAC_mass_steel = 156 * HVAC_factor
    HVAC_mass_galv = 70 * HVAC_factor
    HVAC_mass_aluminum = 34 * HVAC_factor
    HVAC_mass_copper = 34 * HVAC_factor
    
    r410a_annual = 2 * (3.33 * runif(n, min = 2, max = 3) * (rtri(n, min = 0.02, max = 0.20, mode = 0.10)))* 0.453592
    r410a_eol = 2 * 3.33 * runif(n, min = 2, max = 3) * rtri(n, min = 0.15, max = 1, mode = 0.56) * 0.453592
    
    # HVAC_mass_r410a = 2 * (3.33 * runif(n, min = 2, max = 3) * (rtri(n, min = 0.02, max = 0.20, mode = 0.10) * Lifetime + 
    #                                                            rtri(n, min = 0.15, max = 1, mode = 0.56) * HVAC_factor)) * 0.453592      # (1.33*Lifetime + 7.46)*HVAC_factor ## runif(n, min = 100, max = 400)

  } else if (Cont_type == "20 ft") {
    
    HVAC_mass_steel = 78 * HVAC_factor
    HVAC_mass_galv = 35 * HVAC_factor
    HVAC_mass_aluminum = 17 * HVAC_factor
    HVAC_mass_copper = 17 * HVAC_factor
    
    r410a_annual = (3.33 * runif(n, min = 2, max = 3) * (rtri(n, min = 0.02, max = 0.20, mode = 0.10)))* 0.453592
    r410a_eol = 3.33 * runif(n, min = 2, max = 3) * rtri(n, min = 0.15, max = 1, mode = 0.56) * 0.453592
    
    # HVAC_mass_r410a = (3.33 * runif(n, min = 2, max = 3) * (rtri(n, min = 0.02, max = 0.20, mode = 0.10) * Lifetime + 
    #                                                          rtri(n, min = 0.15, max = 1, mode = 0.56) * HVAC_factor)) * 0.453592     # (1.33*Lifetime + 7.46)*HVAC_factor ## runif(n, min = 100, max = 400)
    
  } else if (Cont_type == "Cabinet") { ## WILL NEED TO UPDATE THIS
    
    HVAC_mass_steel = 0 # 78 * HVAC_factor
    HVAC_mass_galv = 0 # 35 * HVAC_factor
    HVAC_mass_aluminum = 0 # 17 * HVAC_factor
    HVAC_mass_copper =0  # 17 * HVAC_factor
    
    r410a_annual = 0
    r410a_eol = 0
    
  }
  
  HVAC_mass_r410a = r410a_annual * Lifetime + r410a_eol * HVAC_factor
  
  if(refrigerant=="r32.kg") {
    
    HVAC_mass_r410a = HVAC_mass_r410a * runif(n, min = 0.7, max = 0.9)
    
  }
  
  HVAC_emit_CO2 = 0
  HVAC_emit_CH4 = 0
  HVAC_emit_N20 = 0
  HVAC_emit_VOC = 0
  HVAC_emit_CO = 0
  HVAC_emit_NOx = 0
  HVAC_emit_PM10 = 0
  HVAC_emit_PM25 = 0
  HVAC_emit_SOx = 0
  
  HVAC_input_col = c(HVAC_mass_steel, HVAC_mass_galv, HVAC_mass_aluminum, HVAC_mass_copper, HVAC_mass_r410a,
                     HVAC_emit_CO2, HVAC_emit_CH4, HVAC_emit_N20, HVAC_emit_VOC, HVAC_emit_CO,
                     HVAC_emit_NOx, HVAC_emit_PM10, HVAC_emit_PM25, HVAC_emit_SOx)
  
  HVAC_input_length = length(HVAC_input_col)
  HVAC_input_names = c("steel.kg", "galvanized.steel.kg", "aluminum.kg", "copper.kg", refrigerant,
                       "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                       "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg") # MAKE REFRIGERANT VARIABLE
  
  HVAC_LCA_matrix  = data.frame(rep("HVAC.cont", HVAC_input_length),
                                HVAC_input_names,
                                HVAC_input_col,
                                rep("Calcs", HVAC_input_length),
                                rep("See excel for calcs, assumptions, and sources", HVAC_input_length))
  colnames(HVAC_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  # Batt House # 
  
  if(Cont_type == "40 ft") {
    
    Battcont_mass_steel = 3562.875
    Battcont_mass_wood = 637.125
    
  } else if (Cont_type == "20 ft") {
    
    Battcont_mass_steel = 1881.437
    Battcont_mass_wood = 318.563
    
  } else if (Cont_type == "Cabinet") {
    
    Battcont_mass_steel = 212.712
    Battcont_mass_wood = 0
    
  }
  
  Battcont_emit_CO2 = 0
  Battcont_emit_CH4 = 0
  Battcont_emit_N20 = 0
  Battcont_emit_VOC = 0
  Battcont_emit_CO = 0
  Battcont_emit_NOx = 0
  Battcont_emit_PM10 = 0
  Battcont_emit_PM25 = 0
  Battcont_emit_SOx = 0
  
  Battcont_input_col = c(Battcont_mass_steel, Battcont_mass_wood,
                         Battcont_emit_CO2, Battcont_emit_CH4, Battcont_emit_N20, Battcont_emit_VOC, Battcont_emit_CO,
                         Battcont_emit_NOx, Battcont_emit_PM10, Battcont_emit_PM25, Battcont_emit_SOx)
  
  Battcont_input_length = length(Battcont_input_col)
  Battcont_input_names = c("steel.kg", "wood.kg",
                           "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                           "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg")
  
  Battcont_LCA_matrix  = data.frame(rep("Battcont.cont", Battcont_input_length),
                                Battcont_input_names,
                                Battcont_input_col,
                                rep("Calcs", Battcont_input_length),
                                rep("See excel for calcs, assumptions, and sources", Battcont_input_length))
  colnames(Battcont_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  

  # Inv House #
  
  if(Inv_type == "20 ft") {
    
    Invcont_mass_steel = 1881.437
    Invcont_mass_wood = 318.563
    
  } else if (Inv_type == "Cabinet") {
    
    Invcont_mass_steel = 212.712
    Invcont_mass_wood = 0
    
  } else if (Inv_type == "In_Batt") {
    
    Invcont_mass_steel = 0
    Invcont_mass_wood = 0
    
  }
  
  
  Invcont_emit_CO2 = 0
  Invcont_emit_CH4 = 0
  Invcont_emit_N20 = 0
  Invcont_emit_VOC = 0
  Invcont_emit_CO = 0
  Invcont_emit_NOx = 0
  Invcont_emit_PM10 = 0
  Invcont_emit_PM25 = 0
  Invcont_emit_SOx = 0
  
  
  Invcont_input_col = c(Invcont_mass_steel, Invcont_mass_wood,
                        Invcont_emit_CO2, Invcont_emit_CH4, Invcont_emit_N20, Invcont_emit_VOC, Invcont_emit_CO,
                        Invcont_emit_NOx, Invcont_emit_PM10, Invcont_emit_PM25, Invcont_emit_SOx)
  
  Invcont_input_length = length(Invcont_input_col)
  Invcont_input_names = c("steel.kg", "wood.kg",
                          "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                          "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg")
  
  Invcont_LCA_matrix  = data.frame(rep("Invcont.cont", Invcont_input_length),
                                    Invcont_input_names,
                                    Invcont_input_col,
                                    rep("Calcs", Invcont_input_length),
                                    rep("See excel for calcs, assumptions, and sources", Invcont_input_length))
  colnames(Invcont_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  
  # Foundation # put concrete emissions as direct
  
  Found_mass_conc = mat_l # cubic yards total
  
  Found_energy_resoil = (0.09*(3.65)*(0.004) + 0.84*(0.01)*(0) + (0.01)*(0)) * 0.323055463
  Found_energy_diesel = (0.09*(3.65)*(0.008) + 0.84*(0.01)*(0) + (0.01)*(0.279)) * 0.323055463
  Found_energy_petcoke = (0.09*(3.65)*(0.174) + 0.84*(0.01)*(0) + (0.01)*(0)) * 0.323055463
  Found_energy_natgas = (0.09*(3.65)*(0.157) + 0.84*(0.01)*(0.143) + (0.01)*(0.31)) * 0.323055463
  Found_energy_coal = (0.09*(3.65)*(0.397) + 0.84*(0.01)*(0) + (0.01)*(0)) * 0.323055463
  Found_energy_waste = (0.09*(3.65)*(0.045) + 0.84*(0.01)*(0) + (0.01)*(0)) * 0.323055463
  Found_energy_tire = (0.09*(3.65)*(0.04) + 0.84*(0.01)*(0) + (0.01)*(0)) * 0.323055463
  Found_energy_solvents  = (0.09*(3.65)*(0.051) + 0.84*(0.01)*(0) + (0.01)*(0)) * 0.323055463
  Found_energy_wasteoil = (0.09*(3.65)*(0.007) + 0.84*(0.01)*(0) + (0.01)*(0)) * 0.323055463
  Found_energy_renewables = (0.09*(3.65)*(0.007) + 0.84*(0.01)*(0) + (0.01)*(0)) * 0.323055463
  Found_energy_elec = (0.09*(3.65)*(0.111) + 0.84*(0.01)*(0.857) + (0.01)*(0.41)) * 0.323055463
  
  Found_emit_CO2 = (0.09*(787232+42.314) + 0.84*(24+947.94) + (3.572+221.317))/907185
  Found_emit_CH4 = (0.09*(31+0.05) + 0.84*(0+1.1) + (0.1+0.26))/907185
  Found_emit_N20 = (0.09*(4.4+0.001) + 0.84*(0+0.022) + (0+0.005))/907185
  Found_emit_VOC = (0.09*(71.1+0.022) + 0.84*(0+1.288) + (63+0.114))/907185
  Found_emit_CO = (0.09*(1087.9+0.082) + 0.84*(1.7+2.814) + (10.9+0.426))/907185
  Found_emit_NOx = (0.09*(1136.2+0.226) + 0.84*(3.8+4.338) + (18.1+1.181))/907185
  Found_emit_PM10 = (0.09*(191.6+0.009) + 0.84*(5.5+0.225) + (45.1+0.047))/907185
  Found_emit_PM25 = (0.09*(109.6+0.009) + 0.84*(1.8+0.182) + (11.7+0.045))/907185
  Found_emit_SOx = (0.09*(259.6+0.004) + 0.84*(0.4+1.346) + (3.4+0.019))/907185
  
  Found_water = (0.09*(170) + 0.91*(120) + (17))*0.004172699
  
  
  Found_input_col = c(Found_mass_conc, Found_energy_resoil, Found_energy_diesel, Found_energy_petcoke,
                      Found_energy_natgas, Found_energy_coal, Found_energy_waste, Found_energy_tire,
                      Found_energy_solvents, Found_energy_wasteoil, Found_energy_renewables, Found_energy_elec,
                      Found_emit_CO2, Found_emit_CH4, Found_emit_N20, Found_emit_VOC, Found_emit_CO,
                      Found_emit_NOx, Found_emit_PM10, Found_emit_PM25, Found_emit_SOx)
  
  Found_input_length = length(Found_input_col)
  Found_input_names = c("concrete.cby", "residual.oil.kWh", "diesel.kWh", "petroleum.coke.kWh",
                        "natural.gas.kWh", "coal.kWh", "heat.waste.kWh", "tire.kWh",
                        "solvents.kWh", "waste.oil.kWh", "renewables.kWh", "electricity.US.kWh",
                        "CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                        "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg") 
  
  Found_LCA_matrix = data.frame(rep("Found.quant", Found_input_length),
                               Found_input_names,
                               Found_input_col,
                               rep("source_short_temp", Found_input_length), 
                               rep("temporary value for Found - will replace later")) 
  colnames(Found_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  
  # Comms ### TEMPORARY VALUES - NEED TO REPLACE ###
  
  Comm_mass_temp = 0 # replace
  Comm_input_col = c(Comm_mass_temp) # replace
  
  Comm_input_length = length(Comm_input_col)
  Comm_input_names = c("temp.unit") # replace
  
  Comm_LCA_matrix = data.frame(rep("Comm.quant", Comm_input_length),
                              Comm_input_names,
                              Comm_input_col,
                              rep("source_short_temp", Comm_input_length), # replace
                              rep("temporary value for Comm - will replace later")) # replace
  colnames(Comm_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  

  # Battery trays ###
  
  Tray_mass = runif(n, min = 100, max = 400) * rack_per_cont
  Tray_input_col = c(Tray_mass) # replace
  
  Tray_input_length = length(Tray_input_col)
  Tray_input_names = c("steel.kg") # replace
  
  Tray_LCA_matrix = data.frame(rep("Rack.cont", Tray_input_length),
                               Tray_input_names,
                               Tray_input_col,
                               rep("sampled technical specs", Tray_input_length), # replace
                               rep("Samsung UPS, Samsung Utility, LG utility")) # replace
  colnames(Tray_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  # Coal Combustion ###
  
  coal_emit_CO2 = runif(n, min = 0.100208333, max = 0.130208333)
  coal_emit_CH4 = 0
  coal_emit_N20 = 0
  coal_emit_VOC = runif(n, min = 0.000016667, max = 0.000070833)
  coal_emit_CO = 0 # CO2 EF assumes all carbon to CO2
  coal_emit_NOx = runif(n, min = 0.000104167, max = 0.0006875)
  coal_emit_PM10 = runif(n, min = 0.000005417, max = 0.000258333)
  coal_emit_PM25 = 0
  coal_emit_SOx = runif(n, min = 0.000645833, max = 0.000791667)
  
  coal_input_col = c(coal_emit_CO2, coal_emit_CH4, coal_emit_N20, coal_emit_VOC, coal_emit_CO,
                      coal_emit_NOx, coal_emit_PM10, coal_emit_PM25, coal_emit_SOx)
  
  coal_input_length = length(coal_input_col)
  coal_input_names = c("CO2.kg", "CH4.kg", "N20.kg", "VOC.kg", "CO.kg",
                        "NOx.kg", "PM10.kg", "PM25.kg", "SOx.kg") 
  
  coal_LCA_matrix = data.frame(rep("coal_combustion.MJ", coal_input_length),
                                coal_input_names,
                                coal_input_col,
                                rep("epa", coal_input_length), 
                                rep("https://www.epa.gov/sites/default/files/2020-09/documents/1.1_bituminous_and_subbituminous_coal_combustion.pdf")) 
  colnames(coal_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  # Purchased Electricity ### Assume from solar
  
  pel_energy_solar = Capacity_MWh * 1000 / (RTE_tot)
  
  pel_input_col = c(pel_energy_solar)
  
  pel_input_length = length(pel_input_col)
  pel_input_names = c(purchased_electricity) 
  
  pel_LCA_matrix = data.frame(rep("purchased.electricity.cycle", pel_input_length),
                              pel_input_names,
                              pel_input_col,
                              rep("batt_size", pel_input_length), 
                              rep("NA")) 
  colnames(pel_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  # Sold Electricity ### Assume offsets gas
  
  sel_energy_solar =  (-1) * Capacity_MWh * 1000
  
  sel_input_col = c(sel_energy_solar)
  
  sel_input_length = length(sel_input_col)
  sel_input_names = c(sold_electricity) 
  
  sel_LCA_matrix = data.frame(rep("sold.electricity.cycle", sel_input_length),
                              sel_input_names,
                              sel_input_col,
                              rep("batt_size", sel_input_length), 
                              rep("NA")) 
  colnames(sel_LCA_matrix) = c("row_name", "col_name", "value", "source_short", "notes")
  
  
  ### Full LCA Matrix ###
  
  LCA_matrix = rbind(BattAssembly_LCA_matrix, Inv_LCA_matrix, Trans_LCA_matrix, Switch_LCA_matrix, Conductor_LCA_matrix, 
                     Conduit_LCA_matrix, BMS_LCA_matrix, Fire_LCA_matrix, HVAC_LCA_matrix,
                     Battcont_LCA_matrix, Invcont_LCA_matrix, Found_LCA_matrix,
                     # Comm_LCA_matrix, 
                     Tray_LCA_matrix,
                     coal_LCA_matrix,
                     pel_LCA_matrix,
                     sel_LCA_matrix)
  
  
  ### LCA Matrix Cleaning ### CHANGE FROM NATURALGAS_SELECT.MJ TO NATURALGAS_SELECT_PLUSCOMBUST.MJ
  
  # natural gas
  LCA_matrix$value[LCA_matrix$col_name=="natural.gas.kWh"] = LCA_matrix$value[LCA_matrix$col_name=="natural.gas.kWh"]* 3.6
  # LCA_matrix[LCA_matrix=="natural.gas.kWh"] = "naturalgas_select.MJ" 
  # LCA_matrix[LCA_matrix=="natural.gas.MJ"] = "naturalgas_select.MJ" 
  
  LCA_matrix[LCA_matrix=="natural.gas.kWh"] = "naturalgas_combust.MJ" # edit these if io table doesn't look right, top 14 rows should switch to combust
  LCA_matrix[LCA_matrix=="natural.gas.MJ"] = "naturalgas_combust.MJ"
  
  # coal
  LCA_matrix$value[LCA_matrix$col_name=="coal.kWh"] = LCA_matrix$value[LCA_matrix$col_name=="coal.kWh"]* 3.6
  LCA_matrix[LCA_matrix=="coal.kWh"] = "coal.MJ" 
  
  # diesel
  LCA_matrix$value[LCA_matrix$col_name=="diesel.kWh"] = LCA_matrix$value[LCA_matrix$col_name=="diesel.kWh"]* 3.6
  LCA_matrix[LCA_matrix=="diesel.kWh"] = "diesel.MJ" 
  
  # residual oil
  LCA_matrix$value[LCA_matrix$col_name=="residual.oil.kWh"] = LCA_matrix$value[LCA_matrix$col_name=="residual.oil.kWh"]* 3.6
  LCA_matrix[LCA_matrix=="residual.oil.kWh"] = "rfo.MJ"
  LCA_matrix[LCA_matrix=="residual.oil.MJ"] = "rfo.MJ"
  
  # wood
  LCA_matrix$value[LCA_matrix$col_name=="wood.kg"] = LCA_matrix$value[LCA_matrix$col_name=="wood.kg"] / 750
  LCA_matrix[LCA_matrix=="wood.kg"] = "mpp.pnw.m3"
  
  
  # name change
  LCA_matrix[LCA_matrix=="aluminum.kg"] = "aluminum.virgin.wrought.kg"
  LCA_matrix[LCA_matrix=="steel.kg"] = "steel.virgin.hotrolled.kg"
  LCA_matrix[LCA_matrix=="stainless.steel.kg"] = "stainless.steel.machined.kg"
  LCA_matrix[LCA_matrix=="galvanized.steel.kg"] = "steel.virgin.galvanized.kg"
  LCA_matrix[LCA_matrix=="FM200.HFC227.agent.kg"] = "HFC.227ea.kg"
  LCA_matrix[LCA_matrix=="r410a.kg"] = "R410a.kg"
  
  # write.xlsx(LCA_matrix, "test_LCA_matric_v3.xlsx")
  
  
  
  
  ##############################################################################
  # Graphing #
  ##############################################################################
  
  # "zBatt",
  # "yInv",
  # "xcBOS",
  # "weBOS",
  # "vsBOS",
  # "ulab_eq_kWh",
  # "tsales_tax_kWh",
  # "sdev_cost_kWh")
  
  dur_temp = Dur_Table$dur_char[Dur_Table$dur_num==Duration]
  
  graph_order = c("Developer Costs", 
                  "Sales Tax", 
                  "Inst. and Labor", 
                  "Structural BOS", 
                  "Electrical BOS",
                  "Container BOS",
                  "Inverter",
                  "Battery")
  graph_order = factor(graph_order)
  
  df_tot_graph = data.frame(
    round(
      c(
        cost_Dev_kWh,
        cost_st_kWh,
        cost_lab_tot_kWh,
        cost_mat_sBOS_kWh,
        cost_mat_eBOS_kWh,
        cost_mat_cBOS_kWh,
        cost_mat_inv_kWh,
        cost_mat_batt_kWh
      )
    ),
    factor(c(
      "Dev",
      "sales_tax_kWh",
      "sBOS",
      "eBOS",
      "cBOS",
      "lab_eq_kWh",
      "Inv",
      "zbatt"
    )),
    rep(dur_temp,8),
    c(
      cost_mat_batt_kWh + cost_mat_inv_kWh + cost_mat_cBOS_kWh + cost_mat_eBOS_kWh + cost_mat_sBOS_kWh + cost_lab_tot_kWh + cost_st_kWh + cost_Dev_kWh,
      cost_mat_batt_kWh + cost_mat_inv_kWh + cost_mat_cBOS_kWh + cost_mat_eBOS_kWh + cost_mat_sBOS_kWh + cost_lab_tot_kWh + cost_st_kWh,
      cost_mat_batt_kWh + cost_mat_inv_kWh + cost_mat_cBOS_kWh + cost_mat_eBOS_kWh + cost_mat_sBOS_kWh + cost_lab_tot_kWh,
      cost_mat_batt_kWh + cost_mat_inv_kWh + cost_mat_cBOS_kWh + cost_mat_eBOS_kWh + cost_mat_sBOS_kWh,
      cost_mat_batt_kWh + cost_mat_inv_kWh + cost_mat_cBOS_kWh + cost_mat_eBOS_kWh,
      cost_mat_batt_kWh + cost_mat_inv_kWh + cost_mat_cBOS_kWh,
      cost_mat_batt_kWh + cost_mat_inv_kWh,
      cost_mat_batt_kWh),
    
    c(1, 2, 3, 4, 5, 6, 7, 8),
    rep(Chem, 8),
    rep(City,8),
    rep(State,8)
    
  )
  colnames(df_tot_graph) = c("Cost", "Component", "Duration", "ypos", "temp", "Chemistry", "City", "State")
  
  df_tot_graph$Component = graph_order
  df_tot_graph$Component <- factor(df_tot_graph$Component, levels = df_tot_graph$Component[order(df_tot_graph$temp)])
  
  # mat matrix sizing
  
  mat_key = data.frame(c(Cap_Adj, mat_b, mat_c, mat_d, mat_e, mat_f, mat_g, mat_h,
                         mat_i, mat_j, mat_k, mat_l, Tot_site, mat_n, mat_o, mat_p,
                         mat_q, mat_r, mat_s, mat_t))
  colnames(mat_key) = c("Quant")
  
  ##############################################################################
  # LCA Cleaning, Assembly, and csv Writing #
  ##############################################################################
  
  runs_LCA = LCA_matrix
  
  dim_runs_LCA = dim(runs_LCA)
  
  temp_LCA = LCA_matrix
  
  results_mat = mat_key
  
  
  
  ### formatting of LCA inputs ###
  
  # chemistry name tranformation #
  
  chemistry_transformation = data.frame(c("NCA Graphite", "LFP Graphite",
                                          "NMC Graphite", "LMO Graphite",
                                          "NMC Graphite 111", "NMC Graphite 532",
                                          "NMC Graphite 622", "NMC Graphite 811", 
                                          "LFP Graphite HT", "LFP Graphite SS"),
                                        c("NCA.kg", "LFP-SS.kg", "NMC-811.kg", 
                                          "LMO.kg", "NMC-111.kg", "NMC-532.kg",
                                          "NMC-622.kg", "NMC-811.kg", "LFP-HT.kg",
                                          "LFP-SS.kg"))
  colnames(chemistry_transformation) = c("Chem_Input", "Chem_LCA")
  chemistry_LCA = chemistry_transformation$Chem_LCA[chemistry_transformation$Chem_Input==Chem]
  
  # battery kWh to battery materials
  
  dim_results_mat = dim(mat_key)
  
  batt_mat_names = Battery_materials$`cell material (g/kWh)`
  batt_mat_names[1] = chemistry_LCA
  
  batt_mat_input = data.frame(batt_mat_names, Battery_materials[,chemistry_LCA] * results_mat$Quant[1] * 1000 / 1000) # *1000/1000 for units
  
  colnames(batt_mat_input) = c("input_name", "value")
  
  # non battery material cleaning and naming
  
  results_mat_names = c("inverter.count", "transformer.count", "Switchgear.count",
                        "Conductor.ft", "Conduit.ft", "BMS.remove", "Fire.cont",
                        "HVAC.cont", "Battcont.cont", "Invcont.cont", "Found.quant")
  
  results_mat_input = data.frame(matrix(NA, nrow = 11, ncol = 2))
  
  colnames(results_mat_input) = c("input_name", "value")
  
  results_mat_input$value = results_mat$Quant[2:12]
  
  results_mat_input$input_name = results_mat_names
  
  results_mat_input = rbind(batt_mat_input, results_mat_input)
  
  results_mat_input = rbind(results_mat_input,
                            c("Rack.cont",results_mat_input$value[results_mat_input$input_name=="Fire.cont"]),
                            c("battery.assembly.kWh", results_mat$Quant[1]*1000),
                            c("purchased.electricity.cycle", Cycle_per_year * Lifetime),
                            c("sold.electricity.cycle", Cycle_per_year * Lifetime)
                            )
  
  
  ### formatting temp_LCA into io_matrix and impact vectors
  
  Li_ion_Battery_LCA_clean = data.frame(Li_ion_Battery_LCA$row_name, Li_ion_Battery_LCA$col_name,
                                        Li_ion_Battery_LCA$value, Li_ion_Battery_LCA$source_short,
                                        Li_ion_Battery_LCA$notes)
  colnames(Li_ion_Battery_LCA_clean) = c("row_name", "col_name", "value", "source_short", "notes")
  
  tot_LCA = rbind(temp_LCA, Li_ion_Battery_LCA_clean)
  
  co2_impact = tot_LCA[tot_LCA$col_name=="CO2.kg",]
  ch4_impact = tot_LCA[tot_LCA$col_name=="CH4.kg",]
  n2o_impact = tot_LCA[tot_LCA$col_name=="N2O.kg",]
  voc_impact = tot_LCA[tot_LCA$col_name=="VOC.kg",]
  co_impact = tot_LCA[tot_LCA$col_name=="CO.kg",]
  nox_impact = tot_LCA[tot_LCA$col_name=="NOx.kg",]
  pm10_impact = tot_LCA[tot_LCA$col_name=="PM10.kg",]
  pm25_impact = tot_LCA[tot_LCA$col_name=="PM25.kg",]
  sox_impact = tot_LCA[tot_LCA$col_name=="SOx.kg",]
  
  co2_impact = data.frame(co2_impact$row_name, co2_impact$value)
  ch4_impact = data.frame(ch4_impact$row_name, ch4_impact$value)
  n2o_impact = data.frame(n2o_impact$row_name, n2o_impact$value)
  voc_impact = data.frame(voc_impact$row_name, voc_impact$value)
  co_impact = data.frame(co_impact$row_name, co_impact$value)
  nox_impact = data.frame(nox_impact$row_name, nox_impact$value)
  pm10_impact = data.frame(pm10_impact$row_name, pm10_impact$value)
  pm25_impact = data.frame(pm25_impact$row_name, pm25_impact$value)
  sox_impact = data.frame(sox_impact$row_name, sox_impact$value)
  
  colnames(co2_impact) = c("products", "r")
  colnames(ch4_impact) = c("products", "r")
  colnames(n2o_impact) = c("products", "r")
  colnames(voc_impact) = c("products", "r")
  colnames(co_impact) = c("products", "r")
  colnames(nox_impact) = c("products", "r")
  colnames(pm10_impact) = c("products", "r")
  colnames(pm25_impact) = c("products", "r")
  colnames(sox_impact) = c("products", "r")
  
  io_vector = tot_LCA
  io_vector = io_vector[io_vector$col_name!="CO2.kg",]
  io_vector = io_vector[io_vector$col_name!="CH4.kg",]
  io_vector = io_vector[io_vector$col_name!="N2O.kg",]
  io_vector = io_vector[io_vector$col_name!="VOC.kg",]
  io_vector = io_vector[io_vector$col_name!="CO.kg",]
  io_vector = io_vector[io_vector$col_name!="NOx.kg",]
  io_vector = io_vector[io_vector$col_name!="PM10.kg",]
  io_vector = io_vector[io_vector$col_name!="PM25.kg",]
  io_vector = io_vector[io_vector$col_name!="SOx.kg",]
  
  # cleaning pre-existing LCA
  
  io_data_LCA$value[!is.na(io_data_LCA$new_value)] = io_data_LCA$new_value[!is.na(io_data_LCA$new_value)]
  io_data_LCA$source_short[!is.na(io_data_LCA$new_value)] = io_data_LCA$new_source_short[!is.na(io_data_LCA$new_value)]
  io_data_LCA_clean = data.frame(io_data_LCA$row_name, io_data_LCA$col_name, io_data_LCA$value, io_data_LCA$source_short, io_data_LCA$Notes)
  colnames(io_data_LCA_clean) = c("row_name", "col_name", "value", "source_short", "notes")
  
  co2_data_LCA$r[!is.na(co2_data_LCA$new_value)] = co2_data_LCA$new_value[!is.na(co2_data_LCA$new_value)]
  co2_data_LCA_clean = data.frame(co2_data_LCA$products, co2_data_LCA$r)
  colnames(co2_data_LCA_clean) = c("products", "r")
  
  ch4_data_LCA$r[!is.na(ch4_data_LCA$new_value)] = ch4_data_LCA$new_value[!is.na(ch4_data_LCA$new_value)]
  ch4_data_LCA_clean = data.frame(ch4_data_LCA$products, ch4_data_LCA$r)
  colnames(ch4_data_LCA_clean) = c("products", "r")
  
  n2o_data_LCA$r[!is.na(n2o_data_LCA$new_value)] = n2o_data_LCA$new_value[!is.na(n2o_data_LCA$new_value)]
  n2o_data_LCA_clean = data.frame(n2o_data_LCA$products, n2o_data_LCA$r)
  colnames(n2o_data_LCA_clean) = c("products", "r")
  
  # co_data_LCA$r[!is.na(co_data_LCA$new_value)] = co_data_LCA$new_value[!is.na(co_data_LCA$new_value)]
  co_data_LCA_clean = data.frame(co_data_LCA$products, co_data_LCA$r)
  colnames(co_data_LCA_clean) = c("products", "r")
  
  # nox_data_LCA$r[!is.na(nox_data_LCA$new_value)] = nox_data_LCA$new_value[!is.na(nox_data_LCA$new_value)]
  nox_data_LCA_clean = data.frame(nox_data_LCA$products, nox_data_LCA$r)
  colnames(nox_data_LCA_clean) = c("products", "r")
  
  so2_data_LCA$r[!is.na(so2_data_LCA$new_value)] = so2_data_LCA$new_value[!is.na(so2_data_LCA$new_value)]
  so2_data_LCA_clean = data.frame(so2_data_LCA$products, so2_data_LCA$r)
  colnames(so2_data_LCA_clean) = c("products", "r")
  
  # pm25_data_LCA$r[!is.na(pm25_data_LCA$new_value)] = pm25_data_LCA$new_value[!is.na(pm25_data_LCA$new_value)]
  pm25_data_LCA_clean = data.frame(pm25_data_LCA$products, pm25_data_LCA$r)
  colnames(pm25_data_LCA_clean) = c("products", "r")
  
  # voc_data_LCA$r[!is.na(voc_data_LCA$new_value)] = voc_data_LCA$new_value[!is.na(voc_data_LCA$new_value)]
  voc_data_LCA_clean = data.frame(voc_data_LCA$products, voc_data_LCA$r)
  colnames(voc_data_LCA_clean) = c("products", "r")
  
  # finding overlaps in battery lca and data lca
  
  io_overlap = intersect(io_vector$row_name, io_data_LCA_clean$row_name)
  co2_overlap = intersect(co2_impact$products, co2_data_LCA_clean$products)
  ch4_overlap = intersect(ch4_impact$products, ch4_data_LCA_clean$products)
  n2o_overlap = intersect(n2o_impact$products, n2o_data_LCA_clean$products)
  co_overlap = intersect(co_impact$products, co_data_LCA_clean$products)
  nox_overlap = intersect(nox_impact$products, nox_data_LCA_clean$products)
  so2_overlap = intersect(sox_impact$products, so2_data_LCA_clean$products)
  pm25_overlap = intersect(pm25_impact$products, pm25_data_LCA_clean$products)
  voc_overlap = intersect(voc_impact$products, voc_data_LCA_clean$products)
  
  # remove overlapping values
  
  if (length(io_overlap) > 0) {
    
    for (k in 1:length(io_overlap)) {
      
      io_data_LCA_clean = io_data_LCA_clean[!io_data_LCA_clean$row_name==io_overlap[k],]
    }
  }
  
  if (length(co2_overlap) > 0) {
    
    for (k in 1:length(co2_overlap)) {
      
      co2_data_LCA_clean = co2_data_LCA_clean[co2_data_LCA_clean$products!=co2_overlap[k],]
    }
  }
  
  if (length(ch4_overlap) > 0) {
    
    for (k in 1:length(ch4_overlap)) {
      
      ch4_data_LCA_clean = ch4_data_LCA_clean[ch4_data_LCA_clean$products!=ch4_overlap[k],]
    }
  }
  
  if (length(n2o_overlap) > 0) {
    
    for (k in 1:length(n2o_overlap)) {
      
      n2o_data_LCA_clean = n2o_data_LCA_clean[n2o_data_LCA_clean$products!=n2o_overlap[k],]
    }
  }
  
  if (length(co_overlap) > 0) {
    
    for (k in 1:length(co_overlap)) {
      
      co_data_LCA_clean = co_data_LCA_clean[co_data_LCA_clean$products!=co_overlap[k],]
    }
  }
  
  if (length(nox_overlap) > 0) {
    
    for(k in 1:length(nox_overlap)) {
      
      nox_data_LCA_clean = nox_data_LCA_clean[nox_data_LCA_clean$products!=nox_overlap[k],]
    }
  }
  
  if (length(so2_overlap) > 0) {
    
    for(k in 1:length(so2_overlap)) {
      
      so2_data_LCA_clean = so2_data_LCA_clean[so2_data_LCA_clean$products!=so2_overlap[k],]
      
    }
  }
  
  if (length(pm25_overlap) > 0) {
    
    for (k in 1:length(pm25_overlap)) {
      
      pm25_data_LCA_clean = pm25_data_LCA_clean[pm25_data_LCA_clean$products!=pm25_overlap[k],]
    }
  }
  
  if (length(voc_overlap) > 0) {
    
    for (k in 1:length(voc_overlap)) {
      
      voc_data_LCA_clean = voc_data_LCA_clean[voc_data_LCA_clean$products!=voc_overlap[k],]
    }
  }
  
  # create final vectors
  
  io_vector = rbind(io_vector, io_data_LCA_clean)
  co2_impact = rbind(co2_impact, co2_data_LCA_clean)
  ch4_impact = rbind(ch4_impact, ch4_data_LCA_clean)
  n2o_impact = rbind(n2o_impact, n2o_data_LCA_clean)
  co_impact = rbind(co_impact, co_data_LCA_clean)
  nox_impact = rbind(nox_impact, nox_data_LCA_clean)
  sox_impact = rbind(sox_impact, so2_data_LCA_clean)
  pm25_impact = rbind(pm25_impact, pm25_data_LCA_clean)
  voc_impact = rbind(voc_impact, voc_data_LCA_clean)
  
  co2_impact_products = co2_impact$products
  co2_impact = data.frame(co2_impact$r)
  colnames(co2_impact) = c("r")
  rownames(co2_impact) = co2_impact_products
  
  ch4_impact_products = ch4_impact$products
  ch4_impact = data.frame(ch4_impact$r)
  colnames(ch4_impact) = c("r")
  rownames(ch4_impact) = ch4_impact_products
  
  n2o_impact_products = n2o_impact$products
  n2o_impact = data.frame(n2o_impact$r)
  colnames(n2o_impact) = c("r")
  rownames(n2o_impact) = n2o_impact_products
  
  co_impact_products = co_impact$products
  co_impact = data.frame(co_impact$r)
  colnames(co_impact) = c("r")
  rownames(co_impact) = co_impact_products
  
  nox_impact_products = nox_impact$products
  nox_impact = data.frame(nox_impact$r)
  colnames(nox_impact) = c("r")
  rownames(nox_impact) = nox_impact_products
  
  sox_impact_products = sox_impact$products
  sox_impact = data.frame(sox_impact$r)
  colnames(sox_impact) = c("r")
  rownames(sox_impact) = sox_impact_products
  
  pm25_impact_products = pm25_impact$products
  pm25_impact = data.frame(pm25_impact$r)
  colnames(pm25_impact) = c("r")
  rownames(pm25_impact) = pm25_impact_products
  
  voc_impact_products = voc_impact$products
  voc_impact = data.frame(voc_impact$r)
  colnames(voc_impact) = c("r")
  rownames(voc_impact) = voc_impact_products
  
  # convert io_vector to io_matrix
  
  dim_io_vector = dim(io_vector)
  
  row_unique = unique(io_vector$row_name)
  col_unique = unique(io_vector$col_name)
  product_unique = c(row_unique, col_unique)
  product_unique = unique(product_unique)
  
  # io_names = c("product", product_unique)
  
  io_matrix = data.frame(matrix(NA, nrow = length(product_unique), ncol = length(product_unique)))
  colnames(io_matrix) = product_unique
  rownames(io_matrix) = product_unique
  
  for (i in 1:length(product_unique)) {
    
    for (j in 1:length(product_unique)) {
      
      # i = 1
      # j = 1
      
      temp_row = product_unique[i] 
      temp_col = product_unique[j]
      temp_val = io_vector$value[io_vector$row_name==temp_row & io_vector$col_name==temp_col]
      
      if(length(temp_val) > 0) {
        
        io_matrix[i, j] = temp_val[1]
        
      } else {
        
        io_matrix[i, j] = 0
        
      }
      
    }
    
  }
  
  # find all impact vector values not present in matrix
  ## add empty rows/columns to io matrix
  
  impact_vector_items = unique(c(rownames(co2_impact), rownames(ch4_impact), rownames(n2o_impact), rownames(co_impact),
                                 rownames(nox_impact), rownames(sox_impact), rownames(pm25_impact), rownames(voc_impact)))
  
  mat_notvector = setdiff(impact_vector_items, rownames(io_matrix)) # in x, not y
  
  mat_add = matrix(0, nrow = length(mat_notvector), ncol = length(mat_notvector))
  
  mat_io = as.matrix(bdiag(data.matrix(io_matrix), mat_add))
  rownames(mat_io) = c(rownames(io_matrix), mat_notvector)
  colnames(mat_io) = c(rownames(io_matrix), mat_notvector)
  
  io_matrix = mat_io
  
  # find all matrix values not present in impact vectors
  ## add row with values of zero for each impact vector for each non-present item
  
  co2_notmatrix = setdiff(rownames(io_matrix), rownames(co2_impact)) # in x, not in y
  ch4_notmatrix = setdiff(rownames(io_matrix), rownames(ch4_impact)) # in x, not in y
  n2o_notmatrix = setdiff(rownames(io_matrix), rownames(n2o_impact)) # in x, not in y
  co_notmatrix = setdiff(rownames(io_matrix), rownames(co_impact)) # in x, not in y
  nox_notmatrix = setdiff(rownames(io_matrix), rownames(nox_impact)) # in x, not in y
  sox_notmatrix = setdiff(rownames(io_matrix), rownames(sox_impact)) # in x, not in y
  pm25_notmatrix = setdiff(rownames(io_matrix), rownames(pm25_impact)) # in x, not in y
  voc_notmatrix = setdiff(rownames(io_matrix), rownames(voc_impact)) # in x, not in y
  
  co2_impact_add = data.frame(rep(0, length(co2_notmatrix)))
  ch4_impact_add = data.frame(rep(0, length(ch4_notmatrix)))
  n2o_impact_add = data.frame(rep(0, length(n2o_notmatrix)))
  co_impact_add = data.frame(rep(0, length(co_notmatrix)))
  nox_impact_add = data.frame(rep(0, length(nox_notmatrix)))
  sox_impact_add = data.frame(rep(0, length(sox_notmatrix)))
  pm25_impact_add = data.frame(rep(0, length(pm25_notmatrix)))
  voc_impact_add = data.frame(rep(0, length(voc_notmatrix)))
  
  rownames(co2_impact_add) = co2_notmatrix
  rownames(ch4_impact_add) = ch4_notmatrix
  rownames(n2o_impact_add) = n2o_notmatrix
  rownames(co_impact_add) = co_notmatrix
  rownames(nox_impact_add) = nox_notmatrix
  rownames(sox_impact_add) = sox_notmatrix
  rownames(pm25_impact_add) = pm25_notmatrix
  rownames(voc_impact_add) = voc_notmatrix
  
  colnames(co2_impact_add) = c("r")
  colnames(ch4_impact_add) = c("r")
  colnames(n2o_impact_add) = c("r")
  colnames(co_impact_add) = c("r")
  colnames(nox_impact_add) = c("r")
  colnames(sox_impact_add) = c("r")
  colnames(pm25_impact_add) = c("r")
  colnames(voc_impact_add) = c("r")
  
  co2_impact = rbind(co2_impact, co2_impact_add)
  ch4_impact = rbind(ch4_impact, ch4_impact_add)
  n2o_impact = rbind(n2o_impact, n2o_impact_add)
  co_impact = rbind(co_impact, co_impact_add)
  nox_impact = rbind(nox_impact, nox_impact_add)
  sox_impact = rbind(sox_impact, sox_impact_add)
  pm25_impact = rbind(pm25_impact, pm25_impact_add)
  voc_impact = rbind(voc_impact, voc_impact_add)
  
  
  co2_impact$r[is.na(co2_impact$r)==1] = 0
  ch4_impact$r[is.na(ch4_impact$r)==1] = 0
  n2o_impact$r[is.na(n2o_impact$r)==1] = 0
  co_impact$r[is.na(co_impact$r)==1] = 0
  nox_impact$r[is.na(nox_impact$r)==1] = 0
  sox_impact$r[is.na(sox_impact$r)==1] = 0
  pm25_impact$r[is.na(pm25_impact$r)==1] = 0
  voc_impact$r[is.na(voc_impact$r)==1] = 0
  
  
  results_mat_input_temp = results_mat_input
  results_mat_input = data.frame(results_mat_input_temp$value)
  rownames(results_mat_input) = results_mat_input_temp$input_name
  colnames(results_mat_input) = c("y")
  
  y_input = co2_impact
  y_input$r = 0
  
  y_input_names = rownames(results_mat_input)
  
  
  for(k in 1:length(y_input_names)) {
    
    # k = 1
    y_input[y_input_names[k],] = results_mat_input$y[k]
    
  }
  
  
  y_input = y_input[!(row.names(y_input) %in% "BMS.remove"),]
  y_input = data.frame(y_input)
  rownames(y_input) = rownames(co2_impact)
  colnames(y_input) = c("y")
  y_input$y = as.numeric(y_input$y)
  
  # row matching
  
  io_matrix = as.data.frame(io_matrix)
  io_matrix_match = io_matrix
  
  io_matrix_match$co2_impact = co2_impact[match(row.names(io_matrix_match), row.names(co2_impact)),"r"]
  io_matrix_match$ch4_impact = ch4_impact[match(row.names(io_matrix_match), row.names(ch4_impact)),"r"]
  io_matrix_match$n2o_impact = n2o_impact[match(row.names(io_matrix_match), row.names(n2o_impact)),"r"]
  io_matrix_match$co_impact = co_impact[match(row.names(io_matrix_match), row.names(co_impact)),"r"]
  io_matrix_match$nox_impact = nox_impact[match(row.names(io_matrix_match), row.names(nox_impact)),"r"]
  io_matrix_match$sox_impact = sox_impact[match(row.names(io_matrix_match), row.names(sox_impact)),"r"]
  io_matrix_match$pm25_impact = pm25_impact[match(row.names(io_matrix_match), row.names(pm25_impact)),"r"]
  io_matrix_match$voc_impact = voc_impact[match(row.names(io_matrix_match), row.names(voc_impact)),"r"]
  io_matrix_match$y_input = y_input[match(row.names(io_matrix_match), row.names(y_input)),"y"]
  
  rownames(co2_impact) = rownames(io_matrix_match)
  rownames(ch4_impact) = rownames(io_matrix_match)
  rownames(n2o_impact) = rownames(io_matrix_match)
  rownames(co_impact) = rownames(io_matrix_match)
  rownames(nox_impact) = rownames(io_matrix_match)
  rownames(sox_impact) = rownames(io_matrix_match)
  rownames(pm25_impact) = rownames(io_matrix_match)
  rownames(voc_impact) = rownames(io_matrix_match)
  rownames(y_input) = rownames(io_matrix_match)
  
  co2_impact$r = io_matrix_match$co2_impact
  ch4_impact$r = io_matrix_match$ch4_impact
  n2o_impact$r = io_matrix_match$n2o_impact
  co_impact$r = io_matrix_match$co_impact
  nox_impact$r = io_matrix_match$nox_impact
  sox_impact$r = io_matrix_match$sox_impact
  pm25_impact$r = io_matrix_match$pm25_impact
  voc_impact$r = io_matrix_match$voc_impact
  y_input$y = io_matrix_match$y_input
  
  names_remove = c("T&D??", "T&D?")
  io_matrix = io_matrix[!(row.names(io_matrix) %in% names_remove),]
  io_matrix = io_matrix[,!(names(io_matrix) %in% names_remove)]
  co2_impact = co2_impact[!(row.names(co2_impact) %in% names_remove),]
  ch4_impact = ch4_impact[!(row.names(ch4_impact) %in% names_remove),]
  n2o_impact = n2o_impact[!(row.names(n2o_impact) %in% names_remove),]
  co_impact = co_impact[!(row.names(co_impact) %in% names_remove),]
  nox_impact = nox_impact[!(row.names(nox_impact) %in% names_remove),]
  sox_impact = sox_impact[!(row.names(sox_impact) %in% names_remove),]
  pm25_impact = pm25_impact[!(row.names(pm25_impact) %in% names_remove),]
  voc_impact = voc_impact[!(row.names(voc_impact) %in% names_remove),]
  y_input = y_input[!(row.names(y_input) %in% names_remove),]
  
  lca_names = row.names(io_matrix)
  
  co2_impact = data.frame(co2_impact)
  colnames(co2_impact) = "r"
  rownames(co2_impact) = lca_names
  ch4_impact = data.frame(ch4_impact)
  colnames(ch4_impact) = "r"
  rownames(ch4_impact) = lca_names
  n2o_impact = data.frame(n2o_impact)
  colnames(n2o_impact) = "r"
  rownames(n2o_impact) = lca_names
  co_impact = data.frame(co_impact)
  colnames(co_impact) = "r"
  rownames(co_impact) = lca_names
  nox_impact = data.frame(nox_impact)
  colnames(nox_impact) = "r"
  rownames(nox_impact) = lca_names
  sox_impact = data.frame(sox_impact)
  colnames(sox_impact) = "r"
  rownames(sox_impact) = lca_names
  pm25_impact = data.frame(pm25_impact)
  colnames(pm25_impact) = "r"
  rownames(pm25_impact) = lca_names
  voc_impact = data.frame(voc_impact)
  colnames(voc_impact) = "r"
  rownames(voc_impact) = lca_names
  y_input = data.frame(y_input)
  colnames(y_input) = "r"
  rownames(y_input) = lca_names
  
  
  
  # io_matrix["naturalgas_select.MJ", "naturalgas_combust.MJ"] = 0 # this correct since this divides sources between conventional and shale
  # io_matrix["naturalgas.conventional.MJ", "naturalgas_combust.MJ"] = 1 # this is actually correct
  # io_matrix["naturalgas.shale.MJ", "naturalgas_combust.MJ"] = 1 # this is correct
  
  # io_matrix["naturalgas_select.MJ", ] = 0
  io_matrix["naturalgas_select.MJ", "naturalgas_combust.MJ"] = 0
  # io_matrix["naturalgas.conventional.MJ", ] = 0
  # io_matrix["naturalgas.shale.MJ", ] = 0
  
  # io_matrix["electricity.NG.kWh", "naturalgas_select.MJ"] = 0 # lca impacts
  
  
  
  
  
  
  
  io_matrix["coal.MJ", "coal_combustion.MJ"] = 1 # / runif(n, min = 0.8, max = 0.9)
  
  co2_impact["electricity.Solar.kWh",1] = rtri(n, min = 18, max = 180, mode = 48)/1000 # https://www.ipcc.ch/site/assets/uploads/2018/02/ipcc_wg3_ar5_annex-iii.pdf#page=7
  
  write.csv(io_matrix, "io_tables_2/io_table_physical.csv")
  write.csv(co2_impact, "io_tables_2/impact_vectors/co2_impact.csv")
  write.csv(ch4_impact, "io_tables_2/impact_vectors/ch4_impact.csv")
  write.csv(n2o_impact, "io_tables_2/impact_vectors/n2o_impact.csv")
  write.csv(co_impact, "io_tables_2/impact_vectors/co_impact.csv")
  write.csv(nox_impact, "io_tables_2/impact_vectors/nox_impact.csv")
  write.csv(sox_impact, "io_tables_2/impact_vectors/sox_impact.csv")
  write.csv(pm25_impact, "io_tables_2/impact_vectors/pm25_impact.csv")
  write.csv(voc_impact, "io_tables_2/impact_vectors/voc_impact.csv")
  
  write.csv(y_input, "io_tables_2/y_input.csv")
  
  ##############################################################################
  # LCA Run #
  ##############################################################################
  
  # Checks to see if necessary packages are installed
  packages <- c("xts", "gdata", "udunits2", "plyr", "gdata", "data.table", "zoo",
                "abind", "ggplot2", "scales", "rstudioapi", "gsubfn", "stringr")
  if (length(setdiff(packages, rownames(installed.packages()))) > 0) {
    install.packages(setdiff(packages, rownames(installed.packages())))  
  }
  
  #load packages
  lapply(packages, library, character.only = TRUE)
  
  
  materials = read.csv("io_tables_2/y_input.csv", header = TRUE, row.names = 1)
  materials_vals = materials[materials$r!=0,]
  materials_names = rownames(materials)[materials[["r"]] !=0]
  
  #Define CO2EQ GWP IPCC Constants
  
  ipcc.ch4.100 <- 28 
  ipcc.n2o.100 <- 298 # may be 295
  
  
  #Read in filepaths for emissions calculations ### use these for filepaths - 
  
  co2.filepath <- 'io_tables_2/impact_vectors/co2_impact.csv'
  ch4.filepath <- 'io_tables_2/impact_vectors/ch4_impact.csv'
  n2o.filepath <- 'io_tables_2/impact_vectors/n2o_impact.csv'
  co.filepath <- 'io_tables_2/impact_vectors/co_impact.csv'
  nox.filepath <- 'io_tables_2/impact_vectors/nox_impact.csv'
  sox.filepath <- 'io_tables_2/impact_vectors/sox_impact.csv'
  pm25.filepath <- 'io_tables_2/impact_vectors/pm25_impact.csv'
  voc.filepath <- 'io_tables_2/impact_vectors/voc_impact.csv'
  
  
  #Scenario and results dataframe setup
  cases <- data.frame(materials_names, materials_vals)
  
  
  # DELETE BELOW # ONLY FOR DETERMINING LC IMPACT OF ELECTRICITY FROM NAT GAS
  
  # cases = data.frame("electricity.US.kWh", 1)
  
  # DELETE ABOVE # ONLY FOR DETERMINING LC IMPACT OF ELECTRICITY FROM NAT GAS
  
  
  
  
  
  colnames(cases) = c("Mat_names", "Mat_vals")
  
  results.total.list.ghg <- c()
  results.total.list.co <- c()
  results.total.list.nox <- c()
  results.total.list.sox <- c()
  results.total.list.pm25 <- c()
  results.total.list.voc <- c()
  
  y.inputs <- data.frame()
  
  for(scenario in 1:dim(cases)[1]) {
    
    # scenario = 1 # temp value for trials
    
    functional.unit <- 'kg.per.ton.accepted' 
    current.case <- cases[1,scenario]
    
    #I-O and Y Setup
    
    A <- IOTableSetup(io_filepath) # read csv event
    y <- YSetUp(co2.filepath) # read csv event
    time.horizon <- 100
    
    ##### ****************** Process Calculations and Y Definition ********** #####
    
    y[cases$Mat_names[scenario],] = cases$Mat_vals[scenario]
    
    #Y inputs
    y$scenario <- cases[scenario,1]
    y$contributors <- rownames(y)
    y.inputs <- rbind(y.inputs, y)
    y$scenario <- NULL
    y$contributors <- NULL
    
    #Normalization Factor ----
    
    normalization.factor <- 1 
    ### denominator for emission factor [ie if all your raw data is for 10 bottles, you can add all raw numbers to y vector and this will normalize it per bottle before running LCA]
    
    y[,"y"] <- y[,"y"] / normalization.factor
    
    #### *************************** RESULTS GENERATION *********************** #####
    
    # Create separate vector with only negative values and zero out negative values
    #    in original y vector to ensure math works out for I-O
    y1 <- y
    y1[y1>0] <- 0
    y1 <- abs(y1)
    y[y<0] <- 0
    
    ### GWP Calcs ###
    
    results.kg.co2eq <- TotalGHGEmissions(A, data.matrix(y, rownames.force = NA),
                                          co2.filepath,
                                          ch4.filepath, n2o.filepath,
                                          time.horizon)
    results.kg.co2eq.credits <- TotalGHGEmissions(A, data.matrix(y1, rownames.force = NA),
                                                  co2.filepath,
                                                  ch4.filepath, n2o.filepath,
                                                  time.horizon)
    results.kg.co2eq <- results.kg.co2eq - results.kg.co2eq.credits # Subtract off credits
    
    results.kg.co2eq$emission <- 'co2eq'
    
    results.total.list.ghg[[scenario]] <- results.kg.co2eq 
    
    
    ### CO Calcs ###
    
    results.kg.co <- COEmissions(A, data.matrix(y, rownames.force = NA),
                                 co.filepath)
    results.kg.co.credits <- COEmissions(A, data.matrix(y1, rownames.force = NA),
                                         co.filepath)
    results.kg.co<- results.kg.co - results.kg.co.credits # Subtract off credits
    
    results.kg.co$emission <- 'co'
    
    results.total.list.co[[scenario]] <- results.kg.co
    
    
    ### NOX Calcs ###
    
    results.kg.nox <- NOXEmissions(A, data.matrix(y, rownames.force = NA),
                                   nox.filepath)
    results.kg.nox.credits <- NOXEmissions(A, data.matrix(y1, rownames.force = NA),
                                           nox.filepath)
    results.kg.nox<- results.kg.nox - results.kg.nox.credits # Subtract off credits
    
    results.kg.nox$emission <- 'nox'
    
    results.total.list.nox[[scenario]] <- results.kg.nox
    
    
    ### SOX Calcs ###
    
    results.kg.sox <- SOXEmissions(A, data.matrix(y, rownames.force = NA),
                                   sox.filepath)
    results.kg.sox.credits <- SOXEmissions(A, data.matrix(y1, rownames.force = NA),
                                           sox.filepath)
    results.kg.sox<- results.kg.sox - results.kg.sox.credits # Subtract off credits
    
    results.kg.sox$emission <- 'sox'
    
    results.total.list.sox[[scenario]] <- results.kg.sox
    
    
    ### PM25 Calcs ###
    
    results.kg.pm25 <- PM25Emissions(A, data.matrix(y, rownames.force = NA),
                                     pm25.filepath)
    results.kg.pm25.credits <- PM25Emissions(A, data.matrix(y1, rownames.force = NA),
                                             pm25.filepath)
    results.kg.pm25<- results.kg.pm25 - results.kg.pm25.credits # Subtract off credits
    
    results.kg.pm25$emission <- 'pm25'
    
    results.total.list.pm25[[scenario]] <- results.kg.pm25
    
    
    ### VOC Calcs ###
    
    results.kg.voc <- VOCEmissions(A, data.matrix(y, rownames.force = NA),
                                   voc.filepath)
    results.kg.voc.credits <- VOCEmissions(A, data.matrix(y1, rownames.force = NA),
                                           voc.filepath)
    results.kg.voc<- results.kg.voc - results.kg.voc.credits # Subtract off credits
    
    results.kg.voc$emission <- 'voc'
    
    results.total.list.voc[[scenario]] <- results.kg.voc
    
  } 
  
  
  ##############################################################################
  # Independent LCA of r410a and HFC227 #
  ##############################################################################
  

  ### r410a LCA ###
  
  functional.unit <- 'kg.per.ton.accepted' 
  current.case <- cases[1,scenario]
  
  #I-O and Y Setup
  
  A <- IOTableSetup(io_filepath) # read csv event
  y <- YSetUp(co2.filepath) # read csv event
  time.horizon <- 100
  
  ##### ****************** Process Calculations and Y Definition ********** #####
  
  y["R410a.kg",] = HVAC_mass_r410a * Cont_quant
  
  #Y inputs
  y$scenario <- cases[scenario,1]
  y$contributors <- rownames(y)
  y.inputs <- rbind(y.inputs, y)
  y$scenario <- NULL
  y$contributors <- NULL
  
  #Normalization Factor ----
  
  normalization.factor <- 1 
  ### denominator for emission factor [ie if all your raw data is for 10 bottles, you can add all raw numbers to y vector and this will normalize it per bottle before running LCA]
  
  y[,"y"] <- y[,"y"] / normalization.factor
  
  #### *************************** RESULTS GENERATION *********************** #####
  
  # Create separate vector with only negative values and zero out negative values
  #    in original y vector to ensure math works out for I-O
  y1 <- y
  y1[y1>0] <- 0
  y1 <- abs(y1)
  y[y<0] <- 0
  
  ### GWP Calcs ###
  
  results.kg.co2eq_r410A <- TotalGHGEmissions(A, data.matrix(y, rownames.force = NA),
                                              co2.filepath,
                                              ch4.filepath, n2o.filepath,
                                              time.horizon)
  results.kg.co2eq.credits_r410A <- TotalGHGEmissions(A, data.matrix(y1, rownames.force = NA),
                                                      co2.filepath,
                                                      ch4.filepath, n2o.filepath,
                                                      time.horizon)
  results.kg.co2eq_r410A <- results.kg.co2eq_r410A - results.kg.co2eq.credits_r410A # Subtract off credits
  
  results.kg.co2eq_r410A$emission <- 'co2eq'
  
  
  ### fire agent LCA ###
  
  functional.unit <- 'kg.per.ton.accepted' 
  current.case <- cases[1,scenario]
  
  #I-O and Y Setup
  
  A <- IOTableSetup(io_filepath) # read csv event
  y <- YSetUp(co2.filepath) # read csv event
  time.horizon <- 100
  
  ##### ****************** Process Calculations and Y Definition ********** #####
  
  y["HFC.227ea.kg",] = Fire_mass_agent * Cont_quant
  
  #Y inputs
  y$scenario <- cases[scenario,1]
  y$contributors <- rownames(y)
  y.inputs <- rbind(y.inputs, y)
  y$scenario <- NULL
  y$contributors <- NULL
  
  #Normalization Factor ----
  
  normalization.factor <- 1 
  ### denominator for emission factor [ie if all your raw data is for 10 bottles, you can add all raw numbers to y vector and this will normalize it per bottle before running LCA]
  
  y[,"y"] <- y[,"y"] / normalization.factor
  
  #### *************************** RESULTS GENERATION *********************** #####
  
  # Create separate vector with only negative values and zero out negative values
  #    in original y vector to ensure math works out for I-O
  y1 <- y
  y1[y1>0] <- 0
  y1 <- abs(y1)
  y[y<0] <- 0
  
  ### GWP Calcs ###
  
  results.kg.co2eq_agent <- TotalGHGEmissions(A, data.matrix(y, rownames.force = NA),
                                              co2.filepath,
                                              ch4.filepath, n2o.filepath,
                                              time.horizon)
  results.kg.co2eq.credits_agent <- TotalGHGEmissions(A, data.matrix(y1, rownames.force = NA),
                                                      co2.filepath,
                                                      ch4.filepath, n2o.filepath,
                                                      time.horizon)
  results.kg.co2eq_agent <- results.kg.co2eq_agent - results.kg.co2eq.credits_agent # Subtract off credits
  
  results.kg.co2eq_agent$emission <- 'co2eq'

  
  ##############################################################################
  # NPV Analysis #
  ##############################################################################
  
  # discount_series = seq(from = 1, to = Lifetime)
  # discount_series = (1/(1+irr))^discount_series
  
  
  ghg_purchased_elec_ann = rep(sum(results.total.list.ghg[[14]]$r), Lifetime)/Lifetime # divide by lifetime because value in lca is for lifetime cycles
  co_purchased_elec_ann = rep(sum(results.total.list.co[[14]]$r), Lifetime)/Lifetime
  nox_purchased_elec_ann = rep(sum(results.total.list.nox[[14]]$r), Lifetime)/Lifetime
  sox_purchased_elec_ann = rep(sum(results.total.list.sox[[14]]$r), Lifetime)/Lifetime
  voc_purchased_elec_ann = rep(sum(results.total.list.voc[[14]]$r), Lifetime)/Lifetime
  pm25_purchased_elec_ann = rep(sum(results.total.list.pm25[[14]]$r), Lifetime)/Lifetime
  
  ghg_offset_elec_ann = rep(sum(results.total.list.ghg[[15]]$r), Lifetime)/Lifetime # -1* sum(results.total.list.ghg[[15]]$r) * scc * discount_series 
  co_offset_elec_ann = rep(sum(results.total.list.co[[15]]$r), Lifetime)/Lifetime
  nox_offset_elec_ann = rep(sum(results.total.list.nox[[15]]$r), Lifetime)/Lifetime
  sox_offset_elec_ann = rep(sum(results.total.list.sox[[15]]$r), Lifetime)/Lifetime
  voc_offset_elec_ann = rep(sum(results.total.list.voc[[15]]$r), Lifetime)/Lifetime
  pm25_offset_elec_ann = rep(sum(results.total.list.pm25[[15]]$r), Lifetime)/Lifetime
  
  cost_purchased_elec = rep(plant_profits$Elec_Pur_USD_pyear[plant_profits$Peaker==peaker_name], Lifetime)
    # series of annual cost of buying elec 
  cost_offset_elec = -1 * rep(plant_profits$Elec_Off_USD_pyear[plant_profits$Peaker==peaker_name], Lifetime)
    # series of anual cost of selling elec (negative)
  
  
  cost_batt_replace = rep(0, Lifetime)
  cost_batt_replace[round(Lifespan,0)] = (df_tot_graph$Cost[df_tot_graph$Component=="Battery"] * Capacity_MWh * 1000)
  # single value in year of replacement of emissions from battery x scc 
  
  
  ghg_batt_replace = rep(0, Lifetime)
  co_batt_replace = rep(0, Lifetime)
  nox_batt_replace = rep(0, Lifetime)
  sox_batt_replace = rep(0, Lifetime)
  voc_batt_replace = rep(0, Lifetime)
  pm25_batt_replace = rep(0, Lifetime)
  lca_battery_ind = c(1, 16:28) # battery LCA items [1, 16: 28]
  
  for (i in lca_battery_ind) {
    
    ghg_batt_replace[round(Lifespan,0)] = ghg_batt_replace[round(Lifespan,0)] + sum(results.total.list.ghg[[i]]$r)
    co_batt_replace[round(Lifespan,0)] = co_batt_replace[round(Lifespan,0)] + sum(results.total.list.co[[i]]$r)
    nox_batt_replace[round(Lifespan,0)] = nox_batt_replace[round(Lifespan,0)] + sum(results.total.list.nox[[i]]$r)
    sox_batt_replace[round(Lifespan,0)] = sox_batt_replace[round(Lifespan,0)] + sum(results.total.list.sox[[i]]$r)
    voc_batt_replace[round(Lifespan,0)] = voc_batt_replace[round(Lifespan,0)] + sum(results.total.list.voc[[i]]$r)
    pm25_batt_replace[round(Lifespan,0)] = pm25_batt_replace[round(Lifespan,0)] + sum(results.total.list.pm25[[i]]$r)
    
  }
  # single value in year of replacement of cost of batteries
  
  
  cost_equipment_life = rep(0, Lifetime)
  ghg_equipment_life = rep(0, Lifetime)
  co_equipment_life = rep(0, Lifetime)
  nox_equipment_life = rep(0, Lifetime)
  sox_equipment_life = rep(0, Lifetime)
  voc_equipment_life = rep(0, Lifetime)
  pm25_equipment_life = rep(0, Lifetime)
  # cycle through all equipment, add replacement cost for each eq at replacement year, then discount
  ## inverter, transformer, switchgear, fire, HVAC, 
  
  ### inverter
  
  if (Inv_lifetime < Lifetime) {
    
    cost_equipment_life[Inv_lifetime] = cost_equipment_life[Inv_lifetime] + df_tot_graph$Cost[df_tot_graph$Component=="Inverter"] * Capacity_MWh * 1000
    ghg_equipment_life[Inv_lifetime] = ghg_equipment_life[Inv_lifetime] + sum(results.total.list.ghg[[2]]$r)
    co_equipment_life[Inv_lifetime] = co_equipment_life[Inv_lifetime] + sum(results.total.list.co[[2]]$r)
    nox_equipment_life[Inv_lifetime] = nox_equipment_life[Inv_lifetime] + sum(results.total.list.nox[[2]]$r)
    sox_equipment_life[Inv_lifetime] = sox_equipment_life[Inv_lifetime] + sum(results.total.list.sox[[2]]$r)
    voc_equipment_life[Inv_lifetime] = voc_equipment_life[Inv_lifetime] + sum(results.total.list.voc[[2]]$r)
    pm25_equipment_life[Inv_lifetime] = pm25_equipment_life[Inv_lifetime] + sum(results.total.list.pm25[[2]]$r)
    
  }
  
  ### transformer
  
  if (Trans_lifetime < Lifetime) { # if transformer replacement required
    
    cost_equipment_life[Trans_lifetime] = cost_equipment_life[Trans_lifetime] + price_c * mat_c
    ghg_equipment_life[Trans_lifetime] = ghg_equipment_life[Trans_lifetime] + sum(results.total.list.ghg[[3]]$r)
    co_equipment_life[Trans_lifetime] = co_equipment_life[Trans_lifetime] + sum(results.total.list.co[[3]]$r)
    nox_equipment_life[Trans_lifetime] = nox_equipment_life[Trans_lifetime] + sum(results.total.list.nox[[3]]$r)
    sox_equipment_life[Trans_lifetime] = sox_equipment_life[Trans_lifetime] + sum(results.total.list.sox[[3]]$r)
    voc_equipment_life[Trans_lifetime] = voc_equipment_life[Trans_lifetime] + sum(results.total.list.voc[[3]]$r)
    pm25_equipment_life[Trans_lifetime] = pm25_equipment_life[Trans_lifetime] + sum(results.total.list.pm25[[3]]$r)
    
  }
  
  ### switchgear
  
  if (Switch_lifetime < Lifetime) { # if switchgear replacement required
    
    cost_equipment_life[Switch_lifetime] = cost_equipment_life[Switch_lifetime] + price_d * mat_d
    ghg_equipment_life[Switch_lifetime] = ghg_equipment_life[Switch_lifetime] + sum(results.total.list.ghg[[4]]$r)
    co_equipment_life[Switch_lifetime] = co_equipment_life[Switch_lifetime] + sum(results.total.list.co[[4]]$r)
    nox_equipment_life[Switch_lifetime] = nox_equipment_life[Switch_lifetime] + sum(results.total.list.nox[[4]]$r)
    sox_equipment_life[Switch_lifetime] = sox_equipment_life[Switch_lifetime] + sum(results.total.list.sox[[4]]$r)
    voc_equipment_life[Switch_lifetime] = voc_equipment_life[Switch_lifetime] + sum(results.total.list.voc[[4]]$r)
    pm25_equipment_life[Switch_lifetime] = pm25_equipment_life[Switch_lifetime] + sum(results.total.list.pm25[[4]]$r)
    
  }
  
  ### fire # gwp = 3350
  
  if (Fire_ghg_lifetime < Lifetime) { # if fire supp replacement required
    
    cost_equipment_life[Fire_ghg_lifetime] = cost_equipment_life[Fire_ghg_lifetime] + 1975*fire_2001_price_factor * mat_h
    ghg_equipment_life[Fire_ghg_lifetime] = ghg_equipment_life[Fire_ghg_lifetime] + Fire_mass_agent/ Fire_ghg_factor * Cont_quant * 3350
    
  }
  
  ghg_equipment_life[Lifetime] = ghg_equipment_life[Lifetime] + Fire_mass_agent/ Fire_ghg_factor * Cont_quant * 3350
  
  
  ### HVAC
  
  HVAC_gwp = 1923.5
  ghg_HVAC = rep(0, Lifetime)
  co_HVAC = rep(0, Lifetime)
  nox_HVAC = rep(0, Lifetime)
  sox_HVAC = rep(0, Lifetime)
  voc_HVAC = rep(0, Lifetime)
  pm25_HVAC = rep(0, Lifetime)
  
  ghg_HVAC = ghg_HVAC + r410a_annual*Cont_quant
  ghg_HVAC[Lifetime] = ghg_HVAC[Lifetime] + r410a_eol*Cont_quant # assign eol leakage to last year

  if(refrigerant=="r32.kg") {
    
    HVAC_gwp = 677
    
  }
  
  ghg_HVAC = ghg_HVAC * HVAC_gwp
  
  if (HVAC_lifetime < Lifetime) { # if hvac replacment required
    
    cost_equipment_life[HVAC_lifetime] = cost_equipment_life[HVAC_lifetime] + price_i * mat_i
    ghg_HVAC[HVAC_lifetime] = ghg_HVAC[HVAC_lifetime] + (sum(results.total.list.ghg[[9]]$r) - r410a_annual*Cont_quant*HVAC_gwp) / HVAC_factor # if HVAC replaced, full impacts - annual impacts
    co_HVAC[HVAC_lifetime] = co_HVAC[HVAC_lifetime] + sum(results.total.list.co[[9]]$r)
    nox_HVAC[HVAC_lifetime] = nox_HVAC[HVAC_lifetime] + sum(results.total.list.nox[[9]]$r)
    sox_HVAC[HVAC_lifetime] = sox_HVAC[HVAC_lifetime] + sum(results.total.list.sox[[9]]$r)
    voc_HVAC[HVAC_lifetime] = voc_HVAC[HVAC_lifetime] + sum(results.total.list.voc[[9]]$r)
    pm25_HVAC[HVAC_lifetime] = pm25_HVAC[HVAC_lifetime] + sum(results.total.list.pm25[[9]]$r)
    
    }
  
  ghg_equipment_life = ghg_equipment_life + ghg_HVAC 
  co_equipment_life = co_equipment_life + co_HVAC 
  nox_equipment_life = nox_equipment_life + nox_HVAC 
  sox_equipment_life = sox_equipment_life + sox_HVAC 
  voc_equipment_life = voc_equipment_life + voc_HVAC 
  pm25_equipment_life = pm25_equipment_life + pm25_HVAC 
  
  # cost_equipment_life = cost_equipment_life * discount_series
  # ghg_equipment_life = ghg_equipment_life * scc * discount_series # convert from kg co2eq to $$$
  
  
  
  ### upfront costs
  
  cost_upfront = sum(df_tot_graph$Cost) * Capacity_MWh * 1000
  cost_upfront = c(cost_upfront, rep(0, Lifetime))
  ghg_upfront = 0   # remove hvac annual and eol leakage, fire eol leakage
  co_upfront = 0   # remove hvac annual and eol leakage, fire eol leakage
  nox_upfront = 0   # remove hvac annual and eol leakage, fire eol leakage
  sox_upfront = 0   # remove hvac annual and eol leakage, fire eol leakage
  voc_upfront = 0   # remove hvac annual and eol leakage, fire eol leakage
  pm25_upfront = 0   # remove hvac annual and eol leakage, fire eol leakage
  
  upfront_damage_index = c(1, 5:7, 10:13, 16:28)
    
  for (i in upfront_damage_index) {
    
    ghg_upfront = ghg_upfront + sum(results.total.list.ghg[[i]]$r)
    co_upfront = co_upfront + sum(results.total.list.co[[i]]$r)
    nox_upfront = nox_upfront + sum(results.total.list.nox[[i]]$r)
    sox_upfront = sox_upfront + sum(results.total.list.sox[[i]]$r)
    voc_upfront = voc_upfront + sum(results.total.list.voc[[i]]$r)
    pm25_upfront = pm25_upfront + sum(results.total.list.pm25[[i]]$r)
    
  }
  
  ghg_upfront = ghg_upfront + (sum(results.total.list.ghg[[9]]$r) - sum(results.kg.co2eq_r410A$r))/HVAC_factor
  ghg_upfront = ghg_upfront + sum(results.total.list.ghg[[8]]$r) - sum(results.kg.co2eq_agent$r)
  ghg_upfront = ghg_upfront + sum(results.total.list.ghg[[2]]$r) / Inv_factor
  ghg_upfront = ghg_upfront + sum(results.total.list.ghg[[3]]$r) / Trans_factor
  ghg_upfront = ghg_upfront + sum(results.total.list.ghg[[4]]$r) / Switch_factor
  ghg_upfront = c(ghg_upfront, rep(0, Lifetime))
  
  co_upfront = co_upfront + (sum(results.total.list.co[[9]]$r))/HVAC_factor
  co_upfront = co_upfront + sum(results.total.list.co[[8]]$r)
  co_upfront = co_upfront + sum(results.total.list.co[[2]]$r) / Inv_factor
  co_upfront = co_upfront + sum(results.total.list.co[[3]]$r) / Trans_factor
  co_upfront = co_upfront + sum(results.total.list.co[[4]]$r) / Switch_factor
  co_upfront = c(co_upfront, rep(0, Lifetime))
  
  nox_upfront = nox_upfront + (sum(results.total.list.nox[[9]]$r))/HVAC_factor
  nox_upfront = nox_upfront + sum(results.total.list.nox[[8]]$r)
  nox_upfront = nox_upfront + sum(results.total.list.nox[[2]]$r) / Inv_factor
  nox_upfront = nox_upfront + sum(results.total.list.nox[[3]]$r) / Trans_factor
  nox_upfront = nox_upfront + sum(results.total.list.nox[[4]]$r) / Switch_factor
  nox_upfront = c(nox_upfront, rep(0, Lifetime))
  
  sox_upfront = sox_upfront + (sum(results.total.list.sox[[9]]$r))/HVAC_factor
  sox_upfront = sox_upfront + sum(results.total.list.sox[[8]]$r)
  sox_upfront = sox_upfront + sum(results.total.list.sox[[2]]$r) / Inv_factor
  sox_upfront = sox_upfront + sum(results.total.list.sox[[3]]$r) / Trans_factor
  sox_upfront = sox_upfront + sum(results.total.list.sox[[4]]$r) / Switch_factor
  sox_upfront = c(sox_upfront, rep(0, Lifetime))
  
  voc_upfront = voc_upfront + (sum(results.total.list.voc[[9]]$r))/HVAC_factor
  voc_upfront = voc_upfront + sum(results.total.list.voc[[8]]$r)
  voc_upfront = voc_upfront + sum(results.total.list.voc[[2]]$r) / Inv_factor
  voc_upfront = voc_upfront + sum(results.total.list.voc[[3]]$r) / Trans_factor
  voc_upfront = voc_upfront + sum(results.total.list.voc[[4]]$r) / Switch_factor
  voc_upfront = c(voc_upfront, rep(0, Lifetime))
  
  pm25_upfront = pm25_upfront + (sum(results.total.list.pm25[[9]]$r))/HVAC_factor
  pm25_upfront = pm25_upfront + sum(results.total.list.pm25[[8]]$r)
  pm25_upfront = pm25_upfront + sum(results.total.list.pm25[[2]]$r) / Inv_factor
  pm25_upfront = pm25_upfront + sum(results.total.list.pm25[[3]]$r) / Trans_factor
  pm25_upfront = pm25_upfront + sum(results.total.list.pm25[[4]]$r) / Switch_factor
  pm25_upfront = c(pm25_upfront, rep(0, Lifetime))
  
  # damages_upfront = damages_upfront * scc
  
  # damages_upfront  = # remove life_cycle emissions from lca results
  ## subtract independent LCA on HVAC_mass_r410a
  ## divide remaining HVAC cost by HVAC factor
  #
  ## subtract independent LCA on Fire_mass_agent
  ## do NOT divide by fire factor
  #
  ## divide inverter by inverter factor
  #
  ## divide trans by trans factor
  #
  ## divide switch by switch factor
  #
  
  ### df assembly
  
  df_NPV = data.frame(cost_upfront,
                      ghg_upfront,
                      c(0,cost_batt_replace),
                      c(0,ghg_batt_replace),
                      c(0,cost_equipment_life),
                      c(0,ghg_equipment_life),
                      c(0,cost_purchased_elec),
                      c(0,ghg_purchased_elec_ann),
                      c(0,cost_offset_elec),
                      c(0,ghg_offset_elec_ann))
  
  colnames(df_NPV) = c("usd_upfront", "kgco2_upfront",
                       "usd_battrep", "kgco2_battrep",
                       "usd_o&m", "kgco2_o&m",
                       "usd_charge", "kgco2_charge",
                       "usd_discharge", "kgco2_discharge")
  

  ##############################################################################
  # Final Results Formatting #
  ##############################################################################
  
  ### Efficiency reformtatting
  
  df_losses = data.frame(c("Transformer", "Inverter", "Battery", "Thermal", "Misc."),
                         c(Efficiency$Transformer, Efficiency$Inverter, 1-Efficiency$Battery,
                           Efficiency$Thermal_Draw, Efficiency$Misc_Draw))
  colnames(df_losses) = c("Equipment", "Percent_Loss")
  
  
  results = list(df_tot_graph, mat_key, results.total.list.ghg, results.total.list.co,
                 results.total.list.nox, results.total.list.sox, results.total.list.pm25,
                 results.total.list.voc, cases, df_NPV, df_losses)
  
  
  return(results)
  
}

