#------------------------------------------------------------------------------
# function_results_chem_stats #
#------------------------------------------------------------------------------

# Used in battery cost modeling

# preps plotting for chem plots

# NEED TO UPDATE TO REFLECT CHANGES ON func_li_BESS

#------------------------------------------------------------------------------
# Libraries, Clear, and Runs #
#------------------------------------------------------------------------------

library(readxl)
library(ggplot2)
library(RColorBrewer)
# library(matlib)
library(reshape2)
library(MASS)
library(foreign)
library(gridExtra)
# library(DMwR)
library(abind)
library(openxlsx)
library(rlang)
library(rstudioapi)
library(fBasics)
library(grDevices)
library(unikn)
library(ggrepel)
library(EnvStats)

#------------------------------------------------------------------------------
# Function #
#------------------------------------------------------------------------------

function_results_chem_stats <- function(results_binded) {
  
  Stats = data.frame(Mean = numeric(3), STDev = numeric(3), Chemistry = factor(3))
  Stats$Mean = c(sum(results_binded$Mean[results_binded$Chemistry=="NCA Graphite"]),
                 sum(results_binded$Mean[results_binded$Chemistry=="NMC Graphite"]),
                 sum(results_binded$Mean[results_binded$Chemistry=="LFP Graphite"]) # ,
                 # sum(results_binded$Mean[results_binded$Chemistry=="LMO Graphite"])
  )
  Stats$STDev = round(c(sum(results_binded$STDev[results_binded$Chemistry=="NCA Graphite"]),
                        sum(results_binded$STDev[results_binded$Chemistry=="NMC Graphite"]),
                        sum(results_binded$STDev[results_binded$Chemistry=="LFP Graphite"]) # ,
                        # sum(results_binded$STDev[results_binded$Chemistry=="LMO Graphite"])
  )
  )
  Stats$Chemistry = c("NCA Graphite", 
                      "NMC Graphite", 
                      "LFP Graphite" # , 
                      #"LMO Graphite"
  )
  
  return(Stats)
  
}